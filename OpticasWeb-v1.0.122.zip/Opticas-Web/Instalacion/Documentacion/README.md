# OpticasWeb v1.0.59 — Gestión Óptica (PHP + MariaDB)

Versión de trabajo para **Óptica Nueva Visión**, preparada para XAMPP con dos delegaciones.

## Convención de delegaciones

La aplicación usa una única convención:

- **1 = Carmona**
- **2 = Tocina**

La BBDD original usaba `Delegacion` al revés (1=Tocina, 2=Carmona), mientras que sus `Almacenes` ya eran 1=Carmona y 2=Tocina. Desde v1.0.51 los importadores traducen correctamente clientes/artículos y el stock se conserva sin invertir.

## Actualizar una instalación existente

Ejecuta **`actualizar_base_datos.bat`**. Antes de cambiar nada crea automáticamente un volcado SQL en la carpeta `backups`. La corrección de delegaciones y la carga segura de datos heredados quedan registradas en `app_migrations`, por lo que no vuelven a aplicarse al repetir la actualización.

## Instalación nueva

1. Ejecuta **`instalar_todo.bat`** como administrador.
2. Abre la aplicación con **`abrir_gestion_optica.bat`** o el acceso directo creado.
3. Usuario inicial: `admin` / `admin`; cambia la contraseña al entrar.
4. Para cargar los datos históricos, usa en este orden:
   - `importar_clientes_reales.bat`
   - `importar_productos_reales.bat`
   - `importar_ficha_optica_reales.bat`
   - `importar_stock_reales.bat`

Los importadores de clientes y productos reemplazan sus tablas de destino; los `.bat` piden confirmación antes de ejecutarlos.

## Backup y Restauración (Local)

El menú **Configuración → Backup y Restauración (Local)** permite crear
volcados SQL completos en `Backups_Local`, trasladarlos a otro equipo y
restaurarlos. Cada restauración exige un archivo SQL completo, crea primero
`Backup_Antes_Restauracion_...sql` y comprueba las tablas esenciales. Si la
importación falla o queda incompleta, revierte automáticamente a esa copia.

### Listados ajustables

En Clientes y Artículos puedes arrastrar el borde entre columnas para cambiar sus anchos. La distribución se guarda automáticamente en ese navegador/equipo. El botón **Restablecer columnas** elimina esa memoria y recupera el reparto por defecto.

## Estado funcional actual

Implementado en v1.0.54: **Proveedores**, histórico de **Compras por artículo** y pestaña **Ventas Cliente** en modo consulta; además se mantiene todo lo anterior.

Implementado: clientes, usuarios, delegaciones, marcas, artículos, ficha de gafas, lentillas, audífonos, listados, stock por delegación y saneamiento de datos heredados de clientes/artículos.

Pendiente de siguientes fases: edición operativa de compras, Nueva Venta/TPV, pedidos/encargos, facturación, Cuentas Cliente e inventario.

## Reparar codificación

Si tras importar aparecen nombres con símbolos extraños, ejecuta `reparar_codificacion_datos.bat`. Corrige textos de clientes y artículos sin borrar registros.

## Archivos de base de datos

- `instalar_bd.sql`: creación inicial usada por el instalador.
- `schema.sql`: esquema para instalación manual.
- `actualizar_bd_todo.sql`: única migración estructural consolidada.
- `importar_*_reales.sql`: volcados históricos preparados para esta tienda.

Los antiguos `actualizar_bd_*.sql` individuales se han retirado del paquete para evitar duplicidades.


## Operativa histórica v1.0.54
`actualizar_base_datos.bat` crea las tablas nuevas e importa de forma idempotente los 93 proveedores, el histórico TPV/ventas y las compras disponibles en el backup original.
