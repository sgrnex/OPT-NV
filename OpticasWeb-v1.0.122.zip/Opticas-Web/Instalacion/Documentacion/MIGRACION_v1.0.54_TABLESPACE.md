# v1.0.54

Corrección definitiva de tablas operativas InnoDB.

Las páginas PHP no crean tablas al abrirse. Las estructuras se gestionan únicamente mediante instalador y actualizador para evitar errores 1813 por tablespaces huérfanos.
