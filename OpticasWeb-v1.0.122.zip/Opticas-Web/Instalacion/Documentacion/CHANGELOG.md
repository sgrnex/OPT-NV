# Historial de versiones — OpticasWeb

## v1.0.87

- El acceso directo del escritorio pasa a llamarse «Cloud Opticas».
- El instalador mantiene `instalar_todo.bat` como archivo principal de la
  carpeta raíz.
- La aplicación queda agrupada en `Aplicacion/` y los recursos de instalación
  de base de datos en `Instalacion/BaseDatos/`.
- Se mantienen las mismas rutas de instalación y el mismo funcionamiento de
  Apache, MySQL y del acceso directo.

## v1.0.86

- Columnas de los listados principales adaptadas automáticamente al ancho real
  disponible de la ventana.
- Al redimensionar una columna, el espacio se redistribuye entre las columnas
  situadas a su derecha.
- La distribución se recalcula al cambiar el tamaño de la ventana y mantiene
  el desplazamiento horizontal solo cuando no existe espacio suficiente.
- Aplicado a Clientes, Artículos, Proveedores, Usuarios, Marcas e Inventario.

## v1.0.85

- Eliminada la columna final vacía que quedaba después de «Delegación» en los
  listados de Clientes y Artículos.
- Ajustadas las filas de filtros y el cálculo de anchos para que coincidan con
  las columnas reales.
- Eliminada la lupa residual del listado de Proveedores.
- Reiniciada la memoria de columnas para evitar recuperar distribuciones
  antiguas incorrectas.
- Retirada la pastilla «Inicio» de la pantalla de Inicio.

## v1.0.84

- Sustituido el icono de escritorio e instalación por la imagen facilitada.
- Conservadas las proporciones originales, sin deformación.
- Generado el icono en resoluciones de 16×16 a 256×256 con fondo blanco para
  adaptar correctamente el símbolo al formato cuadrado `.ico`.

## v1.0.83

- Nueva distribución de **Backup y Restauración (Local)** en dos bloques
  enfrentados, con separación vertical y listado de copias a todo lo ancho.
- El botón de restauración queda encima del selector de archivo.
- Las barras de progreso siguen apareciendo a la derecha del botón activo con
  los mensajes «Volcando base de datos» y «Restaurando Base de Datos».
- Tipografía del nombre «Cloud Opticas» del menú lateral unificada con la del
  logotipo de la portada.

## v1.0.82

- Portada de acceso alineada con la maqueta definitiva facilitada.
- Tipografía del texto «Cloud Opticas» configurada como Calligrahp810 BT Roman.
- Paleta CSS global basada en los colores reales del logotipo.
- Eliminado el botón «Entrar en el programa».

## v1.0.81

- Portada de acceso ajustada literalmente a la maqueta facilitada: Arial,
  colores, espacios y colocación del formulario.
- Eliminado el botón «Entrar en el programa».

## v1.0.80

- Nuevo icono de escritorio e instalación basado en la imagen facilitada.
- Conversión multirresolución de 16×16 a 256×256, conservando las proporciones
  originales y completando el formato cuadrado con fondo blanco.
- Actualizada también la caché del icono utilizado por el navegador.

## v1.0.79

- La portada retocada se convierte en la pantalla única de inicio de sesión.
- Se mantiene el menú lateral común en toda la aplicación una vez validado el usuario.
- El cierre de la última ventana activa cierra automáticamente la sesión, sin
  interrumpir la navegación interna ni otras ventanas abiertas.
- Se conserva el logotipo sin deformar mediante ajuste proporcional.

## v1.0.59

- Botón **Aceptación APD** alineado verticalmente con Mailing/SMS.
- Unificados los botones **Guardar** de 21 Puntos y Observaciones con el
  estilo general, eliminando la barra duplicada inferior.
- Precios de las tablas repetibles mostrados siempre con dos decimales.

## v1.0.59

- Unificados los botones de **Guardar** en 21 Puntos y Observaciones con el
  estilo general de las fichas; eliminada la barra duplicada inferior.
- Alineado verticalmente el botón **Aceptación APD** con Mailing/SMS.
- Conservadas las mejoras de Inventario, Encargos/Pedidos, fuentes, tamaños,
  listados y PDF de la v1.0.58.

## v1.0.58

- Activado **Inventario** con stock, mínimos, costes, PVP, delegación y aviso de stock bajo.
- Activado **Encargos/Pedidos** con alta, fecha, cliente, artículo, estado y observaciones.
- Añadidos cinco tamaños de letra y fuentes Arial/Helvetica, Times y Courier para impresión y PDF.
- En listados con detalle, los datos del paciente aparecen una sola vez; las filas siguientes no repiten nombre y apellidos.
- Se mantienen los límites físicos de celda, separación y truncado `...` de los PDF.

## v1.0.57

- Añadido selector funcional **Ninguna** junto a **Todas** en los listados.
- La selección vacía se conserva al generar el listado; ya no se interpreta
  erróneamente como “todas las columnas”.
- Los nombres muestran nombre y primer apellido, manteniendo el nombre
  completo cuando no existen apellidos (sociedades o entidades).
- El PDF aplica recorte físico por celda y usa `...` compatible, evitando que
  cualquier texto invada la columna siguiente.
- Ajustadas las anchuras de delegación y columnas de longitud conocida.

## v1.0.56

- Reforzada la persistencia de columnas de Clientes y Artículos: memoria
  versionada, restauración tras completar el layout y guardado del estado de
  la tabla al redimensionar.
- Los PDF de listados genéricos calculan ahora el ancho de cada columna según
  sus contenidos, respetando mínimos y máximos.
- Los textos que superan el ancho disponible se truncan con `…` y nunca
  invaden la columna contigua.

## v1.0.55

- Añadido **Backup y Restauración (Local)** al menú principal.
- Creación de volcados SQL completos con fecha y hora en `Backups_Local`.
- Restauración protegida con confirmación, validación del archivo y copia
  automática previa.
- Comprobación posterior de tablas esenciales y reversión automática si la
  restauración falla o queda incompleta.
- La carpeta de backups queda protegida frente al acceso web directo.
- `db.php` ya no crea ni modifica tablas al abrir pantallas; la estructura se
  gestiona únicamente mediante instalación y actualización.
- Versión interna, instaladores y documentación actualizados a 1.0.55.

## v1.0.54

- Habilitado **Proveedores**: listado, búsqueda, filtro, alta, edición, activo/inactivo, navegación y borrado seguro mediante desactivación, conservando siempre el histórico.
- Importados los **93 proveedores** del backup original con corrección UTF-8 y traducción de delegaciones.
- Habilitada la pestaña **Compras** de la ficha de artículo con histórico de pedido/albarán/factura de compra disponible en el backup.
- Habilitada **Ventas Cliente** como consulta histórica: 18.673 cabeceras TPV y 32.278 líneas, con detalle por venta y total pagado.
- Añadida red de seguridad en `db.php` para crear tablas operativas críticas si se copia el programa antes de ejecutar el actualizador; evita el fatal por `articulos_compras` ausente.
- Corregido estructuralmente el redimensionado de columnas en Clientes y Artículos: la columna de selección ya no se elimina con `display:none`, cada tirador conserva su índice real y los anchos se memorizan por columna en formato v4.
- `actualizar_base_datos.bat` e `instalar_todo.bat` importan automáticamente la operativa histórica v1.0.54 de forma idempotente.

## v1.0.52

- Corregido definitivamente el **desfase de una columna** de los tiradores de redimensionado en los listados de Clientes y Artículos.
- Cada tirador queda vinculado por `data-col-key` a su columna real, no por posición visual/índice.
- La columna de selección oculta ya no desplaza los anchos ni los tiradores; al activar/desactivar Seleccionar se recalcula sin alterar el resto.
- Nueva memoria de anchos **v3**: se descartan automáticamente configuraciones anteriores incompatibles.
- Se mantienen anchos mínimos, memoria independiente por listado y botón Restablecer columnas.


## v1.0.51

- Fix codificación UTF-8: regenerados importadores históricos desde el backup en UTF-8 real y añadido `reparar_codificacion_datos.bat` para corregir instalaciones donde aparecían textos tipo `ADRIAN` o `MUNOZ` con simbolos raros.

- Corregido definitivamente el redimensionado manual de columnas en los listados de Clientes y Artículos: se descartan memorias antiguas corruptas, se aplican anchos mínimos reales, la tabla ya no puede contraerse a la izquierda y los textos no se parten verticalmente.
- Cierre de la disposición visual definitiva de **Consulta Artículos**: nombre actual arriba a la izquierda, título centrado, Delegación con etiqueta a la izquierda del desplegable y controles superiores/inferiores según la referencia aportada.
- **Guardar / Nuevo / Borrar** quedan agrupados a la izquierda y **Anterior / Siguiente / Volver** a la derecha; Guardar usa el mismo estilo que los demás botones.
- El mismo criterio de botoneras y controles se aplica a la **Ficha Cliente**.
- Listados de **Clientes** y **Artículos**: columnas redimensionables arrastrando sus separadores; los anchos quedan memorizados por separado en el navegador/equipo y se añade **Restablecer columnas** para volver al reparto original.
- Renombrada la pestaña superior de la ficha de cliente a **Datos Cliente**.
- Unificada definitivamente la **tipografía, altura de casillas y tamaño de texto** en toda la aplicación mediante una única escala global.
- Corregida la cabecera fija de los listados de Clientes y Artículos: el `thead` completo queda fijo y opaco, evitando que el texto de las filas se vea por debajo de la franja verde tras compactar las filas.
- Afinado final de interfaz: **Consulta Artículos** y **Ficha Cliente** reducen también tipografía y altura de campos; todos los checkbox de la aplicación comparten el mismo cuadrado compacto y check azul.
- Ajuste final de interfaz: título superior desplazado, botoneras superiores con el mismo aspecto que las inferiores y botón inferior **Borrar** en Clientes y Artículos.
- Listados más densos: tipografía reducida, interlineado mínimo legible y menor altura de fila.
- Reducción global aproximada del **15 %** en la altura de los campos de datos (sin alterar checkboxes/radios).
- Corregido el mapeo de delegaciones heredado del sistema original: la aplicación mantiene **1=Carmona / 2=Tocina**, traduciendo clientes y artículos importados desde **1=Tocina / 2=Carmona**.
- Añadida una **migración única e idempotente** que, además del arreglo de delegaciones, rellena campos heredados que en v1.0.50 quedaron vacíos o incompletos en **clientes** y **artículos**.
- El **stock por almacén** se reconstruye con los datos reales del backup, sin invertir delegaciones porque en origen ya era **1=Carmona / 2=Tocina**.
- Regenerados los importadores `importar_clientes_reales.sql`, `importar_productos_reales.sql` e `importar_stock_reales.sql` con más campos útiles (21 puntos, audífonos, márgenes, cuentas, web, color/material/sexo/calibre/proveedor, etc.).
- Fichas de **cliente** y **artículo** ajustadas al diseño de referencia y **compactadas verticalmente** para reducir la necesidad de scroll sin perder legibilidad.
- Recuperada la pestaña **Observaciones** en clientes, manteniendo además el resumen visible en la ficha principal.
- `actualizar_base_datos.bat` crea copia SQL previa y refleja ya que también sanea datos y recompone stock.
- Limpieza del paquete: retiradas migraciones estructurales individuales duplicadas y el antiguo `reparar_bd.bat`, peligroso una vez existen datos reales.
- README actualizado al estado funcional real de la aplicación.

## v1.0.50

- Corregido el fondo verde de la cabecera de los listados: ahora se
  mantiene fijo junto con el texto al hacer scroll (antes la franja
  verde se desplazaba y el texto quedaba "flotando").
- Etiquetas de campo sin negrita en las fichas de cliente y artículo.
- Ficha de artículo: casillas más anchas y un 15% más bajas; ficha algo
  más ancha para dar sitio a todos los campos.
- Ficha de cliente: casillas un 15% más bajas.

## v1.0.49

- Comandos superiores de las fichas (Nuevo, Guardar, Borrar...) ahora
  como **botones con recuadro**, con la navegación (Anterior/Siguiente/
  Volver) separada a la derecha, en cliente y artículo.
- **Ficha de artículo** reorganizada y compacta según el nuevo diseño;
  la pestaña **Tarifas** cabe sin scroll (4 filas anchas).
- **Ficha de cliente** reorganizada y más baja: se elimina Teléfono 2,
  se incorpora el bloque **Observaciones** dentro de "Datos contacto
  cliente" y se elimina la pestaña "Observaciones" (usan el mismo
  campo, no se pierde nada).

## v1.0.48

- Ventanas de poca información (Marcas, Delegaciones, Usuarios y ficha
  de usuario) más estrechas (520px).
- **Marcas**: buscador, edición del nombre en línea, contador de
  marcas y ordenación por nombre o nº de artículos.
- **Delegaciones**: cada una editable como tarjeta con Nombre,
  Dirección, Teléfono y Email; crear, guardar y borrar.
- **Usuarios**: buscador, filtro activo/inactivo, columna "Último
  acceso" (se registra al iniciar sesión) y botón bloquear/activar
  (🔒/🔓) sin borrar.
- Nueva migración `actualizar_bd_delegaciones_usuarios.sql` (incluida
  en `actualizar_bd_todo.sql` y en `actualizar_base_datos.bat`).

## v1.0.47

- Reiniciar numeración: el recuadro de la vista preliminar es un 30%
  más bajo (de 55vh a 38vh de altura máxima).

## v1.0.46

- **Corregida la ficha de artículo "descolocada"**: un `</div>`
  sobrante cerraba el panel antes de tiempo, lo que sacaba la barra de
  acciones y los campos fuera de su sitio. Ya se ve correctamente
  dentro del panel.
- La cabecera de columna "Número" ya no se parte en dos líneas.

## v1.0.45

- Ficha de artículo: reorganizada la cabecera con el orden y anchos
  indicados (Referencia/Fecha Alta/Ult. Modif./Último proveedor;
  Nombre ancho + Modelo + Marca; Código Fabricante/Color/Material/Sexo;
  Código/Código Barras/Casa/Calibre + Activo), con la Delegación arriba
  a la derecha. Al abrir la ficha aparece ya desplegada la pestaña
  **Tarifas**.

## v1.0.44

- **Uniformidad total** tomando Clientes como patrón: todas las
  pantallas (Usuarios, Marcas, Delegaciones, fichas de las pestañas de
  cliente, ficha de usuario, ficha de artículo, Reiniciar numeración)
  usan ya la misma tipografía, los mismos botones con icono a la
  izquierda (➕ Nuevo, ✅ Guardar, ❌ Eliminar, ↩️ Volver,
  ⬅️ Anterior, ➡️ Siguiente...) y el mismo estilo de listado (píldora
  de título, doble clic en fila para abrir, iconos de acción).

## v1.0.43

- Revisión de homogeneidad: reforzado el estilo de los botones para
  que todos (enlaces y botones) tengan exactamente el mismo tamaño y
  altura.
- Confirmado que Anterior/Siguiente están en las fichas de cliente
  (las 6 pestañas) y de artículo, que ambos listados tienen los
  botones necesarios (Nuevo, Seleccionar, Buscar, Filtrar, Limpiar +
  los propios de cada módulo) y la paginación/navegación.

## v1.0.42

- **Tipografía homogénea en toda la aplicación**: se fija un único
  tamaño de letra base y se eliminan los tamaños dispares que había
  por pantallas (títulos, listados, fichas...). Nada de textos
  grandes; todas las fichas y listados comparten el mismo tamaño.
  Únicas excepciones estructurales: la píldora de título de cada
  pantalla y el icono de la cámara en la foto.

## v1.0.41

- Ficha de artículo (y sus 6 pestañas) más compacta: etiquetas de
  campo con letra más pequeña y recuadros de entrada de menor altura,
  sin afectar a la ficha de cliente.

## v1.0.40

- **Importación del stock por almacén** (`importar_stock_reales.bat`):
  rellena la pestaña "Existencias" de cada artículo con el stock real
  de Carmona y Tocina tomado del backup (27.184 registros). Antes esa
  pestaña salía vacía porque solo se había importado el total, no el
  desglose por almacén.

## v1.0.39

- Ficha de artículo: barra de acciones homogénea con la de cliente
  (Nuevo, Guardar, Borrar, Etiquetas, Anterior, Siguiente, Volver)
  arriba y abajo, misma tipografía y estilo.
- Listado de artículos: añadido el modo **Seleccionar** con casillas y
  acciones en bloque (borrar / activar / desactivar), igual que
  clientes.
- Doble clic en cualquier parte de la fila de un artículo lo abre, y al
  **Volver** se regresa exactamente a ese artículo (resaltado y con los
  mismos filtros/página).

## v1.0.38

- Nuevo **`actualizar_base_datos.bat`**: aplica todas las
  actualizaciones de estructura de la base de datos con un doble clic,
  sin tener que entrar en phpMyAdmin. Es seguro: solo añade columnas y
  tablas que falten, no borra ni modifica datos existentes (ni los
  nombres de clientes corregidos a mano).

## v1.0.37

- **Menú lateral y cabeceras fijos**: el menú queda fijo; en Clientes y
  Artículos, la parte superior (título, buscador, botones y cabeceras
  de columna) se mantiene fija y solo hace scroll el cuerpo de la lista.
- **Ficha de artículo completa** con sus 6 pestañas, replicando el
  programa original: datos generales (referencia, nombre, calibre,
  color, material, sexo, modelo, proveedor, marca, casa, códigos...),
  **Tarifas** (márgenes, impuestos, PVP 1-5, costes, cuentas),
  **Existencias** (stock por almacén), **Compras**, **Observaciones**,
  **Campos Extra** y **Web**. Migración:
  `actualizar_bd_ficha_articulo.sql` (en `actualizar_bd_todo.sql`).

## v1.0.36

- Menú lateral un 15% más ancho.
- En la Ficha Gafas, **doble clic sobre una línea de producto**
  (Producto de graduaciones, Monturas o Gafas de sol) abre una ventana
  emergente con los artículos del almacén cuyo nombre se parece; al
  pulsar uno, se abre su ficha. Si no hay coincidencias, avisa. (El
  producto en la ficha es texto libre importado, por eso se ofrecen
  candidatos en vez de un enlace directo.)

## v1.0.35

- **Delegaciones renombradas** a su nombre corto en la base de datos:
  1 = Carmona, 2 = Tocina (la empresa "Óptica Nueva Visión" irá en
  Configuración). Todos los desplegables y columnas de delegación
  muestran ya solo Carmona/Tocina, sin acortados al vuelo. Migración:
  `actualizar_bd_nombres_delegaciones.sql` (incluida en
  `actualizar_bd_todo.sql`).
- **Artículos** usa los mismos controles e iconos que Clientes en su
  barra (🔍 Buscar, ➕ Nuevo, 🏷️ Marcas, 🔎 Filtrar, 🧹 Limpiar).
- **Ventanas centradas**: Marcas, Delegaciones, ficha de Artículo,
  ficha de Usuario y Reiniciar numeración se muestran centradas como
  la de Listados, no desplazadas a la izquierda.
- Corregida la caja de "Nombre de la nueva marca/delegación": era
  enorme; ahora es un campo de una sola línea.
- En el filtro común de Listados, las etiquetas de los campos ya no
  van en negrita.

## v1.0.34

- Pantalla de Listados: el título "Opciones de salida" va ahora dentro
  del recuadro como encabezado normal (igual que "Formato de salida"),
  no incrustado en la línea del borde.
- "Columnas a incluir:" queda en su propia línea, con todas las
  opciones en la línea inferior.

## v1.0.33

- Pantalla de Listados: "Formato de salida" y "Columnas a incluir" se
  muestran cada uno en una sola línea (sin que HTML o Delegación caigan
  a una segunda línea), más compactos, como se pidió. En ventanas muy
  estrechas esas líneas hacen scroll horizontal en vez de partirse.

## v1.0.32

- Pantalla de Listados: todo el texto a un tamaño más pequeño (los
  encabezados de sección algo mayores para que sigan destacando).
- En cualquier listado, la columna Delegación muestra solo el nombre
  corto (Carmona / Tocina), no el nombre completo de la tienda.

## v1.0.31

- **Homogeneidad visual de la pantalla de Listados**: las cuatro
  secciones (Tipo de listado, Filtrar qué clientes incluir, Formato de
  salida y Opciones de salida) comparten ahora el mismo recuadro y el
  mismo estilo de encabezado (color acento, negrita, mismo tamaño).
  Se quitaron los separadores redundantes y los botones Volver /
  Generar listado llevan icono, a juego con el resto de la aplicación.

## v1.0.30

- **Filtro común "a qué clientes incluir"** en Listados: un único
  bloque plegable, entre el tipo de listado y el formato de salida,
  que se aplica a **cualquier** listado (General, Graduaciones,
  Lentillas, Audífonos). Filtros: Nombre/Apellidos, NIF, Teléfono,
  Población, Provincia, Email, Edad (desde/hasta), Fecha de alta
  (desde/hasta), Fecha de nacimiento (desde/hasta), Delegación,
  Estado (activo/inactivo), Acepta Mailing/SMS y Revisión pendiente.
- Para evitar duplicar criterios, se han quitado como tipos de listado
  "por Edades", "por Fecha de Alta" y "por Delegación": ahora esos
  criterios viven solo en el filtro común (Delegación sigue además
  como columna mostrable).

## v1.0.29

- **Delegación** disponible también como columna elegible en "Columnas
  a incluir" (además de seguir existiendo como tipo de listado), para
  poder mostrarla en cualquier listado.

## v1.0.28

- La pantalla de selección de Listados usa ahora el mismo tamaño de
  letra que el resto de la aplicación (se quitaron los tamaños
  reducidos de "Formato de salida" y "Opciones de salida"); solo se
  mantiene la negrita donde corresponde.

## v1.0.27

- Pantalla de Listados: las filas de formato y opciones ahora se
  ajustan dentro del margen de la página (bajan de línea si no caben)
  en vez de salirse por la derecha; mismo tamaño de letra.

## v1.0.26

- **Corregido el PDF de listados** (salían avisos "Undefined variable
  $interlinea"): faltaba capturar esa variable en la función interna;
  ya genera el PDF correctamente.
- Pantalla de Listados **centrada** en la ventana.
- "Formato de salida" y cada fila de "Opciones" van ahora **en una
  sola línea** (con scroll horizontal si no cabe).
- Casilla **"Todas"** para activar/desactivar de golpe las columnas a
  incluir, además de una a una.
- Tres listados nuevos: **por Delegación**, **por Fecha de Alta**
  (ambos funcionando) y **por Vendedor** (en gris hasta que exista
  Ficheros → Vendedores).

## v1.0.25

- **Listados de Clientes ampliados**:
  - Graduaciones, Lentillas y Audífonos pueden salir **con o sin el
    detalle** de cada cliente. Con detalle usan formato ficha (cliente
    y debajo sus graduaciones / lentillas / audiometrías).
  - Nueva salida **🖨️ Imprimir** (abre una vista limpia y lanza el
    diálogo de impresión del navegador).
  - **Opciones de salida** para Pantalla/Imprimir/PDF: orientación
    (vertical u horizontal), tamaño de letra (pequeño/normal/grande) y
    elección de qué columnas incluir (NIF, Teléfono, Población,
    Provincia, Email).
  - En CSV/Excel/XML, el modo con detalle se aplana repitiendo los
    datos del cliente en cada fila de detalle.
- El motor PDF admite ahora orientación horizontal además de la
  paginación ya añadida.

## v1.0.24

- Botones del listado de Clientes reordenados y todos con icono a la
  izquierda del texto (Nuevo, Seleccionar, Listados, Reiniciar,
  Buscar, Filtrar, Limpiar).
- **El PDF de listados ahora es multipágina**: saca el listado
  completo (todos los registros), repitiendo la cabecera en cada
  página, en vez de cortar a una sola hoja.

## v1.0.23

- **Campo "Ir a pág."** en la barra de paginación (Clientes y
  Artículos), útil con muchas páginas.
- **Pantalla de Listados de Clientes** (botón "Listados clientes"),
  con las opciones: General, por Edades, por Graduaciones, con
  Lentillas y con Audífonos. Deudores, Preferenciales y por Doctor
  quedan en gris hasta que existan Ventas y Ficheros→Doctores.
- Cada listado se puede sacar en **7 formatos**: Ver en pantalla, PDF,
  Excel, CSV, RTF, XML y HTML. (El PDF, por usar el motor propio sin
  librerías, se limita a una página; para listados largos, usar
  Excel/CSV.)
- Con esto, el apartado **Clientes** queda funcionalmente completo.

## v1.0.22

- **Reiniciar numeración** ahora es un proceso en dos pasos: primero
  pregunta si se está seguro y ofrece una **vista preliminar** con la
  tabla completa de todos los clientes (Nº actual → Nº nuevo, los que
  cambian resaltados); solo tras revisarla y marcar la confirmación se
  aplica definitivamente.

## v1.0.21

- **Paginación real** en los listados de Clientes y Artículos (antes se
  cortaban a 500). Selector de tamaño de página (50, 100, 200, 500,
  1000 o Todos) y botones Anterior/Siguiente con indicador de página,
  arriba y abajo de la tabla. Conserva búsqueda, filtros y orden al
  cambiar de página.
- **Corregido el desfase de los filtros por columna**: había una celda
  de más que corría todas las casillas una posición (por eso al
  escribir bajo "Apellidos" filtraba por "Nombre").
- **Columnas autoajustables**: la tabla reparte el ancho entre todas
  las columnas y el texto largo parte de línea, para que se vean todas
  dentro de la ventana sin scroll horizontal.

## v1.0.20

- **Corregido el aviso de borrado que saltaba al buscar/filtrar**: las
  casillas de filtro compartían formulario con los botones de acción
  masiva, y pulsar Enter disparaba "Borrar seleccionados". Ahora los
  filtros (GET) y la selección múltiple (POST) van en formularios
  separados, y el de selección no tiene botones dentro.
- **Filtrar / Limpiar** movidos a la fila de botones superior (a la
  derecha), en Clientes y Artículos, para que no se salgan de la fila
  de filtros.

## v1.0.19

- Añadida la casilla de filtro bajo **Número** (Clientes y Artículos),
  que faltaba.
- Corregido que la celda "Filtrar / Limpiar" se saliera de la fila:
  ya no hereda el ancho estrecho pensado para los iconos.

## v1.0.18

- **Corregida de verdad la justificación del PDF de Autorización APD**:
  el método anterior (espaciado de palabras vía comando PDF) no se
  estaba aplicando; ahora cada palabra se coloca a mano en su posición
  exacta para que las líneas lleguen justo al margen derecho, igual
  que en tu documento de referencia.
- **Reordenado el documento**: el recuadro de "Base jurídica y
  normativa aplicable" pasa a ir al final (después de las firmas), y
  la fecha se coloca justo antes de las firmas, alineada a la derecha
  — igual que en tu modelo.

## v1.0.17

- Reorganizada la barra de búsqueda de Clientes y Artículos en dos
  filas (búsqueda/filtros arriba, botones de acción abajo), para que
  no se amontonen todos los controles en una sola línea.
- Añadido **Número** como opción de búsqueda general (antes solo se
  podía buscar por Nombre, Apellidos, NIF, etc.).
- Confirmado y cerrado el formato del documento de Autorización APD
  (sin cambios de contenido esta vez).

## v1.0.16

- **Selección múltiple en Clientes**: botón "☑️ Seleccionar" muestra
  casillas por fila (+ "seleccionar todos los visibles/filtrados") y
  permite **Borrar**, **Activar** o **Desactivar** en bloque.
- Barra de acciones de la ficha: orden Nuevo → Guardar → Borrar, y
  todos los elementos (incluida Delegación) centrados verticalmente.
- **Corrección de Nombre/Apellidos sin repartir**: 308 clientes
  corregidos automáticamente (`actualizar_nombres_apellidos.sql`), 49
  dudosos listados en `nombres_dudosos.txt` para revisión manual, y 20
  empresas/instituciones identificadas y dejadas sin tocar.

## v1.0.15

- El nombre del cliente aparece ahora junto a la píldora "FICHA
  CLIENTE" (en gris legible) en las 6 pestañas, para saber siempre en
  qué cliente se está trabajando.
- Iconos de Anterior/Siguiente (⬅️➡️) a juego con el resto de la barra
  de acciones (Guardar, Nuevo, Borrar, Volver...).
- Botón "Aceptación APD" rediseñado como pastilla, igual estilo que
  "Ficha Gafas" / "21 Puntos", en vez del recuadro anterior.

## v1.0.14

- Corregido el hueco en blanco entre "Apellidos" y "Contacto": esos
  campos (Contacto, NIF, Dirección, Población, C.P., Provincia) ahora
  van pegados debajo de Apellidos, en la misma columna, en vez de
  esperar a que termine la columna de la foto.
- Añadida justificación (ambos márgenes) a los párrafos del PDF de
  autorización APD, incluido el recuadro de la base jurídica.

## v1.0.13

- Reorganizada la fila superior de la ficha de cliente: el botón
  "Aceptación APD" pasa a estar junto a "Acepta recibir Mailing y
  SMS"; "Fecha Aviso" pasa a su propia fila; los recuadros de Fecha
  Alta / Ult. Modificación / Próxima Revisión ahora son elásticos
  (crecen o encogen con el ancho de la ventana, hasta un máximo
  razonable), mientras Número y las casillas mantienen tamaño fijo.
- Corregido el subtítulo del PDF de autorización APD ("VISIóN" con
  tilde mal capitalizada por `strtoupper`, que no trata bien los
  acentos en UTF-8).
- La casilla "AUTORIZO..." del PDF ahora aparece marcada con una X
  cuando el cliente ya tiene el consentimiento dado en la aplicación.

## v1.0.12

- Sustituido el PDF de autorización APD por el modelo exacto
  proporcionado (mismo título, apartado de datos del interesado,
  texto de consentimiento, casilla, fecha y firmas), con los datos
  reales de la óptica (Paseo de San Antón, 10, Carmona (Sevilla),
  NIF 00000000M). La base jurídica y normativa aplicable queda en un
  recuadro gris con letra más pequeña, todo en una sola página.
- Corregido de paso un carácter (casilla ☐) que no era representable
  en la fuente del PDF; ahora es un cuadrado dibujado.
- Los datos de la óptica se editan en `datos_optica.php` hasta que
  exista la pantalla de Configuración.

## v1.0.11

- Columna Delegación en el listado muestra solo TOCINA/CARMONA (sin el
  nombre completo de la óptica).
- **Anterior/Siguiente** en todas las pestañas de la ficha (arriba y
  abajo), manteniendo la pestaña activa al cambiar de cliente.
- **Volver mantiene el sitio exacto**: búsqueda, filtros y orden se
  conservan, y la fila del cliente que acabas de ver queda resaltada y
  centrada en pantalla.
- **Aviso de cambios sin guardar** al intentar salir de una ficha
  modificada sin guardar.
- **Atajos de teclado**: `Ctrl+G` Guardar, `Ctrl+A` Anterior, `Ctrl+S`
  Siguiente (sustituyen a los atajos del navegador mientras estás en
  la app).
- Botón APD renombrado a "Aceptación / APD" (dos líneas) y solo se
  activa si la casilla de Mailing/SMS está marcada.
- Columna Apellidos ya no parte el texto en dos líneas.
- **Ordenar por cualquier columna** (Clientes y Artículos), pulsando la
  cabecera; con flecha indicando la dirección.
- **Filtro Activo/Inactivo** añadido en Clientes y Artículos.
- Reorganizada la cabecera de la ficha de cliente: Delegación se mueve
  a la barra superior de acciones; el botón de Aceptación APD se mueve
  junto a la foto.
- **Importados los datos reales de Ficha Gafas, Ficha Lentillas y
  Audífonos** (`importar_ficha_optica_reales.bat`): 30.650 graduaciones,
  17.740 monturas, 34.657 cristales/productos, 1.745 registros de
  lentillas y 3 audiometrías, todo enganchado a los clientes ya
  importados.

## v1.0.10

- **Corregido el problema de acentos/caracteres raros al importar**
  (p. ej. "2º B" apareciendo como "2┬║B"): el cliente de MySQL leía los
  ficheros `.sql` con la codificación de la consola de Windows en vez
  de UTF-8. Añadido `--default-character-set=utf8mb4` a todas las
  llamadas a `mysql.exe` (instalación, reparación e importación).
- No hace falta ningún paso extra para arreglar los datos ya
  importados: como los scripts de importación borran antes de volver a
  meter los datos, basta con **volver a ejecutar**
  `importar_clientes_reales.bat` e `importar_productos_reales.bat`.

## v1.0.9

- **Delegaciones**: nueva pantalla (Configuración → Delegaciones) para
  etiquetar cada cliente con su tienda de origen; el listado de
  Clientes sigue mostrando todos, con un filtro por delegación.
- **Importación de clientes reales**: `importar_clientes_reales.sql` +
  `.bat` — importa los 9.827 clientes reales (Tocina + Carmona) con su
  delegación ya asignada. Se excluyen a propósito los campos de "21
  Puntos" del origen porque eran una plantilla vacía idéntica en todos
  los clientes, sin datos reales.
- **Nuevo módulo Almacén → Artículos y Marcas** (básico): Código,
  Referencia, Nombre, Código de barras, Marca, Coste, PVP, Existencias,
  Delegación.
- **Importación de productos reales**: `importar_productos_reales.sql`
  + `.bat` — importa los 13.591 artículos reales, con existencias
  sumadas de todos los almacenes.
- Los listados de Clientes y Artículos limitan a 500 filas visibles a
  la vez (con aviso), para que no se sobrecarguen con miles de filas
  reales; usa el buscador para acotar.

## v1.0.8

- Redistribuida la ficha de cliente (pestaña Datos contacto cliente)
  para que coincida exactamente con la disposición indicada: Número /
  Activo / Mailing / botón APD arriba a la izquierda; Fecha Alta / Ult.
  Modificación / Próxima Revisión / Fecha Aviso arriba a la derecha;
  Nombre/Apellidos junto a la foto y "Mostrar aviso".
- Nuevo botón **IMPRIMIR FORM. APD.**: genera un PDF de una página con
  los datos del cliente y de la óptica, autorizando el envío de
  emails/SMS informativos o publicitarios, con espacio para firma.
  Los datos de la óptica se editan en `datos_optica.php` hasta que
  exista la pantalla de Configuración.
- El PDF se genera sin librerías externas (no dependía de instalar nada
  en el XAMPP).

## v1.0.7

- Barra de acciones superior en la ficha de cliente, como en el original:
  Guardar, Nuevo, Borrar, Nueva Venta, Nuevo Encargo, Imprimir, Email,
  Volver (las 4 del medio en gris hasta que existan esos módulos).
- Nuevos campos de solo lectura: **Número**, **Fecha Alta**,
  **Ult. Modificación** (se actualiza sola al guardar), y casilla
  **Activo**.
- Añadidas las pestañas **Ventas Cliente** y **Cuentas Cliente** (en
  gris, próxima fase).
- Nueva migración `actualizar_bd_activo_modificacion.sql` (ya incluida
  en `actualizar_bd_todo.sql`).

## v1.0.6

- La app ahora se llama **Cloud Opticas** de cara al usuario, y muestra
  la versión (v1.0.6) en el título de la ventana del navegador y en el
  menú lateral. Un único fichero (`version.php`) centraliza el nombre y
  la versión para no tener que cambiarlo en varios sitios.
- Los `.bat` (instalador, reparación, lanzador) también muestran
  "Cloud Opticas v1.0.6" en sus mensajes.

## v1.0.5

- Corregida la cabecera "Número" de las tablas (heredaba el estilo gris
  de las celdas de datos en vez del blanco de cabecera).
- Menú lateral reducido a ~65% de su ancho anterior.
- Doble clic en Nombre o Apellidos del listado de clientes abre la ficha.
- Ficha Gafas/Lentillas más compactas y apiladas en vertical, para verse
  completas sin scroll horizontal en una ventana normal.
- Texto del selector de archivo (foto del cliente) más pequeño, para que
  quepa bien en su columna.

## v1.0.4

- Nuevo fichero **`actualizar_bd_todo.sql`**: aplica de una sola vez
  todas las migraciones pendientes (antes había que ejecutar 5 ficheros
  por separado).
- `instalar_todo.bat` ahora aplica las migraciones automáticamente cada
  vez que se ejecuta, así que actualizar de versión no debería requerir
  tocar phpMyAdmin salvo la primera vez.

## v1.0.3

- Ficha de cliente completa con las 6 pestañas del programa original:
  **Datos contacto cliente** (todos los campos: mailing/SMS, próxima
  revisión, foto, teléfonos, profesión, tarjeta, %dto, cuenta contable,
  web...), **Ficha Gafas** (graduación LEJOS/CERCA/MULTIFOCAL por ojo +
  monturas + gafas de sol), **21 Puntos** (5 sub-pestañas), **Ficha
  Lentillas** (con gafas / prueba / definitivas / revisiones /
  queratometría) y **Audífonos** (audiometría aérea/ósea + datos del
  audífono), todas por ojo/oído según corresponda.
- Todas las tablas de filas repetibles (con el icono ➕ para añadir y ✕
  para borrar) siguen el mismo patrón que el programa original.
- La protección de borrado de cliente ahora comprueba de verdad estas
  tablas nuevas (antes apuntaba a una tabla que aún no existía).
- Nuevas migraciones para bases de datos ya creadas:
  `actualizar_bd_ficha_completa.sql`, `actualizar_bd_21puntos.sql`,
  `actualizar_bd_fichas_repetibles.sql`,
  `actualizar_bd_queratometria_audifono.sql` (ejecútalas en ese orden si
  vienes de una versión anterior; si instalas desde cero no hace falta,
  ya viene todo en `schema.sql`/`instalar_bd.sql`).

## v1.0.2

- **Corregido el fallo real de "Eliminar" que no funcionaba**: había un
  `<form>` metido dentro de otro `<form>` (HTML no permite formularios
  anidados), tanto en el listado como en el botón nuevo de la ficha. El
  navegador ignoraba el formulario de borrado. Solucionado sin formularios
  anidados.
- Añadida la columna **Apellidos** al listado de clientes (antes solo
  estaba en la ficha), y a la búsqueda/filtros.

## v1.0.1

- Botón **Eliminar** añadido también dentro de la propia ficha del
  cliente (antes solo estaba el icono en el listado).
- Corregido el CSS para que el navegador no sirva una versión antigua en
  caché tras cada actualización (añadida versión al fichero de estilos).
- Revisado de nuevo el ajuste de ancho de ventana y el desbordamiento del
  código postal — si lo sigues viendo igual tras instalar esta versión,
  probablemente sea la caché del navegador: haz Ctrl+F5 en la página.

## v1.0.0

Primera versión empaquetada. Incluye:

- **Clientes**: alta, edición, borrado y búsqueda. Campos: Nombre,
  Apellidos, Contacto, NIF, Teléfono, Dirección, Población, Provincia,
  Código postal, Email, Fecha de nacimiento, Notas.
- El borrado de un cliente se bloquea si tiene ficha óptica, ventas o
  facturas asociadas (esos módulos aún no existen, así que por ahora no
  bloquea nada; se activará solo en cuanto se construyan).
- **Usuarios y login**: acceso con usuario/contraseña, gestión de usuarios
  solo para administradores.
- **Interfaz**: menú lateral con las mismas secciones que el programa de
  referencia (Clientes, Ventas, Ficheros, Almacén, Compras, Contabilidad,
  Configuración) con icono por sección; solo Clientes y Usuarios (dentro
  de Ficheros) funcionan, el resto son fases futuras. Colores en tonos
  pastel verde/marrón, contenido adaptable al ancho de la ventana.
- **Instalación**: `instalar_todo.bat` instala XAMPP si falta, copia la
  app, crea la base de datos y el acceso directo del escritorio con icono
  propio. `reparar_bd.bat` para arreglar una base de datos dañada.
- Tecnología: PHP + MySQL/MariaDB (pensado para subir por FTP a hosting),
  probado en local con XAMPP.
## v1.0.60

- PDF de listados: tipografía base más legible, orientación apaisada automática en listados anchos, cálculo adaptativo de columnas y recorte seguro con `...`.
- Excel y CSV: descargas limpiadas de cualquier salida previa, codificación UTF-8 correcta y Excel compatible mediante tabla HTML.
## v1.0.61

- Corregida la caja de recorte vertical del motor PDF: las letras ya no aparecen amputadas ni convertidas en fragmentos o puntos.
- Se mantiene el recorte horizontal por columna y los puntos suspensivos para valores largos.
## v1.0.62

- PDF: anchos configurados por número de caracteres para Nº, Cliente, CIF/NIF, teléfono, población y fecha.
- Separación uniforme de tres espacios entre columnas y alineación acumulativa desde la izquierda.
- El resto de columnas mantiene el cálculo adaptativo y el recorte `...`.
## v1.0.63

- Ampliada la columna Producto en los históricos de la ficha del cliente (aprox. el doble), con adaptación a nombres largos y ajuste en varias líneas.
- Precio, fecha y acciones conservan tamaños compactos; la tabla mantiene desplazamiento horizontal en pantallas estrechas.
## v1.0.64

- Unificado el estilo de botones: eliminados los rellenos de color, incluidos hover, foco, pulsación y estados primarios/secundarios.
- Se conservan iconos, texto, borde y estados de desactivado.
## v1.0.65

- Ajuste final de listados PDF: dos dígitos de separación entre columnas.
- Se mantienen los anchos configurados para Nº, Cliente, CIF/NIF, teléfono, población y fecha.
- Las columnas siguen acumulándose desde la izquierda y los valores largos se truncan con `...` sin invadir la columna siguiente.
## v1.0.66

- Corregida la visibilidad de los botones sin relleno: texto e iconos oscuros y borde exterior visible.
- Añadido estado de foco/hover sin fondo; los botones de peligro mantienen color rojo.
## v1.0.67

- Integrados los cambios acumulados de interfaz y fichas: título “Ficha Cliente” en una línea, texto “Histórico de ventas” simplificado y controles de búsqueda compactos.
- Consolidada la apariencia de botones sin relleno, conservando texto, iconos y bordes visibles.
- Incluye las mejoras acumuladas de listados PDF, Excel/CSV y columna Producto.
## v1.0.68

- Las filas de Clientes, Almacén e Inventario se abren con un clic en cualquier zona de la línea, salvo controles interactivos.
- Corregida la altura desbocada del buscador de Inventario.
- Incluidos todos los ajustes acumulados de fichas, listados PDF/Excel/CSV, botones y fichas de cliente.
## v1.0.69

- Selección contextual en listados: último registro visitado en rojo suave y registro de origen en morado suave cuando se navega con Anterior/Siguiente.
- Conservación del origen, filtros, página y URL de retorno durante la navegación de Clientes y Artículos.
- Los controles interactivos de las filas no disparan aperturas accidentales.
## v1.0.70

- Corregido el significado de los resaltados: registro inicial en rojo suave y último registro visitado en morado suave.
- Ambos registros permanecen marcados al volver al listado; si no hubo navegación, solo aparece el origen en rojo.
## v1.0.71

- Ajustado el retorno de listados para mostrar siempre los dos registros cuando se navega dentro de una ficha.
- Registro inicial en rojo suave y último registro visitado en morado suave.
- Cuando es necesario, se muestra el conjunto completo filtrado para garantizar que ambos registros sean visibles.
## v1.0.72

- Reforzado el resaltado de listados: entrada inicial roja y último registro visitado morado, aplicados sobre fila y celdas.
- Protegidos los listados frente a colapsos por memorias de columnas inválidas, conservando ancho mínimo y desplazamiento horizontal.
- Verificado el paso de origen y registro visitado en Clientes y Artículos durante Anterior/Siguiente y Volver.
## v1.0.78
- Sustituido el icono de portada e instalación por el `.ico` facilitado, sin alterar sus proporciones.
- La portada centra el icono mediante `object-fit: contain`, evitando cualquier deformación.
- Unificado el menú lateral de la portada y el resto del programa.
- Añadido acceso permanente a Inicio en el menú lateral.
- Sustituidos los iconos del menú por una familia SVG uniforme y más profesional.

## v1.0.77
- Integrada la nueva portada de inicio de Cloud Opticas en `inicio.php`.
- El lanzador y el acceso tras iniciar sesión abren ahora la portada.
- Incorporado el logotipo PNG de la portada y generado el icono Windows `.ico`.
- El instalador copia el icono al directorio instalado y lo usa en el acceso directo del escritorio.

## v1.0.76
- Optimizado el retorno desde las fichas para no cargar todo el listado al recuperar los registros resaltados.
- Eliminadas las columnas de lupa y aspa de Clientes y Artículos.
- La ficha se abre mediante doble clic en cualquier zona de la fila.
- El borrado desde el listado se mantiene mediante selección individual o múltiple.

## v1.0.75
- Se consolida la reorganización de la ficha de artículos con el campo Número.
- Se mantiene Activo marcado por defecto en las altas de artículos.
- Se corrige la alineación de filtros con las columnas Delegación en Clientes y Artículos.

## v1.0.74
- Añadida una barra verde de actividad junto al botón de backup con el texto `Volcando base de datos`.
- Añadida una barra verde de actividad junto al botón de restauración con el texto `Restaurando Base de Datos`.
- El botón en ejecución queda temporalmente desactivado para impedir envíos duplicados.

## v1.0.73
- Se conserva de forma independiente el registro de entrada (`origen`) y el último registro visitado (`resaltar`) en todas las navegaciones de fichas de cliente.
- Al volver al listado se muestran simultáneamente entrada en rojo suave y salida en morado suave.
- Se restaura la distribución normal de las cabeceras eliminando las reglas CSS que podían comprimirlas.
- Se renueva la clave de anchos guardados para descartar configuraciones antiguas deformadas.
