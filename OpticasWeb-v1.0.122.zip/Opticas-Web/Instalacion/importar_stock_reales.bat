@echo off
setlocal
cd /d "%~dp0."
set XAMPP_DIR=C:\xampp

echo ================================================
echo   Importar stock por almacen (Carmona / Tocina)
echo ================================================
echo.
echo Rellena la pestana "Existencias" de cada articulo con el stock
echo real por almacen, tomado del backup.
echo.
echo Solo afecta a la tabla de existencias por almacen; NO toca
echo articulos, clientes ni ningun otro dato.
echo.
set /p CONFIRMAR="Escribe SI en mayusculas para continuar: "
if not "%CONFIRMAR%"=="SI" (
    echo Cancelado, no se ha tocado nada.
    pause
    exit /b 0
)

if not exist "%XAMPP_DIR%\mysql\bin\mysql.exe" (
    echo No encuentro MySQL en "%XAMPP_DIR%".
    pause
    exit /b 1
)

echo Importando...
"%XAMPP_DIR%\mysql\bin\mysql.exe" -u root --default-character-set=utf8mb4 < "%~dp0importar_stock_reales.sql"

if errorlevel 1 (
    echo.
    echo Ha fallado. Copia el mensaje de error y avisame.
    pause
    exit /b 1
)
echo.
echo ================================================
echo   Stock importado correctamente
echo ================================================
pause
