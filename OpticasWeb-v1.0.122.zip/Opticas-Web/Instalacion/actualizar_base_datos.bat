@echo off
setlocal EnableExtensions EnableDelayedExpansion
cd /d "%~dp0."
set "XAMPP_DIR=C:\xampp"
set "MYSQL_EXE=%XAMPP_DIR%\mysql\bin\mysql.exe"
set "MYSQLD_EXE=%XAMPP_DIR%\mysql\bin\mysqld.exe"
set "MYSQL_INI=%XAMPP_DIR%\mysql\bin\my.ini"

 echo ================================================
 echo   Cloud Opticas v1.0.110 - Actualizar base de datos
 echo ================================================
 echo.
 echo Esta actualizacion:
 echo  - crea una copia de seguridad antes de tocar nada;
 echo  - aplica las migraciones de estructura pendientes;
 echo  - corrige UNA SOLA VEZ la asignacion heredada de delegaciones;
 echo  - rellena campos heredados que quedaron incompletos;
 echo  - reconstruye el stock por almacen con los datos reales.
 echo  - habilita Proveedores, Compras historicas y Ventas Cliente.
 echo.
 pause

if not exist "%MYSQL_EXE%" (
    echo No encuentro MySQL en "%XAMPP_DIR%". Revisa que XAMPP este instalado ahi.
    pause
    exit /b 1
)

call :asegurar_mysql
if errorlevel 1 exit /b 1

for /f %%i in ('powershell -NoProfile -Command "Get-Date -Format yyyyMMdd_HHmmss"') do set "TS=%%i"
if not exist "%~dp0backups" mkdir "%~dp0backups"
set "BACKUP=%~dp0backups\gestion_optica_antes_v1.0.59_%TS%.sql"

echo.
echo Creando copia de seguridad...
"%XAMPP_DIR%\mysql\bin\mysqldump.exe" --protocol=tcp -h 127.0.0.1 -P 3306 -u root --default-character-set=utf8mb4 --routines --triggers gestion_optica > "%BACKUP%"
if errorlevel 1 (
    echo.
    echo ERROR: no se pudo crear la copia de seguridad.
    echo No se aplicara ninguna actualizacion.
    if exist "%BACKUP%" del "%BACKUP%" >nul 2>nul
    pause
    exit /b 1
)
echo Copia guardada en:
echo   %BACKUP%

echo.
echo Aplicando actualizaciones...
"%MYSQL_EXE%" --protocol=tcp -h 127.0.0.1 -P 3306 -u root --default-character-set=utf8mb4 --force < "%~dp0actualizar_bd_todo.sql"
if errorlevel 1 (
    echo.
    echo La actualizacion termino con errores. Conserva la copia de seguridad
    echo indicada arriba y revisa los mensajes mostrados.
    pause
    exit /b 1
)

if exist "%~dp0importar_operativa_historica_v1.0.53.sql" (
    echo Importando operativa historica v1.0.53...
    "%MYSQL_EXE%" --protocol=tcp -h 127.0.0.1 -P 3306 -u root --default-character-set=utf8mb4 < "%~dp0importar_operativa_historica_v1.0.53.sql"
    if errorlevel 1 (
        echo ERROR: fallo la importacion historica v1.0.53.
        pause
        exit /b 1
    )
)

echo.
echo ================================================
echo   Base de datos actualizada a v1.0.110
echo ================================================
echo Ya puedes abrir Cloud Opticas normalmente.
echo.
pause
exit /b 0

:asegurar_mysql
echo Comprobando MySQL...
"%MYSQL_EXE%" --protocol=tcp -h 127.0.0.1 -P 3306 -u root -e "SELECT 1" >nul 2>nul
if not errorlevel 1 (
    echo MySQL ya esta listo.
    exit /b 0
)

echo Arrancando MySQL de XAMPP...
start "MySQLXAMPP" /min "%MYSQLD_EXE%" --defaults-file="%MYSQL_INI%"

echo Esperando a que MySQL acepte conexiones...
for /L %%I in (1,1,45) do (
    "%MYSQL_EXE%" --protocol=tcp -h 127.0.0.1 -P 3306 -u root -e "SELECT 1" >nul 2>nul
    if not errorlevel 1 (
        echo MySQL listo.
        exit /b 0
    )
    echo   intento %%I de 45...
    timeout /t 1 /nobreak >nul
)

echo.
echo ERROR: MySQL no ha quedado listo despues de 45 segundos.
echo.
echo Diagnostico rapido:
netstat -ano | findstr ":3306" || echo   Puerto 3306 sin escucha detectada.
echo.
echo Abre XAMPP Control Panel y revisa si MySQL aparece en rojo o si otro servicio
echo ocupa el puerto 3306. Si root tiene contrasena, hay que adaptar este script.
echo.
if exist "%XAMPP_DIR%\mysql\data\mysql_error.log" (
    echo Ultimas lineas del log de MySQL:
    powershell -NoProfile -Command "Get-Content '%XAMPP_DIR%\mysql\data\mysql_error.log' -Tail 20"
)
pause
exit /b 1
