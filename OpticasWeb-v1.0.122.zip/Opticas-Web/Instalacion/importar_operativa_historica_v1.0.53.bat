@echo off
setlocal EnableExtensions
cd /d "%~dp0"
set "MYSQL_EXE=C:\xampp\mysql\bin\mysql.exe"
if not exist "%MYSQL_EXE%" (
  echo ERROR: no encuentro MySQL de XAMPP.
  pause
  exit /b 1
)
echo Importando proveedores, compras historicas y ventas de clientes...
"%MYSQL_EXE%" --protocol=tcp -h 127.0.0.1 -P 3306 -u root --default-character-set=utf8mb4 < "%~dp0importar_operativa_historica_v1.0.53.sql"
if errorlevel 1 (
  echo ERROR durante la importacion historica.
  pause
  exit /b 1
)
echo Importacion completada.
pause
