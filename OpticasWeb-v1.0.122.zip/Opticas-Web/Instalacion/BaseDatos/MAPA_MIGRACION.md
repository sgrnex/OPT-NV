# Mapa de migración OpticasWeb

La migración se ejecutará de forma incremental y repetible. Las correspondencias se guardan en `migracion_correspondencias` y cada proceso en `migracion_ejecuciones`.

| Origen antiguo | Destino | Tratamiento |
|---|---|---|
| clientes | clientes | Correlación por ID de origen y huella; alta/actualización sin duplicar |
| articulos | articulos | Conversión de nombres, precios, IVA, proveedor y delegación |
| proveedores | proveedores | Alta con `origen` e `origen_id` |
| vendedores | vendedores | Requiere tabla destino operativa |
| doctores | clientes.doctor | Excluir `DOCTOR PRUEBA` |
| opticos | graduaciones.optico | Correlación por nombre |
| pedidos/facturas | ventas | Transformación de cabecera y cliente |
| lineas_pedidos/lineas_facturas | ventas_lineas | Validación de venta y artículo relacionados |
| stock_producto/lineas_inventario | articulos_stock | Consolidación por artículo y delegación |

La escritura sólo podrá comenzar después de crear el backup previo y superar todas las validaciones de relaciones.
