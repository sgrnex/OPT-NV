-- Crea la base de datos y las tablas de "Gestión Óptica".
-- El instalador (instalar_todo.bat) ejecuta este fichero automáticamente
-- contra el MySQL de XAMPP. También puedes ejecutarlo tú a mano desde
-- phpMyAdmin, pestaña SQL, si prefieres hacerlo manualmente.

CREATE DATABASE IF NOT EXISTS gestion_optica CHARACTER SET utf8mb4;
USE gestion_optica;

CREATE TABLE IF NOT EXISTS clientes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(150) NOT NULL,
    apellidos VARCHAR(150),
    contacto VARCHAR(150),
    nif VARCHAR(20),
    telefono VARCHAR(30),
    direccion VARCHAR(150),
    poblacion VARCHAR(100),
    provincia VARCHAR(100),
    codigo_postal VARCHAR(10),
    email VARCHAR(150),
    fecha_nacimiento DATE NULL,
    telefono2 VARCHAR(30),
    movil VARCHAR(30),
    profesion VARCHAR(100),
    tarjeta_cliente VARCHAR(50),
    descuento DECIMAL(5,2) DEFAULT 0,
    cuenta_contable VARCHAR(20),
    usuario_web VARCHAR(50),
    clave_web VARCHAR(50),
    clasificacion VARCHAR(50),
    tarifa VARCHAR(10) DEFAULT '1',
    doctor VARCHAR(100),
    acepta_mailing_sms TINYINT(1) NOT NULL DEFAULT 0,
    proxima_revision DATE NULL,
    fecha_aviso DATE NULL,
    mostrar_aviso TINYINT(1) NOT NULL DEFAULT 0,
    foto VARCHAR(255),
    activo TINYINT(1) NOT NULL DEFAULT 1,
    fecha_modificacion DATE NULL,
    notas TEXT,
    delegacion_id INT NULL,
    fecha_21p DATE NULL,
    historia_21p TEXT,
    biomicroscopia_21p TEXT,
    oftalmoscopia_21p TEXT,
    resto_21p TEXT,
    diagnostico_21p TEXT,
    queratometria_od VARCHAR(20),
    queratometria_oi VARCHAR(20),
    audifono_od_fecha DATE NULL,
    audifono_od_marca_modelo VARCHAR(100),
    audifono_od_tipo_pila VARCHAR(30),
    audifono_od_garantia VARCHAR(50),
    audifono_od_importe VARCHAR(20),
    audifono_oi_fecha DATE NULL,
    audifono_oi_marca_modelo VARCHAR(100),
    audifono_oi_tipo_pila VARCHAR(30),
    audifono_oi_garantia VARCHAR(50),
    audifono_oi_importe VARCHAR(20),
    fecha_alta DATE NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS usuarios (
    id INT AUTO_INCREMENT PRIMARY KEY,
    usuario VARCHAR(50) NOT NULL UNIQUE,
    nombre VARCHAR(150) NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    rol ENUM('admin', 'usuario') NOT NULL DEFAULT 'usuario',
    activo TINYINT(1) NOT NULL DEFAULT 1,
    ultimo_acceso DATETIME NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- No hace falta insertar aquí el usuario administrador: la propia
-- aplicación crea automáticamente "admin" / "admin" la primera vez
-- que se conecta y ve la tabla de usuarios vacía.

-- Tablas repetibles de la ficha clínica del cliente (Ficha Gafas,
-- Ficha Lentillas, Audífonos): cada fila es una entrada añadida con el
-- icono "+", como en el programa original.

CREATE TABLE IF NOT EXISTS graduaciones (
    id INT AUTO_INCREMENT PRIMARY KEY,
    cliente_id INT NOT NULL,
    categoria VARCHAR(20) NOT NULL,
    ojo VARCHAR(1) NOT NULL,
    fecha DATE NULL,
    eje VARCHAR(20), cil VARCHAR(20), esf VARCHAR(20), av VARCHAR(20),
    avsin VARCHAR(20), di VARCHAR(20), alt VARCHAR(20), adic VARCHAR(20),
    pris VARCHAR(20), vcor VARCHAR(20), optico VARCHAR(100),
    KEY (cliente_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS graduaciones_productos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    cliente_id INT NOT NULL,
    categoria VARCHAR(20) NOT NULL,
    ojo VARCHAR(1) NOT NULL,
    fecha DATE NULL,
    producto VARCHAR(150), precio VARCHAR(20),
    KEY (cliente_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS monturas (
    id INT AUTO_INCREMENT PRIMARY KEY,
    cliente_id INT NOT NULL,
    fecha DATE NULL, descripcion VARCHAR(150), precio VARCHAR(20),
    KEY (cliente_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS gafas_sol (
    id INT AUTO_INCREMENT PRIMARY KEY,
    cliente_id INT NOT NULL,
    fecha DATE NULL, descripcion VARCHAR(150), precio VARCHAR(20),
    KEY (cliente_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS lentillas_con_gafas (
    id INT AUTO_INCREMENT PRIMARY KEY,
    cliente_id INT NOT NULL,
    ojo VARCHAR(1) NOT NULL,
    fecha DATE NULL, eje VARCHAR(20), cil VARCHAR(20), esf VARCHAR(20),
    av VARCHAR(20), avsin VARCHAR(20),
    KEY (cliente_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS lentillas_prueba (
    id INT AUTO_INCREMENT PRIMARY KEY,
    cliente_id INT NOT NULL,
    ojo VARCHAR(1) NOT NULL,
    fecha DATE NULL, eje VARCHAR(20), cil VARCHAR(20), esf VARCHAR(20),
    radio VARCHAR(20), potencia VARCHAR(20), diametro VARCHAR(20), adicion VARCHAR(20),
    KEY (cliente_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS lentillas_definitivas (
    id INT AUTO_INCREMENT PRIMARY KEY,
    cliente_id INT NOT NULL,
    ojo VARCHAR(1) NOT NULL,
    fecha DATE NULL, eje VARCHAR(20), cil VARCHAR(20), esf VARCHAR(20),
    radio VARCHAR(20), potencia VARCHAR(20), adicion VARCHAR(20), diametro VARCHAR(20),
    diametro_zo VARCHAR(20), curva VARCHAR(20), espesor VARCHAR(20),
    tipo VARCHAR(50), material VARCHAR(50), formula VARCHAR(50), obs VARCHAR(150),
    KEY (cliente_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS lentillas_revisiones (
    id INT AUTO_INCREMENT PRIMARY KEY,
    cliente_id INT NOT NULL,
    fecha DATE NULL, ojo VARCHAR(1), radio VARCHAR(20), potencia VARCHAR(20),
    diametro VARCHAR(20), observaciones VARCHAR(200),
    KEY (cliente_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS audiometrias (
    id INT AUTO_INCREMENT PRIMARY KEY,
    cliente_id INT NOT NULL,
    tipo VARCHAR(10) NOT NULL,
    oido VARCHAR(1) NOT NULL,
    fecha DATE NULL,
    hz125 VARCHAR(10), hz250 VARCHAR(10), hz500 VARCHAR(10), hz750 VARCHAR(10),
    hz1000 VARCHAR(10), hz1500 VARCHAR(10), hz2000 VARCHAR(10), hz3000 VARCHAR(10),
    hz4000 VARCHAR(10), hz6000 VARCHAR(10), hz8000 VARCHAR(10), haic VARCHAR(10),
    KEY (cliente_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS delegaciones (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL,
    direccion VARCHAR(150),
    telefono VARCHAR(30),
    email VARCHAR(150)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Convención fija de delegaciones/almacenes de la aplicación.
-- INSERT IGNORE conserva cualquier dato ya configurado si se ejecuta sobre una BBDD existente.
INSERT IGNORE INTO delegaciones (id, nombre) VALUES
    (1, 'Carmona'),
    (2, 'Tocina');

CREATE TABLE IF NOT EXISTS marcas (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS articulos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    codigo VARCHAR(20),
    referencia VARCHAR(20),
    nombre VARCHAR(150),
    codigo_barras VARCHAR(20),
    marca_id INT NULL,
    coste DECIMAL(12,2) DEFAULT 0,
    pvp DECIMAL(12,2) DEFAULT 0,
    existencias DECIMAL(12,2) DEFAULT 0,
    activo TINYINT(1) NOT NULL DEFAULT 1,
    delegacion_id INT NULL,
    fecha_alta DATE NULL,
    fecha_modificacion DATE NULL,
    tipo_articulo VARCHAR(40) DEFAULT 'Artículo',
    calibre VARCHAR(30),
    color VARCHAR(50),
    material VARCHAR(50),
    sexo VARCHAR(2),
    modelo VARCHAR(50),
    proveedor VARCHAR(100),
    casa VARCHAR(100),
    codigo_fabricante VARCHAR(50),
    -- Tarifas
    tipo_margen VARCHAR(20) DEFAULT 'ARTICULO',
    calculo_margen VARCHAR(20) DEFAULT 'COSTO',
    tipo_calculo VARCHAR(40) DEFAULT 'SOBRE PRECIO DE COSTE',
    actualiza_pvp TINYINT(1) DEFAULT 0,
    margen1 DECIMAL(8,2) DEFAULT 0, margen2 DECIMAL(8,2) DEFAULT 0, margen3 DECIMAL(8,2) DEFAULT 0,
    margen4 DECIMAL(8,2) DEFAULT 0, margen5 DECIMAL(8,2) DEFAULT 0,
    impuesto DECIMAL(5,2) DEFAULT 21, tasa DECIMAL(8,2) DEFAULT 0, peso DECIMAL(8,2) DEFAULT 0, portes DECIMAL(8,2) DEFAULT 0,
    pvp2 DECIMAL(12,2) DEFAULT 0, pvp3 DECIMAL(12,2) DEFAULT 0, pvp4 DECIMAL(12,2) DEFAULT 0, pvp5 DECIMAL(12,2) DEFAULT 0,
    costo_medio DECIMAL(12,2) DEFAULT 0, ultimo_precio_compra DECIMAL(12,2) DEFAULT 0,
    margen_minimo DECIMAL(8,2) DEFAULT 0, precio_minimo DECIMAL(12,2) DEFAULT 0,
    cuenta_venta VARCHAR(20), cuenta_compra VARCHAR(20),
    -- Existencias
    inventariable TINYINT(1) DEFAULT 1,
    -- Observaciones / Web
    observaciones TEXT,
    publicar_web TINYINT(1) DEFAULT 0,
    detalle_web TEXT,
    KEY (marca_id),
    KEY (delegacion_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS articulos_stock (
    id INT AUTO_INCREMENT PRIMARY KEY,
    articulo_id INT NOT NULL,
    delegacion_id INT NULL,
    stock DECIMAL(12,2) DEFAULT 0,
    stock_maximo DECIMAL(12,2) DEFAULT 0,
    stock_minimo DECIMAL(12,2) DEFAULT 0,
    entradas DECIMAL(12,2) DEFAULT 0,
    salidas DECIMAL(12,2) DEFAULT 0,
    KEY (articulo_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS articulos_compras (
    id INT AUTO_INCREMENT PRIMARY KEY,
    articulo_id INT NOT NULL,
    fecha DATE NULL,
    empresa VARCHAR(100),
    documento VARCHAR(50),
    proveedor VARCHAR(100),
    cantidad DECIMAL(12,2) DEFAULT 0,
    precio DECIMAL(12,2) DEFAULT 0,
    KEY (articulo_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS articulos_campos_extra (
    id INT AUTO_INCREMENT PRIMARY KEY,
    articulo_id INT NOT NULL,
    nombre VARCHAR(100),
    valor VARCHAR(255),
    KEY (articulo_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================
-- v1.0.53 - Proveedores, compras históricas y ventas de cliente
-- ============================================================
CREATE TABLE IF NOT EXISTS proveedores (
    id INT AUTO_INCREMENT PRIMARY KEY,
    origen VARCHAR(30) NULL,
    origen_id INT NULL,
    nombre VARCHAR(150) NOT NULL,
    nif VARCHAR(20) NULL,
    direccion VARCHAR(150) NULL,
    codigo_postal VARCHAR(15) NULL,
    poblacion VARCHAR(100) NULL,
    provincia VARCHAR(100) NULL,
    pais VARCHAR(80) NULL,
    contacto VARCHAR(100) NULL,
    telefono VARCHAR(30) NULL,
    telefono2 VARCHAR(30) NULL,
    movil VARCHAR(30) NULL,
    fax VARCHAR(30) NULL,
    email VARCHAR(150) NULL,
    website VARCHAR(150) NULL,
    observaciones TEXT NULL,
    descuento DECIMAL(8,2) NOT NULL DEFAULT 0,
    forma_pago_id INT NULL,
    banco VARCHAR(100) NULL,
    recargo DECIMAL(8,2) NOT NULL DEFAULT 0,
    usuario_web VARCHAR(80) NULL,
    clave_web VARCHAR(80) NULL,
    cuenta_contable VARCHAR(30) NULL,
    iva INT NULL,
    fecha_alta DATE NULL,
    fecha_ultima_compra DATE NULL,
    fecha_baja DATE NULL,
    fecha_modificacion DATE NULL,
    iban VARCHAR(50) NULL,
    producto VARCHAR(100) NULL,
    delegacion_id INT NULL,
    activo TINYINT(1) NOT NULL DEFAULT 1,
    UNIQUE KEY uq_proveedor_origen (origen, origen_id),
    KEY idx_proveedor_nombre (nombre),
    KEY idx_proveedor_delegacion (delegacion_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS ventas (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    origen VARCHAR(30) NOT NULL DEFAULT 'APP',
    origen_id BIGINT NULL,
    numero INT NULL,
    serie INT NULL,
    cliente_id INT NULL,
    fecha DATE NULL,
    subtotal DECIMAL(14,2) NOT NULL DEFAULT 0,
    descuento DECIMAL(14,2) NOT NULL DEFAULT 0,
    portes DECIMAL(14,2) NOT NULL DEFAULT 0,
    total DECIMAL(14,2) NOT NULL DEFAULT 0,
    entrega DECIMAL(14,2) NOT NULL DEFAULT 0,
    vuelta DECIMAL(14,2) NOT NULL DEFAULT 0,
    pagado DECIMAL(14,2) NOT NULL DEFAULT 0,
    cobrado TINYINT(1) NOT NULL DEFAULT 0,
    forma_pago_id INT NULL,
    vendedor_id INT NULL,
    delegacion_id INT NULL,
    observaciones TEXT NULL,
    fecha_alta DATETIME NULL,
    fecha_modificacion DATETIME NULL,
    UNIQUE KEY uq_venta_origen (origen, origen_id),
    KEY idx_ventas_cliente_fecha (cliente_id, fecha),
    KEY idx_ventas_delegacion (delegacion_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS ventas_lineas (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    venta_id BIGINT NOT NULL,
    origen VARCHAR(30) NOT NULL DEFAULT 'APP',
    origen_linea_id BIGINT NULL,
    articulo_id INT NULL,
    codigo VARCHAR(30) NULL,
    nombre VARCHAR(150) NULL,
    cantidad DECIMAL(14,3) NOT NULL DEFAULT 0,
    precio DECIMAL(14,2) NOT NULL DEFAULT 0,
    dto1 DECIMAL(10,2) NOT NULL DEFAULT 0,
    dto2 DECIMAL(10,2) NOT NULL DEFAULT 0,
    importe DECIMAL(14,2) NOT NULL DEFAULT 0,
    iva DECIMAL(8,2) NOT NULL DEFAULT 0,
    almacen_id INT NULL,
    observaciones TEXT NULL,
    UNIQUE KEY uq_venta_linea_origen (origen, origen_linea_id),
    KEY idx_ventas_lineas_venta (venta_id),
    KEY idx_ventas_lineas_articulo (articulo_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS articulos_compras (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    articulo_id INT NOT NULL,
    fecha DATE NULL,
    empresa VARCHAR(100) NULL,
    documento VARCHAR(80) NULL,
    proveedor VARCHAR(150) NULL,
    cantidad DECIMAL(12,2) DEFAULT 0,
    precio DECIMAL(12,2) DEFAULT 0,
    importe DECIMAL(14,2) DEFAULT 0,
    tipo_documento VARCHAR(30) NULL,
    documento_id BIGINT NULL,
    proveedor_id INT NULL,
    origen VARCHAR(40) NULL,
    origen_linea_id BIGINT NULL,
    observaciones TEXT NULL,
    KEY idx_articulos_compras_articulo (articulo_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

ALTER TABLE articulos_compras
    ADD COLUMN IF NOT EXISTS importe DECIMAL(14,2) DEFAULT 0,
    ADD COLUMN IF NOT EXISTS tipo_documento VARCHAR(30) NULL,
    ADD COLUMN IF NOT EXISTS documento_id BIGINT NULL,
    ADD COLUMN IF NOT EXISTS proveedor_id INT NULL,
    ADD COLUMN IF NOT EXISTS origen VARCHAR(40) NULL,
    ADD COLUMN IF NOT EXISTS origen_linea_id BIGINT NULL,
    ADD COLUMN IF NOT EXISTS observaciones TEXT NULL;


