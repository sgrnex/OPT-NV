@echo off
setlocal
cd /d "%~dp0."
set XAMPP_DIR=C:\xampp

echo ================================================
echo   Importar Ficha Gafas / Lentillas / Audifonos reales
echo ================================================
echo.
echo ATENCION: esto BORRA los datos que tengas ahora mismo en Ficha
echo Gafas, Ficha Lentillas y Audifonos, y los sustituye por los datos
echo reales del backup (30.650 graduaciones, 17.740 monturas, 34.657
echo cristales/productos, 1.745 registros de lentillas, 3 audiometrias).
echo.
echo IMPORTANTE: ejecuta primero importar_clientes_reales.bat si no lo
echo has hecho ya, porque estos datos se enganchan a esos clientes.
echo.
set /p CONFIRMAR="Escribe SI en mayusculas para continuar: "
if not "%CONFIRMAR%"=="SI" (
    echo Cancelado, no se ha tocado nada.
    pause
    exit /b 0
)

if not exist "%XAMPP_DIR%\mysql\bin\mysql.exe" (
    echo No encuentro MySQL en "%XAMPP_DIR%". Revisa que XAMPP esta instalado ahi.
    pause
    exit /b 1
)

echo.
echo Importando (puede tardar un par de minutos, es bastante volumen)...
"%XAMPP_DIR%\mysql\bin\mysql.exe" -u root --default-character-set=utf8mb4 < "%~dp0importar_ficha_optica_reales.sql"

if errorlevel 1 (
    echo.
    echo Algo ha fallado durante la importacion. Copia el mensaje de
    echo error de arriba y avisame.
    pause
    exit /b 1
)

echo.
echo ================================================
echo   Importacion completada
echo ================================================
pause
