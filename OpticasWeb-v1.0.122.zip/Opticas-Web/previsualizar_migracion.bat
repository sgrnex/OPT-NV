@echo off
setlocal EnableExtensions
title Cloud Opticas - Previsualizacion de migracion
cd /d "%~dp0"
set "MYSQL=C:\xampp\mysql\bin\mysql.exe"
set "DB=opticasweb_migracion_prueba"
set "REPORT=Aplicacion\Backups_Local\Previsualizacion_Migracion.txt"
if not exist "%MYSQL%" (echo ERROR: No se encontro MySQL&pause&exit /b 1)
"%MYSQL%" -uroot -N -B "%DB%" -e "SELECT 1" >nul 2>&1 || (echo ERROR: Prepara primero la base temporal&pause&exit /b 2)
if not exist "Aplicacion\Backups_Local" mkdir "Aplicacion\Backups_Local"
"%MYSQL%" -uroot "%DB%" -e "DROP TABLE IF EXISTS migracion_previsualizacion; CREATE TABLE migracion_previsualizacion (id int auto_increment primary key, tabla_origen varchar(100), tabla_destino varchar(100), registros int unsigned, estado varchar(20), detalle varchar(255));" >nul 2>&1
"%MYSQL%" -uroot "%DB%" -e "DROP TABLE IF EXISTS migracion_vendedores_destino; CREATE TABLE migracion_vendedores_destino AS SELECT * FROM vendedores WHERE 1=0; DROP TABLE IF EXISTS migracion_opticos_destino; CREATE TABLE migracion_opticos_destino AS SELECT * FROM opticos WHERE 1=0;" >nul 2>&1
call :add clientes clientes actualizar "Correlacion por identificador y datos de contacto"
call :add articulos articulos actualizar "Correlacion por referencia EAN"
call :add proveedores proveedores insertar "Altas y coincidencias por CIF nombre"
call :add vendedores migracion_vendedores_destino insertar "Destino staging creado y listo para validar nombre"
call :add doctores clientes.doctor omitir "Se excluye DOCTOR PRUEBA"
call :add opticos migracion_opticos_destino insertar "Destino staging creado; relacion por nombre pendiente de aplicar"
call :add pedidos ventas insertar "Transformar cabecera y validar cliente"
call :add lineas_pedidos ventas_lineas insertar "Validar pedido y articulo"
call :add facturas ventas insertar "Transformar cabecera y validar cliente"
call :add lineas_facturas ventas_lineas insertar "Validar factura y articulo"
call :add pedidos_compra compras insertar "Transformar cabecera"
call :add lineas_pedidos_compra articulos_compras insertar "Validar compra y articulo"
call :add lineas_inventario articulos_stock actualizar "Validar articulo y cantidad"
(
 echo CLOUD OPTICAS - PREVISUALIZACION DE MIGRACION
 echo Fecha: %date% %time%
 echo Base: %DB%
 echo Estados: INSERTAR / ACTUALIZAR / OMITIR / ERROR
 echo.
 echo TABLA ORIGEN ^| DESTINO ^| REGISTROS ^| ESTADO ^| DETALLE
) > "%REPORT%"
"%MYSQL%" -uroot -N -B "%DB%" -e "SELECT tabla_origen,tabla_destino,registros,UPPER(estado),detalle FROM migracion_previsualizacion ORDER BY id;" >> "%REPORT%"
echo Previsualizacion completada: %CD%\%REPORT%
start "" notepad.exe "%CD%\%REPORT%"
pause
exit /b 0

:add
set "SRC=%~1"
set "DST=%~2"
set "STATE=%~3"
set "DETAIL=%~4"
"%MYSQL%" -uroot "%DB%" -e "INSERT INTO migracion_previsualizacion(tabla_origen,tabla_destino,registros,estado,detalle) SELECT '%SRC%','%DST%',COALESCE(table_rows,0),'%STATE%','%DETAIL%' FROM information_schema.tables WHERE table_schema='%DB%' AND table_name='%SRC%';" >nul 2>&1
exit /b 0
