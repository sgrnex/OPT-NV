@echo off
setlocal EnableExtensions
title Cloud Opticas - Migracion de prueba automatica
cd /d "%~dp0"

rem Arrastra un backup SQL sobre este archivo o dejalo en Backups_Local.
if "%~1"=="" (
  call "%~dp0preparar_prueba_migracion.bat"
) else (
  call "%~dp0preparar_prueba_migracion.bat" "%~1"
)
set "RC=%ERRORLEVEL%"
if not "%RC%"=="0" exit /b %RC%

rem Mostrar el informe al finalizar para que no haya que buscarlo manualmente.
set "REPORT=%CD%\Aplicacion\Backups_Local\Informe_Entorno_Migracion.txt"
if not exist "%REPORT%" set "REPORT=%CD%\Backups_Local\Informe_Entorno_Migracion.txt"
if exist "%REPORT%" (
  echo.
  echo Abriendo informe de validacion...
  start "" notepad.exe "%REPORT%"
)
exit /b 0
