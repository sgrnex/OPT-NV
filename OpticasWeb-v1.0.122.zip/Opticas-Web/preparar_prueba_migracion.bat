@echo off
setlocal EnableExtensions EnableDelayedExpansion
title Cloud Opticas - Preparar prueba de migracion
cd /d "%~dp0"

set "MYSQL_DIR=C:\xampp\mysql\bin"
set "MYSQL_EXE=%MYSQL_DIR%\mysql.exe"
set "TEMP_DB=opticasweb_migracion_prueba"
set "DB_USER=root"
set "DB_PASSWORD="

echo.
echo ============================================================
echo   CLOUD OPTICAS - ENTORNO TEMPORAL DE MIGRACION
echo ============================================================
echo   Base temporal: %TEMP_DB%
echo   La base principal gestion_optica NO se modificara.
echo.

if not exist "%MYSQL_EXE%" (
  echo ERROR: No se encontro MySQL en %MYSQL_DIR%.
  echo Instala o inicia XAMPP y vuelve a ejecutar este archivo.
  pause
  exit /b 1
)

set "BACKUP=%~1"
if not defined BACKUP (
  for /f "delims=" %%F in ('dir /b /a-d /o-d "Backup_GestionOptica_*.sql" 2^>nul') do if not defined BACKUP set "BACKUP=%CD%\%%F"
)
if not defined BACKUP (
  for /f "delims=" %%F in ('dir /b /a-d /o-d "Aplicacion\Backups_Local\Backup_GestionOptica_*.sql" 2^>nul') do if not defined BACKUP set "BACKUP=%CD%\Aplicacion\Backups_Local\%%F"
)
if not defined BACKUP (
  echo ERROR: No se encontro una copia Backup_GestionOptica_*.sql.
  echo Arrastra el archivo SQL sobre preparar_prueba_migracion.bat
  echo o copialo junto a este archivo.
  pause
  exit /b 2
)
if not exist "%BACKUP%" (
  echo ERROR: No existe el archivo indicado:
  echo %BACKUP%
  pause
  exit /b 3
)

echo Copia de origen: %BACKUP%
echo.
echo Se reconstruira EXCLUSIVAMENTE la base temporal %TEMP_DB%.
choice /C SN /N /M "Continuar [S/N]? "
if errorlevel 2 exit /b 0

set "AUTH=-u%DB_USER%"
if defined DB_PASSWORD set "AUTH=%AUTH% -p%DB_PASSWORD%"

echo [1/4] Comprobando MySQL...
"%MYSQL_EXE%" %AUTH% -e "SELECT VERSION();" >nul 2>&1
if errorlevel 1 (
  echo ERROR: MySQL no responde. Inicia MySQL desde el panel de XAMPP.
  pause
  exit /b 4
)

echo [2/4] Reconstruyendo la base temporal...
"%MYSQL_EXE%" %AUTH% -e "DROP DATABASE IF EXISTS `%TEMP_DB%`; CREATE DATABASE `%TEMP_DB%` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;"
if errorlevel 1 goto :error

echo [3/4] Preparando e importando la copia...
set "SQL_TEMP=%TEMP%\CloudOpticas_Migracion_%RANDOM%_%RANDOM%.sql"
powershell -NoProfile -ExecutionPolicy Bypass -Command "$in=[IO.File]::OpenText('%BACKUP%'); $out=New-Object IO.StreamWriter('%SQL_TEMP%', $false, (New-Object Text.UTF8Encoding($false))); try { while(($line=$in.ReadLine()) -ne $null){ if($line -notmatch '^\s*(CREATE\s+DATABASE|USE\s+)'){ $out.WriteLine($line) } } } finally { $in.Dispose(); $out.Dispose() }"
if errorlevel 1 (
  echo ERROR: No se pudo preparar el volcado para la base temporal.
  goto :error
)
"%MYSQL_EXE%" %AUTH% --default-character-set=utf8mb4 "%TEMP_DB%" < "%SQL_TEMP%"
set "IMPORT_RC=%ERRORLEVEL%"
del /q "%SQL_TEMP%" >nul 2>&1
if not "%IMPORT_RC%"=="0" goto :error

echo [4/4] Validando tablas principales...
set "REPORT=Aplicacion\Backups_Local\Informe_Entorno_Migracion.txt"
if not exist "Aplicacion\Backups_Local" mkdir "Aplicacion\Backups_Local"
(
  echo CLOUD OPTICAS - ENTORNO TEMPORAL DE MIGRACION
  echo Fecha: %date% %time%
  echo Base: %TEMP_DB%
  echo Backup: %BACKUP%
) > "%REPORT%"
"%MYSQL_EXE%" %AUTH% -N -B "%TEMP_DB%" -e "SELECT table_name, table_rows FROM information_schema.tables WHERE table_schema=DATABASE() ORDER BY table_name;" >> "%REPORT%"
if errorlevel 1 goto :error
set "COUNT_FILE=%TEMP%\CloudOpticas_TableCount_%RANDOM%_%RANDOM%.txt"
"%MYSQL_EXE%" %AUTH% -N -B "%TEMP_DB%" -e "SELECT COUNT(*) FROM information_schema.tables WHERE table_schema=DATABASE();" > "%COUNT_FILE%"
if errorlevel 1 goto :error
set /p TABLE_COUNT=<"%COUNT_FILE%"
del /q "%COUNT_FILE%" >nul 2>&1
if not defined TABLE_COUNT goto :error
if "%TABLE_COUNT%"=="0" (
  echo ERROR: La base temporal no contiene tablas.
  goto :error
)
echo Total de tablas: %TABLE_COUNT%>> "%REPORT%"

echo.
echo Entorno temporal preparado correctamente.
echo Informe: %CD%\%REPORT%
echo La base principal gestion_optica permanece intacta.
pause
exit /b 0

:error
if defined SQL_TEMP if exist "%SQL_TEMP%" del /q "%SQL_TEMP%" >nul 2>&1
if defined COUNT_FILE if exist "%COUNT_FILE%" del /q "%COUNT_FILE%" >nul 2>&1
echo.
echo ERROR: No se pudo preparar el entorno temporal.
echo La base principal gestion_optica no ha sido modificada.
pause
exit /b 10
