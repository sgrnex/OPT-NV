<?php
require __DIR__ . '/includes/auth.php';
requireLogin();
require __DIR__ . '/db.php';

$pdo = obtenerConexion();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['nombre']) && !isset($_POST['editar_id'])) {
        $nombre = trim($_POST['nombre']);
        if ($nombre !== '') {
            $pdo->prepare('INSERT INTO marcas (nombre) VALUES (:n)')->execute(['n' => $nombre]);
        }
    } elseif (isset($_POST['editar_id'])) {
        $nombre = trim($_POST['nombre_editar'] ?? '');
        if ($nombre !== '') {
            $pdo->prepare('UPDATE marcas SET nombre = :n WHERE id = :id')->execute(['n' => $nombre, 'id' => (int) $_POST['editar_id']]);
        }
    } elseif (isset($_POST['borrar_id'])) {
        $id = (int) $_POST['borrar_id'];
        $pdo->prepare('UPDATE articulos SET marca_id = NULL WHERE marca_id = :id')->execute(['id' => $id]);
        $pdo->prepare('DELETE FROM marcas WHERE id = :id')->execute(['id' => $id]);
    }
    header('Location: marcas.php' . (!empty($_GET['q']) ? '?q=' . urlencode($_GET['q']) : ''));
    exit;
}

$q = trim($_GET['q'] ?? '');
$orden = ($_GET['orden'] ?? 'nombre') === 'articulos' ? 'total_articulos' : 'm.nombre';
$dir = strtolower($_GET['dir'] ?? 'asc') === 'desc' ? 'DESC' : 'ASC';

$sql = 'SELECT m.*, (SELECT COUNT(*) FROM articulos a WHERE a.marca_id = m.id) AS total_articulos FROM marcas m WHERE 1=1';
$params = [];
if ($q !== '') { $sql .= ' AND m.nombre LIKE :q'; $params['q'] = "%$q%"; }
$sql .= " ORDER BY $orden $dir";
$stmt = $pdo->prepare($sql); $stmt->execute($params);
$marcas = $stmt->fetchAll();
$total = count($marcas);

$titulo = 'Marcas';
$activo = 'marcas';
require __DIR__ . '/includes/header.php';
?>
<section class="panel panel--estrecha panel--listado">
  <div class="panel--listado__fijo">
  <div class="panel__title-bar"><span class="panel__title-pill">Marcas</span></div>

  <form method="post" class="alta-simple">
    <input class="alta-simple__input" type="text" name="nombre" placeholder="Nombre de la nueva marca..." required>
    <button class="btn btn--primary" type="submit">➕ Añadir</button>
  </form>

  <form method="get" action="marcas.php" class="alta-simple">
    <input class="alta-simple__input" type="text" name="q" value="<?= htmlspecialchars($q) ?>" placeholder="Buscar marca...">
    <button class="btn btn--secondary" type="submit">🔍 Buscar</button>
  <?php if ($q !== ''): ?><a class="btn btn--secondary" href="marcas.php">🧹 Limpiar</a><?php endif; ?>
  </form>
  </div>

  <div class="panel--listado__scroll">
  <table class="data-table data-table--resizable" id="tabla-marcas" data-column-storage-key="opticas:listado:marcas:columnas">
    <thead><tr>
      <th data-col-key="nombre"><a class="th-orden" href="?orden=nombre&dir=<?= $orden==='m.nombre'&&$dir==='ASC'?'desc':'asc' ?><?= $q!==''?'&q='.urlencode($q):'' ?>">Nombre</a></th>
      <th data-col-key="articulos"><a class="th-orden" href="?orden=articulos&dir=<?= $orden==='total_articulos'&&$dir==='ASC'?'desc':'asc' ?><?= $q!==''?'&q='.urlencode($q):'' ?>">Artículos</a></th>
      <th class="col-actions" data-col-key="acciones" data-col-fixed="1"></th>
    </tr></thead>
    <tbody>
      <?php if (empty($marcas)): ?>
        <tr><td colspan="3" class="empty-row">No hay marcas.</td></tr>
      <?php else: foreach ($marcas as $m): ?>
        <tr>
          <td>
            <form method="post" class="inline-edit">
              <input type="hidden" name="editar_id" value="<?= (int) $m['id'] ?>">
              <input type="text" name="nombre_editar" value="<?= htmlspecialchars($m['nombre']) ?>" class="inline-edit__input">
              <button type="submit" class="icon-link" title="Guardar cambio">💾</button>
            </form>
          </td>
          <td><?= (int) $m['total_articulos'] ?></td>
          <td class="col-actions">
            <form method="post" class="inline-form" onsubmit="return confirm('¿Eliminar la marca <?= htmlspecialchars(addslashes($m['nombre'])) ?>?');">
              <input type="hidden" name="borrar_id" value="<?= (int) $m['id'] ?>">
              <button type="submit" class="icon-link icon-link--danger" title="Eliminar">✕</button>
            </form>
          </td>
        </tr>
      <?php endforeach; endif; ?>
    </tbody>
  </table>
  </div>

  <p class="panel__footer"><?= $total ?> marca<?= $total !== 1 ? 's' : '' ?></p>

  <div class="record-form__actions">
    <a class="btn btn--secondary" href="almacen_articulos.php">↩️ Volver a Artículos</a>
  </div>
</section>
<script src="js/listado_columnas.js?v=1056"></script>
<?php require __DIR__ . '/includes/footer.php'; ?>
