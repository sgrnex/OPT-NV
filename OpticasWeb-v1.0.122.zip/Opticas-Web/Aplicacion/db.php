<?php

function obtenerConexion(): PDO
{
    static $pdo = null;

    if ($pdo === null) {
        $config = require __DIR__ . '/config.php';
        $dsn = "mysql:host={$config['host']};dbname={$config['dbname']};charset=utf8mb4";

        $pdo = new PDO($dsn, $config['user'], $config['password'], [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        ]);

        // La navegación nunca crea ni modifica tablas. La estructura se
        // gestiona exclusivamente mediante instalar_todo/actualizar_bd_todo.
    }

    return $pdo;
}

function crearAdminPorDefectoSiHaceFalta(PDO $pdo): void
{
    $total = $pdo->query('SELECT COUNT(*) AS n FROM usuarios')->fetch()['n'];
    if ((int) $total === 0) {
        $pdo->prepare(
            "INSERT INTO usuarios (usuario, nombre, password_hash, rol, activo)
             VALUES ('admin', 'Administrador', :hash, 'admin', 1)"
        )->execute(['hash' => password_hash('admin', PASSWORD_DEFAULT)]);
    }
}

function tablaExiste(PDO $pdo, string $tabla): bool
{
    static $cache = [];
    if (!isset($cache[$tabla])) {
        $stmt = $pdo->prepare(
            'SELECT COUNT(*) AS n FROM information_schema.tables
             WHERE table_schema = DATABASE() AND table_name = :tabla'
        );
        $stmt->execute(['tabla' => $tabla]);
        $cache[$tabla] = ((int) $stmt->fetch()['n']) > 0;
    }
    return $cache[$tabla];
}

// Lista central de tablas que cuelgan de un cliente (todas con una
// columna cliente_id). Se usa tanto para bloquear el borrado como para
// la renumeración de clientes, así solo hay que mantenerla en un sitio.
function tablasConClienteId(): array
{
    return [
        'graduaciones', 'graduaciones_productos', 'monturas', 'gafas_sol',
        'lentillas_con_gafas', 'lentillas_prueba', 'lentillas_definitivas',
        'lentillas_revisiones', 'audiometrias', 'ventas', 'facturas',
    ];
}

// Un cliente no se puede borrar si tiene ficha óptica (graduaciones,
// lentillas, audífonos) o ventas/facturas asociadas. Ventas y Facturas
// todavía no existen (fases futuras), así que esas dos no bloquean nada
// por ahora; en cuanto se creen (con una columna cliente_id) la
// protección entra en marcha sola, sin tocar este fichero.
function clienteTieneRegistrosAsociados(PDO $pdo, int $clienteId): bool
{
    foreach (tablasConClienteId() as $tabla) {
        if (!tablaExiste($pdo, $tabla)) {
            continue;
        }
        $stmt = $pdo->prepare("SELECT COUNT(*) AS n FROM `$tabla` WHERE cliente_id = :id");
        $stmt->execute(['id' => $clienteId]);
        if ((int) $stmt->fetch()['n'] > 0) {
            return true;
        }
    }

    return false;
}


// Red de seguridad: evita errores fatales si se copia una versión nueva de la
// aplicación antes de ejecutar el actualizador. Solo crea tablas ausentes;
// las migraciones completas siguen estando en actualizar_bd_todo.sql.
function asegurarTablasOperativas(PDO $pdo): void
{
    // Las tablas operativas se crean exclusivamente mediante instalador/migraciones.
    // No se ejecutan CREATE TABLE desde una pantalla PHP para evitar conflictos
    // con tablespaces InnoDB huérfanos después de restauraciones/copias.

    $pdo->exec("CREATE TABLE IF NOT EXISTS articulos_campos_extra (
        id INT AUTO_INCREMENT PRIMARY KEY, articulo_id INT NOT NULL,
        nombre VARCHAR(100), valor VARCHAR(255), KEY (articulo_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

    $pdo->exec("CREATE TABLE IF NOT EXISTS proveedores (
        id INT AUTO_INCREMENT PRIMARY KEY, origen VARCHAR(30), origen_id INT,
        nombre VARCHAR(150) NOT NULL, nif VARCHAR(20), direccion VARCHAR(150), codigo_postal VARCHAR(15),
        poblacion VARCHAR(100), provincia VARCHAR(100), pais VARCHAR(80), contacto VARCHAR(100),
        telefono VARCHAR(30), telefono2 VARCHAR(30), movil VARCHAR(30), fax VARCHAR(30), email VARCHAR(150),
        website VARCHAR(150), observaciones TEXT, descuento DECIMAL(8,2) NOT NULL DEFAULT 0,
        forma_pago_id INT, banco VARCHAR(100), recargo DECIMAL(8,2) NOT NULL DEFAULT 0,
        usuario_web VARCHAR(80), clave_web VARCHAR(80), cuenta_contable VARCHAR(30), iva INT,
        fecha_alta DATE, fecha_ultima_compra DATE, fecha_baja DATE, fecha_modificacion DATE,
        iban VARCHAR(50), producto VARCHAR(100), delegacion_id INT, activo TINYINT(1) NOT NULL DEFAULT 1,
        UNIQUE KEY uq_proveedor_origen (origen, origen_id), KEY (nombre), KEY (delegacion_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

    $pdo->exec("CREATE TABLE IF NOT EXISTS ventas (
        id BIGINT AUTO_INCREMENT PRIMARY KEY, origen VARCHAR(30) NOT NULL DEFAULT 'APP', origen_id BIGINT,
        numero INT, serie INT, cliente_id INT, fecha DATE, subtotal DECIMAL(14,2) NOT NULL DEFAULT 0,
        descuento DECIMAL(14,2) NOT NULL DEFAULT 0, portes DECIMAL(14,2) NOT NULL DEFAULT 0,
        total DECIMAL(14,2) NOT NULL DEFAULT 0, entrega DECIMAL(14,2) NOT NULL DEFAULT 0,
        vuelta DECIMAL(14,2) NOT NULL DEFAULT 0, pagado DECIMAL(14,2) NOT NULL DEFAULT 0,
        cobrado TINYINT(1) NOT NULL DEFAULT 0, forma_pago_id INT, vendedor_id INT, delegacion_id INT,
        observaciones TEXT, fecha_alta DATETIME, fecha_modificacion DATETIME,
        UNIQUE KEY uq_venta_origen (origen, origen_id), KEY (cliente_id, fecha), KEY (delegacion_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

    $pdo->exec("CREATE TABLE IF NOT EXISTS ventas_lineas (
        id BIGINT AUTO_INCREMENT PRIMARY KEY, venta_id BIGINT NOT NULL, origen VARCHAR(30) NOT NULL DEFAULT 'APP',
        origen_linea_id BIGINT, articulo_id INT, codigo VARCHAR(30), nombre VARCHAR(150),
        cantidad DECIMAL(14,3) NOT NULL DEFAULT 0, precio DECIMAL(14,2) NOT NULL DEFAULT 0,
        dto1 DECIMAL(10,2) NOT NULL DEFAULT 0, dto2 DECIMAL(10,2) NOT NULL DEFAULT 0,
        importe DECIMAL(14,2) NOT NULL DEFAULT 0, iva DECIMAL(8,2) NOT NULL DEFAULT 0,
        almacen_id INT, observaciones TEXT,
        UNIQUE KEY uq_venta_linea_origen (origen, origen_linea_id), KEY (venta_id), KEY (articulo_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
}
