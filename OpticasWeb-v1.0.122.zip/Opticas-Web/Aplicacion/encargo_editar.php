<?php
// Compatibilidad con los enlaces de la pantalla anterior.
require __DIR__.'/includes/auth.php';
requireLogin();
$id=isset($_GET['id'])&&is_scalar($_GET['id'])?(int)$_GET['id']:0;
header('Location: encargos.php?id='.max(0,$id));
exit;
