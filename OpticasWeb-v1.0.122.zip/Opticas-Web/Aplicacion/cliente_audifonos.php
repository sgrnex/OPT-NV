<?php
require __DIR__ . '/includes/auth.php';
requireLogin();
require __DIR__ . '/db.php';
require __DIR__ . '/includes/grid_repetible.php';

$pdo = obtenerConexion();
$id = (int) ($_GET['id'] ?? 0);

$stmt = $pdo->prepare('SELECT * FROM clientes WHERE id = :id');
$stmt->execute(['id' => $id]);
$cliente = $stmt->fetch();
if (!$cliente) {
    header('Location: index.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['guardar_audifono'])) {
    $pdo->prepare(
        'UPDATE clientes SET
            audifono_od_fecha=:od_fecha, audifono_od_marca_modelo=:od_marca, audifono_od_tipo_pila=:od_pila,
            audifono_od_garantia=:od_garantia, audifono_od_importe=:od_importe,
            audifono_oi_fecha=:oi_fecha, audifono_oi_marca_modelo=:oi_marca, audifono_oi_tipo_pila=:oi_pila,
            audifono_oi_garantia=:oi_garantia, audifono_oi_importe=:oi_importe
         WHERE id=:id'
    )->execute([
        'od_fecha' => $_POST['audifono_od_fecha'] !== '' ? $_POST['audifono_od_fecha'] : null,
        'od_marca' => trim($_POST['audifono_od_marca_modelo'] ?? ''),
        'od_pila' => trim($_POST['audifono_od_tipo_pila'] ?? ''),
        'od_garantia' => trim($_POST['audifono_od_garantia'] ?? ''),
        'od_importe' => trim($_POST['audifono_od_importe'] ?? ''),
        'oi_fecha' => $_POST['audifono_oi_fecha'] !== '' ? $_POST['audifono_oi_fecha'] : null,
        'oi_marca' => trim($_POST['audifono_oi_marca_modelo'] ?? ''),
        'oi_pila' => trim($_POST['audifono_oi_tipo_pila'] ?? ''),
        'oi_garantia' => trim($_POST['audifono_oi_garantia'] ?? ''),
        'oi_importe' => trim($_POST['audifono_oi_importe'] ?? ''),
        'id' => $id,
    ]);
    header("Location: cliente_audifonos.php?id=$id&guardado=1");
    exit;
}

$config = require __DIR__ . '/includes/grids_config.php';
$volver = "cliente_audifonos.php?id=$id";

$esExistente = true;
$titulo = 'Audífonos';
$activo = 'clientes';
$tabActiva = 'audifonos';
require __DIR__ . '/includes/header.php';
?>
<section class="panel">
  <div class="panel__title-bar"><span class="panel__title-pill">Ficha cliente</span><span class="panel__title-cliente"><?= htmlspecialchars(trim(($cliente['nombre'] ?? '') . ' ' . ($cliente['apellidos'] ?? ''))) ?></span></div>
  <?php require __DIR__ . '/includes/ficha_cliente_tabs.php'; ?>

  <?php $formGuardarId = 'form-audifono'; require __DIR__ . '/includes/ficha_acciones.php'; ?>

  <?php if (!empty($_GET['guardado'])): ?>
    <p class="form-ok">Guardado correctamente.</p>
  <?php endif; ?>

  <details class="ficha-seccion" open>
    <summary class="ficha-seccion__titulo">Audiometría Aérea</summary>
    <?php foreach (['D' => 'Oído derecho', 'I' => 'Oído izquierdo'] as $oido => $nombreOido): ?>
      <p class="ficha-seccion__ojo">👂 <?= $nombreOido ?></p>
      <?php pintarGridRepetible($pdo, 'audiometrias', $config['audiometrias']['columnas'],
          ['cliente_id' => $id, 'tipo' => 'aerea', 'oido' => $oido], $volver); ?>
    <?php endforeach; ?>
  </details>

  <details class="ficha-seccion">
    <summary class="ficha-seccion__titulo">Audiometría Ósea</summary>
    <?php foreach (['D' => 'Oído derecho', 'I' => 'Oído izquierdo'] as $oido => $nombreOido): ?>
      <p class="ficha-seccion__ojo">👂 <?= $nombreOido ?></p>
      <?php pintarGridRepetible($pdo, 'audiometrias', $config['audiometrias']['columnas'],
          ['cliente_id' => $id, 'tipo' => 'osea', 'oido' => $oido], $volver); ?>
    <?php endforeach; ?>
  </details>

  <details class="ficha-seccion">
    <summary class="ficha-seccion__titulo">Audífono</summary>
    <form method="post" id="form-audifono" class="record-form">
      <input type="hidden" name="guardar_audifono" value="1">

      <p class="ficha-seccion__ojo">👂 Oído derecho</p>
      <div class="record-form__grid record-form__grid--three">
        <div class="record-form__row">
          <label for="audifono_od_fecha">Fecha</label>
          <input type="date" id="audifono_od_fecha" name="audifono_od_fecha" value="<?= htmlspecialchars($cliente['audifono_od_fecha'] ?? '') ?>">
        </div>
        <div class="record-form__row">
          <label for="audifono_od_marca_modelo">Marca y Modelo</label>
          <input type="text" id="audifono_od_marca_modelo" name="audifono_od_marca_modelo" value="<?= htmlspecialchars($cliente['audifono_od_marca_modelo'] ?? '') ?>">
        </div>
        <div class="record-form__row">
          <label for="audifono_od_tipo_pila">Tipo Pila</label>
          <input type="text" id="audifono_od_tipo_pila" name="audifono_od_tipo_pila" value="<?= htmlspecialchars($cliente['audifono_od_tipo_pila'] ?? '') ?>">
        </div>
      </div>
      <div class="record-form__grid">
        <div class="record-form__row">
          <label for="audifono_od_garantia">Garantía</label>
          <input type="text" id="audifono_od_garantia" name="audifono_od_garantia" value="<?= htmlspecialchars($cliente['audifono_od_garantia'] ?? '') ?>">
        </div>
        <div class="record-form__row">
          <label for="audifono_od_importe">Importe</label>
          <input type="text" id="audifono_od_importe" name="audifono_od_importe" value="<?= htmlspecialchars($cliente['audifono_od_importe'] ?? '') ?>">
        </div>
      </div>

      <p class="ficha-seccion__ojo">👂 Oído izquierdo</p>
      <div class="record-form__grid record-form__grid--three">
        <div class="record-form__row">
          <label for="audifono_oi_fecha">Fecha</label>
          <input type="date" id="audifono_oi_fecha" name="audifono_oi_fecha" value="<?= htmlspecialchars($cliente['audifono_oi_fecha'] ?? '') ?>">
        </div>
        <div class="record-form__row">
          <label for="audifono_oi_marca_modelo">Marca y Modelo</label>
          <input type="text" id="audifono_oi_marca_modelo" name="audifono_oi_marca_modelo" value="<?= htmlspecialchars($cliente['audifono_oi_marca_modelo'] ?? '') ?>">
        </div>
        <div class="record-form__row">
          <label for="audifono_oi_tipo_pila">Tipo Pila</label>
          <input type="text" id="audifono_oi_tipo_pila" name="audifono_oi_tipo_pila" value="<?= htmlspecialchars($cliente['audifono_oi_tipo_pila'] ?? '') ?>">
        </div>
      </div>
      <div class="record-form__grid">
        <div class="record-form__row">
          <label for="audifono_oi_garantia">Garantía</label>
          <input type="text" id="audifono_oi_garantia" name="audifono_oi_garantia" value="<?= htmlspecialchars($cliente['audifono_oi_garantia'] ?? '') ?>">
        </div>
        <div class="record-form__row">
          <label for="audifono_oi_importe">Importe</label>
          <input type="text" id="audifono_oi_importe" name="audifono_oi_importe" value="<?= htmlspecialchars($cliente['audifono_oi_importe'] ?? '') ?>">
        </div>
      </div>

      <div class="record-form__actions">
        <button class="btn btn--primary" type="submit">✅ Guardar</button>
      </div>
    </form>
  </details>

  <div class="record-form__actions">
    <a class="btn btn--secondary" href="<?= htmlspecialchars($volverListado) ?><?= strpos($volverListado, '?') !== false ? '&' : '?' ?>resaltar=<?= (int) $id ?>&origen=<?= (int)($_GET['origen'] ?? $id) ?>">↩️ Volver</a>
  </div>
</section>
<?php require __DIR__ . '/includes/footer.php'; ?>
