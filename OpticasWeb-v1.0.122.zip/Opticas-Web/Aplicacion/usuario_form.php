<?php
require __DIR__ . '/includes/auth.php';
requireAdmin();
require __DIR__ . '/db.php';

$pdo = obtenerConexion();
$id = isset($_GET['id']) ? (int) $_GET['id'] : (isset($_POST['id']) ? (int) $_POST['id'] : null);
$usuario = null;
$error = null;

if ($id) {
    $stmt = $pdo->prepare('SELECT * FROM usuarios WHERE id = :id');
    $stmt->execute(['id' => $id]);
    $usuario = $stmt->fetch();
    if (!$usuario) {
        header('Location: usuarios.php');
        exit;
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nombreUsuario = trim($_POST['usuario'] ?? '');
    $nombre = trim($_POST['nombre'] ?? '');
    $rol = in_array($_POST['rol'] ?? '', ['admin', 'usuario'], true) ? $_POST['rol'] : 'usuario';
    $activo = isset($_POST['activo']) ? 1 : 0;
    $password = $_POST['password'] ?? '';
    $password2 = $_POST['password2'] ?? '';

    if ($nombreUsuario === '' || $nombre === '') {
        $error = 'El usuario y el nombre son obligatorios.';
    } elseif ($password !== $password2) {
        $error = 'Las dos contraseñas no coinciden.';
    } else {
        $stmt = $pdo->prepare('SELECT id FROM usuarios WHERE usuario = :usuario');
        $stmt->execute(['usuario' => $nombreUsuario]);
        $existente = $stmt->fetch();

        if ($existente && (!$id || (int) $existente['id'] !== $id)) {
            $error = 'Ya existe un usuario con ese nombre de acceso.';
        } elseif (!$id && $password === '') {
            $error = 'La contraseña es obligatoria para un usuario nuevo.';
        } else {
            if ($id) {
                if ($password !== '') {
                    $pdo->prepare(
                        'UPDATE usuarios SET usuario=:usuario, nombre=:nombre,
                         password_hash=:hash, rol=:rol, activo=:activo WHERE id=:id'
                    )->execute([
                        'usuario' => $nombreUsuario, 'nombre' => $nombre,
                        'hash' => password_hash($password, PASSWORD_DEFAULT),
                        'rol' => $rol, 'activo' => $activo, 'id' => $id,
                    ]);
                } else {
                    $pdo->prepare(
                        'UPDATE usuarios SET usuario=:usuario, nombre=:nombre,
                         rol=:rol, activo=:activo WHERE id=:id'
                    )->execute([
                        'usuario' => $nombreUsuario, 'nombre' => $nombre,
                        'rol' => $rol, 'activo' => $activo, 'id' => $id,
                    ]);
                }
            } else {
                $pdo->prepare(
                    'INSERT INTO usuarios (usuario, nombre, password_hash, rol, activo)
                     VALUES (:usuario, :nombre, :hash, :rol, :activo)'
                )->execute([
                    'usuario' => $nombreUsuario, 'nombre' => $nombre,
                    'hash' => password_hash($password, PASSWORD_DEFAULT),
                    'rol' => $rol, 'activo' => $activo,
                ]);
            }
            header('Location: usuarios.php');
            exit;
        }
    }
}

$titulo = $usuario ? 'Editar usuario' : 'Nuevo usuario';
$activo_nav = 'usuarios';
$activo = $activo_nav;
require __DIR__ . '/includes/header.php';
?>
<section class="panel panel--estrecha">
  <div class="panel__title-bar"><span class="panel__title-pill"><?= htmlspecialchars($titulo) ?></span></div>

  <?php if ($error): ?>
    <p class="form-error"><?= htmlspecialchars($error) ?></p>
  <?php endif; ?>

  <form method="post" class="record-form">
    <?php if ($usuario): ?><input type="hidden" name="id" value="<?= (int) $usuario['id'] ?>"><?php endif; ?>

    <div class="record-form__row">
      <label for="usuario">Usuario (para entrar)</label>
      <input type="text" id="usuario" name="usuario" required
             value="<?= htmlspecialchars($usuario['usuario'] ?? '') ?>">
    </div>

    <div class="record-form__row">
      <label for="nombre">Nombre completo</label>
      <input type="text" id="nombre" name="nombre" required
             value="<?= htmlspecialchars($usuario['nombre'] ?? '') ?>">
    </div>

    <div class="record-form__grid">
      <div class="record-form__row">
        <label for="password"><?= $usuario ? 'Nueva contraseña (déjalo en blanco para no cambiarla)' : 'Contraseña' ?></label>
        <input type="password" id="password" name="password">
      </div>
      <div class="record-form__row">
        <label for="password2">Repite la contraseña</label>
        <input type="password" id="password2" name="password2">
      </div>
    </div>

    <div class="record-form__grid">
      <div class="record-form__row">
        <label for="rol">Rol</label>
        <select id="rol" name="rol">
          <option value="usuario" <?= (($usuario['rol'] ?? 'usuario') === 'usuario') ? 'selected' : '' ?>>Usuario</option>
          <option value="admin" <?= (($usuario['rol'] ?? '') === 'admin') ? 'selected' : '' ?>>Administrador</option>
        </select>
      </div>
      <div class="record-form__row record-form__row--checkbox">
        <label><input type="checkbox" name="activo" <?= (!$usuario || $usuario['activo']) ? 'checked' : '' ?>> Activo</label>
      </div>
    </div>

    <div class="record-form__actions">
      <a class="btn btn--secondary" href="usuarios.php">↩️ Volver</a>
      <button class="btn btn--primary" type="submit">✅ Guardar</button>
    </div>
  </form>
</section>
<?php require __DIR__ . '/includes/footer.php'; ?>
