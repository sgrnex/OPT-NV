<?php
// Datos de conexión a la base de datos.
//
// En local, con XAMPP recién instalado, estos valores por defecto
// funcionan tal cual (usuario "root" sin contraseña).
//
// Cuando subas la app a tu hosting, cambia SOLO estos 4 valores por los
// que te indique tu proveedor (host, nombre de la base de datos, usuario
// y contraseña de MySQL). El resto de la aplicación no necesita ningún
// otro cambio para funcionar en el hosting.
return [
    'host'     => 'localhost',
    'dbname'   => 'gestion_optica',
    'user'     => 'root',
    'password' => '',
];
