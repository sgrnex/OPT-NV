@echo off
setlocal EnableExtensions EnableDelayedExpansion
title Cloud Opticas v1.0.110
set "XAMPP_DIR=C:\xampp"
set "MYSQL_EXE=%XAMPP_DIR%\mysql\bin\mysql.exe"
set "MYSQLD_EXE=%XAMPP_DIR%\mysql\bin\mysqld.exe"
set "MYSQL_INI=%XAMPP_DIR%\mysql\bin\my.ini"
set "APACHE_EXE=%XAMPP_DIR%\apache\bin\httpd.exe"

if exist "%APACHE_EXE%" (
    tasklist /FI "IMAGENAME eq httpd.exe" 2>nul | find /I "httpd.exe" >nul
    if errorlevel 1 start "ApacheXAMPP" /min "%APACHE_EXE%"
)

if exist "%MYSQL_EXE%" (
    "%MYSQL_EXE%" --protocol=tcp -h 127.0.0.1 -P 3306 -u root -e "SELECT 1" >nul 2>nul
    if errorlevel 1 (
        if exist "%MYSQLD_EXE%" start "MySQLXAMPP" /min "%MYSQLD_EXE%" --defaults-file="%MYSQL_INI%"
        for /L %%I in (1,1,12) do (
            "%MYSQL_EXE%" --protocol=tcp -h 127.0.0.1 -P 3306 -u root -e "SELECT 1" >nul 2>nul
            if not errorlevel 1 goto :abrir
            timeout /t 1 /nobreak >nul
        )
    )
)

:abrir
start "" http://localhost/opticas-php/inicio.php
