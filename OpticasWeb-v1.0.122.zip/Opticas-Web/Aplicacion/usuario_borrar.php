<?php
require __DIR__ . '/includes/auth.php';
requireAdmin();
require __DIR__ . '/db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = (int) ($_POST['id'] ?? 0);
    $pdo = obtenerConexion();

    if ($id !== usuarioActual()['id']) {
        $stmt = $pdo->prepare('SELECT rol FROM usuarios WHERE id = :id');
        $stmt->execute(['id' => $id]);
        $fila = $stmt->fetch();

        if ($fila) {
            $puedeBorrar = true;
            if ($fila['rol'] === 'admin') {
                $total = $pdo->query("SELECT COUNT(*) AS n FROM usuarios WHERE rol = 'admin'")->fetch()['n'];
                if ((int) $total <= 1) {
                    $puedeBorrar = false;
                }
            }
            if ($puedeBorrar) {
                $pdo->prepare('DELETE FROM usuarios WHERE id = :id')->execute(['id' => $id]);
            }
        }
    }
}

header('Location: usuarios.php');
exit;
