<?php
require __DIR__ . '/includes/auth.php';
requireLogin();
require __DIR__ . '/db.php';
require __DIR__ . '/includes/grid_repetible.php';

$pdo = obtenerConexion();
$id = (int) ($_GET['id'] ?? 0);

$stmt = $pdo->prepare('SELECT * FROM clientes WHERE id = :id');
$stmt->execute(['id' => $id]);
$cliente = $stmt->fetch();
if (!$cliente) {
    header('Location: index.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['guardar_queratometria'])) {
    $pdo->prepare('UPDATE clientes SET queratometria_od = :od, queratometria_oi = :oi WHERE id = :id')->execute([
        'od' => trim($_POST['queratometria_od'] ?? ''),
        'oi' => trim($_POST['queratometria_oi'] ?? ''),
        'id' => $id,
    ]);
    header("Location: ficha_lentillas.php?id=$id&guardado=1");
    exit;
}

$config = require __DIR__ . '/includes/grids_config.php';
$volver = "ficha_lentillas.php?id=$id";

$esExistente = true;
$titulo = 'Ficha Lentillas';
$activo = 'clientes';
$tabActiva = 'lentillas';
require __DIR__ . '/includes/header.php';
?>
<section class="panel">
  <div class="panel__title-bar"><span class="panel__title-pill">Ficha cliente</span><span class="panel__title-cliente"><?= htmlspecialchars(trim(($cliente['nombre'] ?? '') . ' ' . ($cliente['apellidos'] ?? ''))) ?></span></div>
  <?php require __DIR__ . '/includes/ficha_cliente_tabs.php'; ?>

  <?php $formGuardarId = 'form-queratometria'; require __DIR__ . '/includes/ficha_acciones.php'; ?>

  <?php if (!empty($_GET['guardado'])): ?>
    <p class="form-ok">Guardado correctamente.</p>
  <?php endif; ?>

  <details class="ficha-seccion" open>
    <summary class="ficha-seccion__titulo">Con Gafas</summary>
    <?php foreach (['D' => 'Ojo Derecho', 'I' => 'Ojo Izquierdo'] as $ojo => $nombreOjo): ?>
      <p class="ficha-seccion__ojo">👁️ <?= $nombreOjo ?></p>
      <?php pintarGridRepetible($pdo, 'lentillas_con_gafas', $config['lentillas_con_gafas']['columnas'],
          ['cliente_id' => $id, 'ojo' => $ojo], $volver); ?>
    <?php endforeach; ?>
  </details>

  <details class="ficha-seccion">
    <summary class="ficha-seccion__titulo">Lentes de Prueba</summary>
    <?php foreach (['D' => 'Ojo Derecho', 'I' => 'Ojo Izquierdo'] as $ojo => $nombreOjo): ?>
      <p class="ficha-seccion__ojo">👁️ <?= $nombreOjo ?></p>
      <?php pintarGridRepetible($pdo, 'lentillas_prueba', $config['lentillas_prueba']['columnas'],
          ['cliente_id' => $id, 'ojo' => $ojo], $volver); ?>
    <?php endforeach; ?>
  </details>

  <details class="ficha-seccion">
    <summary class="ficha-seccion__titulo">Lentes Definitivas</summary>
    <?php foreach (['D' => 'Ojo Derecho', 'I' => 'Ojo Izquierdo'] as $ojo => $nombreOjo): ?>
      <p class="ficha-seccion__ojo">👁️ <?= $nombreOjo ?></p>
      <?php pintarGridRepetible($pdo, 'lentillas_definitivas', $config['lentillas_definitivas']['columnas'],
          ['cliente_id' => $id, 'ojo' => $ojo], $volver); ?>
    <?php endforeach; ?>
  </details>

  <details class="ficha-seccion">
    <summary class="ficha-seccion__titulo">Revisiones</summary>
    <?php pintarGridRepetible($pdo, 'lentillas_revisiones', $config['lentillas_revisiones']['columnas'],
        ['cliente_id' => $id], $volver); ?>
  </details>

  <details class="ficha-seccion">
    <summary class="ficha-seccion__titulo">Queratometría</summary>
    <form method="post" id="form-queratometria" class="record-form">
      <input type="hidden" name="guardar_queratometria" value="1">
      <div class="record-form__grid">
        <div class="record-form__row">
          <label for="queratometria_od">Ojo derecho</label>
          <input type="text" id="queratometria_od" name="queratometria_od" value="<?= htmlspecialchars($cliente['queratometria_od'] ?? '') ?>">
        </div>
        <div class="record-form__row">
          <label for="queratometria_oi">Ojo izquierdo</label>
          <input type="text" id="queratometria_oi" name="queratometria_oi" value="<?= htmlspecialchars($cliente['queratometria_oi'] ?? '') ?>">
        </div>
      </div>
      <div class="record-form__actions">
        <button class="btn btn--primary" type="submit">✅ Guardar</button>
      </div>
    </form>
  </details>

  <div class="record-form__actions">
    <a class="btn btn--secondary" href="<?= htmlspecialchars($volverListado) ?><?= strpos($volverListado, '?') !== false ? '&' : '?' ?>resaltar=<?= (int) $id ?>&origen=<?= (int)($_GET['origen'] ?? $id) ?>">↩️ Volver</a>
  </div>
</section>
<?php require __DIR__ . '/includes/footer.php'; ?>
