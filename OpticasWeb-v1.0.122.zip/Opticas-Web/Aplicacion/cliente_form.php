<?php
require __DIR__ . '/includes/auth.php';
requireLogin();
require __DIR__ . '/db.php';

$pdo = obtenerConexion();
$id = isset($_GET['id']) ? (int) $_GET['id'] : (isset($_POST['id']) ? (int) $_POST['id'] : null);
$cliente = null;
$error = null;

if ($id) {
    $stmt = $pdo->prepare('SELECT * FROM clientes WHERE id = :id');
    $stmt->execute(['id' => $id]);
    $cliente = $stmt->fetch();
    if (!$cliente) {
        header('Location: index.php');
        exit;
    }
}

$delegaciones = $pdo->query('SELECT * FROM delegaciones ORDER BY nombre COLLATE utf8mb4_general_ci')->fetchAll();

const CARPETA_FOTOS = __DIR__ . '/uploads/clientes';
const TIPOS_FOTO_PERMITIDOS = ['image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $datos = [
        'nombre'             => trim($_POST['nombre'] ?? ''),
        'apellidos'          => trim($_POST['apellidos'] ?? ''),
        'contacto'           => trim($_POST['contacto'] ?? ''),
        'nif'                => trim($_POST['nif'] ?? ''),
        'telefono'           => trim($_POST['telefono'] ?? ''),
        'movil'              => trim($_POST['movil'] ?? ''),
        'direccion'          => trim($_POST['direccion'] ?? ''),
        'poblacion'          => trim($_POST['poblacion'] ?? ''),
        'provincia'          => trim($_POST['provincia'] ?? ''),
        'codigo_postal'      => trim($_POST['codigo_postal'] ?? ''),
        'email'              => trim($_POST['email'] ?? ''),
        'fecha_nacimiento'   => ($_POST['fecha_nacimiento'] ?? '') !== '' ? $_POST['fecha_nacimiento'] : null,
        'profesion'          => trim($_POST['profesion'] ?? ''),
        'tarjeta_cliente'    => trim($_POST['tarjeta_cliente'] ?? ''),
        'descuento'          => ($_POST['descuento'] ?? '') !== '' ? (float) str_replace(',', '.', $_POST['descuento']) : 0,
        'cuenta_contable'    => trim($_POST['cuenta_contable'] ?? ''),
        'usuario_web'        => trim($_POST['usuario_web'] ?? ''),
        'clave_web'          => trim($_POST['clave_web'] ?? ''),
        'acepta_mailing_sms' => isset($_POST['acepta_mailing_sms']) ? 1 : 0,
        'proxima_revision'   => ($_POST['proxima_revision'] ?? '') !== '' ? $_POST['proxima_revision'] : null,
        'fecha_aviso'        => ($_POST['fecha_aviso'] ?? '') !== '' ? $_POST['fecha_aviso'] : null,
        'mostrar_aviso'      => isset($_POST['mostrar_aviso']) ? 1 : 0,
        'notas'              => trim($_POST['notas'] ?? ($cliente['notas'] ?? '')),
    ];

    // Foto: subir una nueva, o quitar la que hubiera si se marcó la casilla
    $rutaFoto = $cliente['foto'] ?? null;
    if (!empty($_POST['quitar_foto']) && $rutaFoto) {
        @unlink(CARPETA_FOTOS . '/' . basename($rutaFoto));
        $rutaFoto = null;
    }
    if (!empty($_FILES['foto']['name']) && $_FILES['foto']['error'] === UPLOAD_ERR_OK) {
        $tipo = mime_content_type($_FILES['foto']['tmp_name']);
        if (isset(TIPOS_FOTO_PERMITIDOS[$tipo]) && $_FILES['foto']['size'] <= 4 * 1024 * 1024) {
            if (!is_dir(CARPETA_FOTOS)) {
                mkdir(CARPETA_FOTOS, 0775, true);
            }
            $nombreFichero = ($id ?: 'nuevo') . '_' . time() . '.' . TIPOS_FOTO_PERMITIDOS[$tipo];
            if (move_uploaded_file($_FILES['foto']['tmp_name'], CARPETA_FOTOS . '/' . $nombreFichero)) {
                if ($rutaFoto) {
                    @unlink(CARPETA_FOTOS . '/' . basename($rutaFoto));
                }
                $rutaFoto = 'uploads/clientes/' . $nombreFichero;
            }
        } else {
            $error = 'La foto debe ser JPG, PNG o WEBP y pesar menos de 4 MB.';
        }
    }
    $datos['foto'] = $rutaFoto;

    $datos['activo'] = isset($_POST['activo']) ? 1 : 0;
    $datos['fecha_modificacion'] = date('Y-m-d');
    $datos['delegacion_id'] = ($_POST['delegacion_id'] ?? '') !== '' ? (int) $_POST['delegacion_id'] : null;

    if ($datos['nombre'] === '') {
        $error = 'El nombre es obligatorio.';
    }

    if ($error === null) {
        if ($id) {
            $datos['id'] = $id;
            $pdo->prepare(
                'UPDATE clientes SET nombre=:nombre, apellidos=:apellidos, contacto=:contacto,
                 nif=:nif, telefono=:telefono, movil=:movil,
                 direccion=:direccion, poblacion=:poblacion, provincia=:provincia,
                 codigo_postal=:codigo_postal, email=:email, fecha_nacimiento=:fecha_nacimiento,
                 profesion=:profesion, tarjeta_cliente=:tarjeta_cliente, descuento=:descuento,
                 cuenta_contable=:cuenta_contable, usuario_web=:usuario_web, clave_web=:clave_web,
                 acepta_mailing_sms=:acepta_mailing_sms, proxima_revision=:proxima_revision,
                 fecha_aviso=:fecha_aviso, mostrar_aviso=:mostrar_aviso, foto=:foto,
                 activo=:activo, fecha_modificacion=:fecha_modificacion, delegacion_id=:delegacion_id,
                 notas=:notas WHERE id=:id'
            )->execute($datos);
        } else {
            $datos['fecha_alta'] = date('Y-m-d');
            $pdo->prepare(
                'INSERT INTO clientes (nombre, apellidos, contacto, nif, telefono, movil,
                 direccion, poblacion, provincia, codigo_postal, email, fecha_nacimiento, profesion,
                 tarjeta_cliente, descuento, cuenta_contable, usuario_web, clave_web,
                 acepta_mailing_sms, proxima_revision, fecha_aviso, mostrar_aviso, foto,
                 activo, fecha_modificacion, delegacion_id, notas, fecha_alta)
                 VALUES (:nombre, :apellidos, :contacto, :nif, :telefono, :movil,
                 :direccion, :poblacion, :provincia, :codigo_postal, :email, :fecha_nacimiento, :profesion,
                 :tarjeta_cliente, :descuento, :cuenta_contable, :usuario_web, :clave_web,
                 :acepta_mailing_sms, :proxima_revision, :fecha_aviso, :mostrar_aviso, :foto,
                 :activo, :fecha_modificacion, :delegacion_id, :notas, :fecha_alta)'
            )->execute($datos);
            $id = (int) $pdo->lastInsertId();
        }
        header('Location: cliente_form.php?id=' . $id . '&guardado=1');
        exit;
    }

    // Si hubo un error, volvemos a mostrar el formulario con lo que se escribió
    $cliente = array_merge($cliente ?? [], $datos, ['id' => $id]);
}

$edad = null;
if (!empty($cliente['fecha_nacimiento'])) {
    $edad = (new DateTime($cliente['fecha_nacimiento']))->diff(new DateTime())->y;
}

$esExistente = !empty($cliente['id']);
$volverListado = $_GET['volver'] ?? $_POST['volver'] ?? 'index.php';
$origenId = (int)($_GET['origen'] ?? $_POST['origen'] ?? $id);
$volverParam = urlencode($volverListado);
$idAnterior = null;
$idSiguiente = null;
if ($esExistente) {
    $stmt = $pdo->prepare('SELECT MAX(id) AS id FROM clientes WHERE id < :id');
    $stmt->execute(['id' => $cliente['id']]);
    $idAnterior = $stmt->fetch()['id'];

    $stmt = $pdo->prepare('SELECT MIN(id) AS id FROM clientes WHERE id > :id');
    $stmt->execute(['id' => $cliente['id']]);
    $idSiguiente = $stmt->fetch()['id'];
}

$titulo = $esExistente ? 'Ficha de cliente' : 'Alta cliente';
$activo = 'clientes';
$tabActiva = 'datos';
require __DIR__ . '/includes/header.php';
?>
<section class="panel panel--cliente-compacta">
  <div class="ficha-cabecera-principal ficha-cabecera-principal--cliente">
    <div class="ficha-cabecera-principal__nombre">
      <?= $esExistente ? htmlspecialchars(trim(($cliente['nombre'] ?? '') . ' ' . ($cliente['apellidos'] ?? ''))) : 'Nuevo cliente' ?>
    </div>
    <div class="ficha-cabecera-principal__titulo">
      <span class="panel__title-pill"><?= $esExistente ? 'Ficha cliente' : 'Alta cliente' ?></span>
    </div>
    <div class="ficha-cabecera-principal__delegacion">
      <label class="ficha-delegacion-horizontal">
        <span>Delegación</span>
        <select name="delegacion_id" form="form-cliente">
          <option value="">—</option>
          <?php foreach ($delegaciones as $d): ?>
            <option value="<?= (int) $d['id'] ?>" <?= (int) ($cliente['delegacion_id'] ?? 0) === (int) $d['id'] ? 'selected' : '' ?>><?= htmlspecialchars($d['nombre']) ?></option>
          <?php endforeach; ?>
        </select>
      </label>
    </div>
  </div>

  <?php require __DIR__ . '/includes/ficha_cliente_tabs.php'; ?>

  <?php $formGuardarId = 'form-cliente'; require __DIR__ . '/includes/ficha_acciones.php'; ?>

  <?php if (!empty($_GET['guardado'])): ?>
    <p class="form-ok">Guardado correctamente.</p>
  <?php endif; ?>
  <?php if ($error): ?>
    <p class="form-error"><?= htmlspecialchars($error) ?></p>
  <?php endif; ?>

  <form method="post" id="form-cliente" class="record-form record-form--cliente record-form--cliente-compacto" enctype="multipart/form-data">
    <?php if ($esExistente): ?><input type="hidden" name="id" value="<?= (int) $cliente['id'] ?>"><?php endif; ?>
    <input type="hidden" name="volver" value="<?= htmlspecialchars($volverListado) ?>">

    <div class="fila-datos-superior">
      <div class="campo-compacto campo-compacto--numero">
        <label>Número</label>
        <input type="text" value="<?= $esExistente ? (int) $cliente['id'] : 'Nuevo' ?>" disabled>
      </div>
      <div class="campo-check">
        <label><input type="checkbox" name="activo" <?= (!$esExistente || !empty($cliente['activo'])) ? 'checked' : '' ?>> Activo</label>
      </div>
      <div class="campo-check">
        <label><input type="checkbox" id="acepta_mailing_sms" name="acepta_mailing_sms" onchange="actualizarBotonApd()" <?= !empty($cliente['acepta_mailing_sms']) ? 'checked' : '' ?>> Acepta recibir Mailing y SMS</label>
      </div>
      <?php if ($esExistente): ?>
        <a href="cliente_pdf_apd.php?id=<?= (int) $cliente['id'] ?>" target="_blank" id="btn-imprimir-apd"
           class="ficha-tabs__tab <?= empty($cliente['acepta_mailing_sms']) ? 'ficha-tabs__tab--disabled' : '' ?>">✍️ Aceptación APD</a>
      <?php else: ?>
        <span class="ficha-tabs__tab ficha-tabs__tab--disabled" title="Guarda primero el cliente">✍️ Aceptación APD</span>
      <?php endif; ?>

      <div class="fila-datos-superior__spacer"></div>

      <div class="campo-compacto campo-elastico">
        <label>Fecha Alta</label>
        <input type="text" value="<?= !empty($cliente['fecha_alta']) ? date('d-m-Y', strtotime($cliente['fecha_alta'])) : '' ?>" disabled>
      </div>
      <div class="campo-compacto campo-elastico">
        <label>Ult. Modificación</label>
        <input type="text" value="<?= !empty($cliente['fecha_modificacion']) ? date('d-m-Y', strtotime($cliente['fecha_modificacion'])) : '' ?>" disabled>
      </div>
      <div class="campo-compacto campo-elastico">
        <label for="proxima_revision">Próxima Revisión</label>
        <input type="date" id="proxima_revision" name="proxima_revision" value="<?= htmlspecialchars($cliente['proxima_revision'] ?? '') ?>">
      </div>
    </div>

    <div class="fila-datos-superior fila-datos-superior--aviso">
      <div class="campo-compacto campo-elastico campo-elastico--aviso">
        <label for="fecha_aviso">Fecha Aviso</label>
        <input type="date" id="fecha_aviso" name="fecha_aviso" value="<?= htmlspecialchars($cliente['fecha_aviso'] ?? '') ?>">
      </div>
      <div class="campo-check campo-check--inline">
        <label><input type="checkbox" name="mostrar_aviso" <?= !empty($cliente['mostrar_aviso']) ? 'checked' : '' ?>> Mostrar aviso</label>
      </div>
    </div>

    <div class="fila-nombre-foto">
      <div class="fila-nombre-foto__campos">
        <div class="record-form__grid" style="grid-template-columns:1fr 1fr 0.75fr 0.95fr">
          <div class="record-form__row">
            <label for="nombre">Nombre *</label>
            <input type="text" id="nombre" name="nombre" required
                   value="<?= htmlspecialchars($cliente['nombre'] ?? '') ?>">
          </div>
          <div class="record-form__row">
            <label for="apellidos">Apellidos</label>
            <input type="text" id="apellidos" name="apellidos" value="<?= htmlspecialchars($cliente['apellidos'] ?? '') ?>">
          </div>
          <div class="record-form__row">
            <label for="nif">NIF</label>
            <input type="text" id="nif" name="nif" value="<?= htmlspecialchars($cliente['nif'] ?? '') ?>">
          </div>
          <div class="record-form__row">
            <label for="contacto">Contacto</label>
            <input type="text" id="contacto" name="contacto" placeholder="Si viene de parte de alguien conocido"
                   value="<?= htmlspecialchars($cliente['contacto'] ?? '') ?>">
          </div>
        </div>

        <div class="record-form__row">
          <label for="direccion">Dirección</label>
          <input type="text" id="direccion" name="direccion" value="<?= htmlspecialchars($cliente['direccion'] ?? '') ?>">
        </div>

        <div class="record-form__grid record-form__grid--three">
          <div class="record-form__row">
            <label for="poblacion">Población</label>
            <input type="text" id="poblacion" name="poblacion" value="<?= htmlspecialchars($cliente['poblacion'] ?? '') ?>">
          </div>
          <div class="record-form__row">
            <label for="codigo_postal">C.P.</label>
            <input type="text" id="codigo_postal" name="codigo_postal" value="<?= htmlspecialchars($cliente['codigo_postal'] ?? '') ?>">
          </div>
          <div class="record-form__row">
            <label for="provincia">Provincia</label>
            <input type="text" id="provincia" name="provincia" value="<?= htmlspecialchars($cliente['provincia'] ?? '') ?>">
          </div>
        </div>
      </div>
      <div class="fila-nombre-foto__lateral">
        <div class="ficha-foto">
          <?php if (!empty($cliente['foto'])): ?>
            <img src="<?= htmlspecialchars($cliente['foto']) ?>" alt="Foto del cliente" class="ficha-foto__img">
            <label class="ficha-foto__quitar"><input type="checkbox" name="quitar_foto" value="1"> Quitar foto</label>
          <?php else: ?>
            <div class="ficha-foto__placeholder">📷</div>
          <?php endif; ?>
          <input type="file" name="foto" accept="image/png, image/jpeg, image/webp">
        </div>
      </div>
    </div>

    <div class="ficha-datos-resto">

        <div class="record-form__grid" style="grid-template-columns:1fr 0.5fr 1.3fr 1fr 1fr 1fr">
          <div class="record-form__row">
            <label for="fecha_nacimiento">Fecha Nacimiento</label>
            <input type="date" id="fecha_nacimiento" name="fecha_nacimiento" value="<?= htmlspecialchars($cliente['fecha_nacimiento'] ?? '') ?>">
          </div>
          <div class="record-form__row">
            <label>Edad</label>
            <input type="text" value="<?= $edad !== null ? $edad : '' ?>" disabled>
          </div>
          <div class="record-form__row">
            <label for="email">Email</label>
            <input type="email" id="email" name="email" value="<?= htmlspecialchars($cliente['email'] ?? '') ?>">
          </div>
          <div class="record-form__row">
            <label for="telefono">Teléfono</label>
            <input type="text" id="telefono" name="telefono" value="<?= htmlspecialchars($cliente['telefono'] ?? '') ?>">
          </div>
          <div class="record-form__row">
            <label for="movil">Móvil</label>
            <input type="text" id="movil" name="movil" value="<?= htmlspecialchars($cliente['movil'] ?? '') ?>">
          </div>
          <div class="record-form__row">
            <label for="profesion">Profesión</label>
            <input type="text" id="profesion" name="profesion" value="<?= htmlspecialchars($cliente['profesion'] ?? '') ?>">
          </div>
        </div>

        <hr class="ficha-sep-fina">

        <div class="ficha-datos-grid">
          <div class="ficha-datos-grid__principal">
            <div class="record-form__grid" style="grid-template-columns:1fr 0.6fr 1fr 1fr 1fr">
              <div class="record-form__row">
                <label for="tarjeta_cliente">Tarjeta Cliente</label>
                <input type="text" id="tarjeta_cliente" name="tarjeta_cliente" value="<?= htmlspecialchars($cliente['tarjeta_cliente'] ?? '') ?>">
              </div>
              <div class="record-form__row">
                <label for="descuento">%Dto</label>
                <input type="text" id="descuento" name="descuento" value="<?= htmlspecialchars($cliente['descuento'] ?? '0') ?>">
              </div>
              <div class="record-form__row">
                <label for="cuenta_contable">Cuenta Contable</label>
                <input type="text" id="cuenta_contable" name="cuenta_contable" value="<?= htmlspecialchars($cliente['cuenta_contable'] ?? '') ?>">
              </div>
              <div class="record-form__row">
                <label for="usuario_web">Usuario Web</label>
                <input type="text" id="usuario_web" name="usuario_web" value="<?= htmlspecialchars($cliente['usuario_web'] ?? '') ?>">
              </div>
              <div class="record-form__row">
                <label for="clave_web">Clave Web</label>
                <input type="text" id="clave_web" name="clave_web" value="<?= htmlspecialchars($cliente['clave_web'] ?? '') ?>">
              </div>
            </div>
            <div class="record-form__grid record-form__grid--three">
              <div class="record-form__row">
                <label>Doctor</label>
                <select disabled><option>Próxima fase (Ficheros)</option></select>
              </div>
              <div class="record-form__row">
                <label>Vendido</label>
                <input type="text" value="0.00" disabled>
              </div>
              <div class="record-form__row">
                <label>Deuda</label>
                <input type="text" value="0.00" disabled>
              </div>
            </div>
            <div class="record-form__grid">
              <div class="record-form__row">
                <label>Clasificación</label>
                <select disabled><option>Próxima fase (Config.)</option></select>
              </div>
              <div class="record-form__row">
                <label>Tarifa</label>
                <select disabled><option>1</option></select>
              </div>
            </div>
          </div>
          <div class="ficha-datos-grid__lateral">
            <div class="record-form__row">
              <label for="notas">Observaciones</label>
              <textarea id="notas" name="notas" rows="5"><?= htmlspecialchars($cliente['notas'] ?? '') ?></textarea>
            </div>
          </div>
        </div>

    </div>

    <div class="record-form__actions record-form__actions--distribuidas">
      <div class="record-form__actions-grupo">
        <button class="btn btn--secondary" type="submit">✅ Guardar</button>
        <a class="btn btn--secondary" href="cliente_form.php">➕ Nuevo</a>
        <?php if ($esExistente): ?>
          <button type="submit" formaction="cliente_borrar.php" formmethod="post"
                  class="btn btn--danger"
                  onclick="return confirm('¿Eliminar a <?= htmlspecialchars(addslashes($cliente['nombre'])) ?>?');">❌ Borrar</button>
        <?php else: ?>
          <span class="btn btn--disabled">❌ Borrar</span>
        <?php endif; ?>
      </div>
      <div class="record-form__actions-grupo record-form__actions-grupo--derecha">
        <?php if ($idAnterior): ?>
        <a class="btn btn--secondary" href="cliente_form.php?id=<?= (int) $idAnterior ?>&volver=<?= $volverParam ?>&origen=<?= $origenId ?>">⬅️ Anterior</a>
        <?php endif; ?>
        <?php if ($idSiguiente): ?>
        <a class="btn btn--secondary" href="cliente_form.php?id=<?= (int) $idSiguiente ?>&volver=<?= $volverParam ?>&origen=<?= $origenId ?>">➡️ Siguiente</a>
        <?php endif; ?>
        <a class="btn btn--secondary" href="<?= htmlspecialchars($volverListado) ?><?= strpos($volverListado, '?') !== false ? '&' : '?' ?>resaltar=<?= $esExistente ? (int) $cliente['id'] : 0 ?>&origen=<?= $origenId ?>">↩️ Volver</a>
      </div>
    </div>
  </form>
</section>
<script>
function actualizarBotonApd() {
  var chk = document.getElementById('acepta_mailing_sms');
  var btn = document.getElementById('btn-imprimir-apd');
  if (!chk || !btn) return;
  if (chk.checked) {
    btn.classList.remove('ficha-tabs__tab--disabled');
  } else {
    btn.classList.add('ficha-tabs__tab--disabled');
  }
}
</script>
<?php require __DIR__ . '/includes/footer.php'; ?>
