<?php
require __DIR__ . '/includes/auth.php';
requireLogin();
require __DIR__ . '/db.php';

$pdo = obtenerConexion();
$id = isset($_GET['id']) ? (int) $_GET['id'] : (isset($_POST['id']) ? (int) $_POST['id'] : null);
$articulo = null;
$error = null;

if ($id) {
    $stmt = $pdo->prepare('SELECT * FROM articulos WHERE id = :id');
    $stmt->execute(['id' => $id]);
    $articulo = $stmt->fetch();
    if (!$articulo) { header('Location: almacen_articulos.php'); exit; }
}

$marcas = $pdo->query('SELECT * FROM marcas ORDER BY nombre COLLATE utf8mb4_general_ci')->fetchAll();
$delegaciones = $pdo->query('SELECT * FROM delegaciones ORDER BY nombre COLLATE utf8mb4_general_ci')->fetchAll();

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['guardar'])) {
    $campos = [
        'codigo','referencia','nombre','codigo_barras','marca_id','coste','pvp','existencias',
        'activo','delegacion_id','tipo_articulo','calibre','color','material','sexo','modelo',
        'proveedor','casa','codigo_fabricante','tipo_margen','calculo_margen','tipo_calculo',
        'actualiza_pvp','margen1','margen2','margen3','margen4','margen5','impuesto','tasa','peso',
        'portes','pvp2','pvp3','pvp4','pvp5','costo_medio','ultimo_precio_compra','margen_minimo',
        'precio_minimo','cuenta_venta','cuenta_compra','inventariable','observaciones',
        'publicar_web','detalle_web',
    ];
    $datos = [];
    foreach ($campos as $c) {
        if (in_array($c, ['activo','actualiza_pvp','inventariable','publicar_web'], true)) {
            $datos[$c] = isset($_POST[$c]) ? 1 : 0;
        } elseif (in_array($c, ['marca_id','delegacion_id'], true)) {
            $datos[$c] = ($_POST[$c] ?? '') !== '' ? (int) $_POST[$c] : null;
        } elseif (in_array($c, ['coste','pvp','existencias','margen1','margen2','margen3','margen4','margen5','impuesto','tasa','peso','portes','pvp2','pvp3','pvp4','pvp5','costo_medio','ultimo_precio_compra','margen_minimo','precio_minimo'], true)) {
            $datos[$c] = ($_POST[$c] ?? '') !== '' ? (float) str_replace(',', '.', $_POST[$c]) : 0;
        } else {
            $datos[$c] = trim($_POST[$c] ?? '');
        }
    }
    if ($datos['nombre'] === '') {
        $error = 'El nombre es obligatorio.';
    } else {
        $datos['fecha_modificacion'] = date('Y-m-d');
        if ($id) {
            $set = implode(', ', array_map(fn($c) => "$c=:$c", array_keys($datos)));
            $datos['id'] = $id;
            $pdo->prepare("UPDATE articulos SET $set WHERE id=:id")->execute($datos);
        } else {
            $datos['fecha_alta'] = date('Y-m-d');
            $cols = implode(', ', array_keys($datos));
            $ph = implode(', ', array_map(fn($c) => ":$c", array_keys($datos)));
            $pdo->prepare("INSERT INTO articulos ($cols) VALUES ($ph)")->execute($datos);
            $id = (int) $pdo->lastInsertId();
        }
        header('Location: articulo_form.php?id=' . $id . '&guardado=1');
        exit;
    }
    $articulo = array_merge($articulo ?? [], $datos, ['id' => $id]);
}

$esExistente = !empty($articulo['id']);
$volverListado = $_GET['volver'] ?? $_POST['volver'] ?? 'almacen_articulos.php';
$origenId = (int)($_GET['origen'] ?? $_POST['origen'] ?? $id);
$volverParam = urlencode($volverListado);
$idAnterior = $idSiguiente = null;
if ($esExistente) {
    $st = $pdo->prepare('SELECT MAX(id) AS id FROM articulos WHERE id < :id'); $st->execute(['id' => $id]); $idAnterior = $st->fetch()['id'];
    $st = $pdo->prepare('SELECT MIN(id) AS id FROM articulos WHERE id > :id'); $st->execute(['id' => $id]); $idSiguiente = $st->fetch()['id'];
}
function av($a, $k, $d = '') { return htmlspecialchars($a[$k] ?? $d); }

// Datos de las pestañas Existencias / Compras / Campos Extra
$stock = $compras = $extras = [];
if ($esExistente) {
    $s = $pdo->prepare('SELECT s.*, d.nombre AS delegacion FROM articulos_stock s LEFT JOIN delegaciones d ON d.id = s.delegacion_id WHERE articulo_id = :id');
    $s->execute(['id' => $id]); $stock = $s->fetchAll();
    $s = $pdo->prepare('SELECT * FROM articulos_compras WHERE articulo_id = :id ORDER BY fecha DESC'); $s->execute(['id' => $id]); $compras = $s->fetchAll();
    $s = $pdo->prepare('SELECT * FROM articulos_campos_extra WHERE articulo_id = :id'); $s->execute(['id' => $id]); $extras = $s->fetchAll();
}

$subtab = $_GET['tab'] ?? 'tarifas';

$titulo = $esExistente ? 'Ficha de artículo' : 'Nuevo artículo';
$activo = 'articulos';
require __DIR__ . '/includes/header.php';
?>
<section class="panel panel--centrada panel--ficha-ancha panel--articulo-compacta">
  <div class="ficha-cabecera-principal ficha-cabecera-principal--articulo">
    <div class="ficha-cabecera-principal__nombre">
      <?= $esExistente ? av($articulo, 'nombre') : 'Nuevo artículo' ?>
    </div>
    <div class="ficha-cabecera-principal__titulo">
      <span class="panel__title-pill">Consulta artículos</span>
    </div>
    <div class="ficha-cabecera-principal__delegacion">
      <label class="ficha-delegacion-horizontal">
        <span>Delegación</span>
        <select name="delegacion_id" form="form-articulo">
          <option value="">—</option>
          <?php foreach ($delegaciones as $d): ?>
            <option value="<?= (int)$d['id'] ?>" <?= (int)($articulo['delegacion_id']??0)===(int)$d['id']?'selected':'' ?>><?= htmlspecialchars($d['nombre']) ?></option>
          <?php endforeach; ?>
        </select>
      </label>
    </div>
  </div>

  <div class="ficha-acciones ficha-acciones--distribuida">
    <div class="ficha-acciones__grupo ficha-acciones__grupo--izquierda">
      <button type="submit" form="form-articulo" name="guardar" value="1" class="ficha-acciones__item btn btn--secondary">✅ Guardar</button>
      <a href="articulo_form.php" class="ficha-acciones__item btn btn--secondary">➕ Nuevo</a>
      <?php if ($esExistente): ?>
        <button type="submit" form="form-borrar-articulo" class="ficha-acciones__item btn btn--danger" onclick="return confirm('¿Eliminar este artículo?');">❌ Borrar</button>
      <?php else: ?>
        <span class="ficha-acciones__item ficha-acciones__item--disabled">❌ Borrar</span>
      <?php endif; ?>
    </div>

    <div class="ficha-acciones__grupo ficha-acciones__grupo--centro">
      <span class="ficha-acciones__item ficha-acciones__item--disabled" title="Próxima fase">🏷️ Etiquetas</span>
    </div>

    <div class="ficha-acciones__grupo ficha-acciones__grupo--derecha">
      <?php if ($idAnterior): ?>
        <a href="articulo_form.php?id=<?= (int) $idAnterior ?>&volver=<?= $volverParam ?>&origen=<?= $origenId ?>" class="ficha-acciones__item btn btn--secondary">⬅️ Anterior</a>
      <?php endif; ?>
      <?php if ($idSiguiente): ?>
        <a href="articulo_form.php?id=<?= (int) $idSiguiente ?>&volver=<?= $volverParam ?>&origen=<?= $origenId ?>" class="ficha-acciones__item btn btn--secondary">➡️ Siguiente</a>
      <?php endif; ?>
      <a href="<?= htmlspecialchars($volverListado) ?><?= strpos($volverListado, '?') !== false ? '&' : '?' ?>resaltar=<?= $esExistente ? (int) $articulo['id'] : 0 ?>&origen=<?= $origenId ?>" class="ficha-acciones__item btn btn--secondary">↩️ Volver</a>
    </div>
  </div>

  <?php if (!empty($_GET['guardado'])): ?><p class="form-ok">Guardado correctamente.</p><?php endif; ?>
  <?php if ($error): ?><p class="form-error"><?= htmlspecialchars($error) ?></p><?php endif; ?>

  <form method="post" id="form-articulo" class="record-form record-form--compacto record-form--articulo-compacto">
    <?php if ($esExistente): ?><input type="hidden" name="id" value="<?= (int) $articulo['id'] ?>"><?php endif; ?>
    <input type="hidden" name="volver" value="<?= htmlspecialchars($volverListado) ?>">
    <input type="hidden" name="guardar" value="1">

    <!-- Cabecera común del artículo -->
    <div class="record-form__grid" style="grid-template-columns:2fr 1.3fr 1fr 1fr">
      <div class="record-form__row"><label>Nombre *</label><input type="text" name="nombre" required value="<?= av($articulo,'nombre') ?>"></div>
      <div class="record-form__row"><label>Referencia</label><input type="text" name="referencia" value="<?= av($articulo,'referencia') ?>"></div>
      <div class="record-form__row"><label>Marca</label>
        <select name="marca_id"><option value="">—</option>
          <?php foreach ($marcas as $m): ?><option value="<?= (int)$m['id'] ?>" <?= (int)($articulo['marca_id']??0)===(int)$m['id']?'selected':'' ?>><?= htmlspecialchars($m['nombre']) ?></option><?php endforeach; ?>
        </select>
      </div>
      <div class="record-form__row"><label>Modelo</label><input type="text" name="modelo" value="<?= av($articulo,'modelo') ?>"></div>
    </div>
    <div class="record-form__grid" style="grid-template-columns:0.55fr 1.15fr 0.85fr 0.95fr 1.5fr 1fr 0.55fr">
      <div class="record-form__row"><label>Número</label><input type="text" value="<?= $esExistente ? (int)$articulo['id'] : '' ?>" disabled></div>
      <div class="record-form__row"><label>Código Fabricante</label><input type="text" name="codigo_fabricante" value="<?= av($articulo,'codigo_fabricante') ?>"></div>
      <div class="record-form__row"><label>Color</label><input type="text" name="color" value="<?= av($articulo,'color') ?>"></div>
      <div class="record-form__row"><label>Material</label><input type="text" name="material" value="<?= av($articulo,'material') ?>"></div>
      <div class="record-form__row"><label>Código Barras</label><input type="text" name="codigo_barras" value="<?= av($articulo,'codigo_barras') ?>"></div>
      <div class="record-form__row"><label>Código</label><input type="text" name="codigo" value="<?= av($articulo,'codigo') ?>"></div>
      <div class="record-form__row"><label>Sexo</label><input type="text" name="sexo" maxlength="2" value="<?= av($articulo,'sexo') ?>"></div>
    </div>
    <div class="record-form__grid" style="grid-template-columns:1fr 0.5fr 1fr 1.3fr 1fr 0.8fr; align-items:end">
      <div class="record-form__row"><label>Fecha Alta</label><input type="text" value="<?= !empty($articulo['fecha_alta']) ? date('d-m-Y', strtotime($articulo['fecha_alta'])) : '' ?>" disabled></div>
      <div class="record-form__row record-form__row--checkbox" style="margin:0;padding-bottom:0.4rem"><label><input type="checkbox" name="activo" <?= (!$esExistente || !empty($articulo['activo'])) ? 'checked' : '' ?>> Activo</label></div>
      <div class="record-form__row"><label>Ult. Modificación</label><input type="text" value="<?= !empty($articulo['fecha_modificacion']) ? date('d-m-Y', strtotime($articulo['fecha_modificacion'])) : '' ?>" disabled></div>
      <div class="record-form__row"><label>Último proveedor</label><input type="text" name="proveedor" value="<?= av($articulo,'proveedor') ?>"></div>
      <div class="record-form__row"><label>Casa</label><input type="text" name="casa" value="<?= av($articulo,'casa') ?>"></div>
      <div class="record-form__row"><label>Calibre</label><input type="text" name="calibre" value="<?= av($articulo,'calibre') ?>"></div>
    </div>


    <!-- Pestañas -->
    <div class="ficha-tabs">
      <?php
        $tabs = ['tarifas'=>'Tarifas','existencias'=>'Existencias','compras'=>'Compras','observaciones'=>'Observaciones','extra'=>'Campos Extra','web'=>'Web'];
        foreach ($tabs as $k => $nombre):
      ?>
        <button type="button" class="ficha-tabs__tab <?= $subtab===$k?'ficha-tabs__tab--active':'' ?>" onclick="mostrarTabArt('<?= $k ?>', this)"><?= $nombre ?></button>
      <?php endforeach; ?>
    </div>

    <div class="art-tab" data-tab="tarifas" style="<?= $subtab==='tarifas'?'':'display:none' ?>">
      <div class="record-form__grid" style="grid-template-columns:1.3fr 1.3fr 1.6fr 1fr; align-items:end">
        <div class="record-form__row"><label>Tipo de margen</label>
          <select name="tipo_margen"><?php foreach (['ARTICULO'=>'Artículo','FAMILIA'=>'Familia'] as $v=>$t): ?><option value="<?= $v ?>" <?= ($articulo['tipo_margen']??'ARTICULO')===$v?'selected':'' ?>><?= $t ?></option><?php endforeach; ?></select>
        </div>
        <div class="record-form__row"><label>Cálculo de margen</label>
          <select name="calculo_margen"><?php foreach (['COSTO'=>'Costo','PVP'=>'PVP'] as $v=>$t): ?><option value="<?= $v ?>" <?= ($articulo['calculo_margen']??'COSTO')===$v?'selected':'' ?>><?= $t ?></option><?php endforeach; ?></select>
        </div>
        <div class="record-form__row"><label>Tipo de cálculo</label>
          <select name="tipo_calculo"><?php foreach (['SOBRE PRECIO DE COSTE'=>'Sobre precio de coste','SOBRE PVP'=>'Sobre PVP'] as $v=>$t): ?><option value="<?= $v ?>" <?= ($articulo['tipo_calculo']??'')===$v?'selected':'' ?>><?= $t ?></option><?php endforeach; ?></select>
        </div>
        <div class="record-form__row record-form__row--checkbox" style="margin:0;padding-bottom:0.4rem"><label><input type="checkbox" name="actualiza_pvp" <?= !empty($articulo['actualiza_pvp'])?'checked':'' ?>> Actualiza PVP al comprar</label></div>
      </div>
      <div class="record-form__grid" style="grid-template-columns:repeat(7,1fr)">
        <?php for ($i=1;$i<=5;$i++): ?>
          <div class="record-form__row"><label>Margen <?= $i ?> %</label><input type="text" name="margen<?= $i ?>" value="<?= av($articulo,"margen$i",'0') ?>"></div>
        <?php endfor; ?>
        <div class="record-form__row"><label>Impuesto %</label><input type="text" name="impuesto" value="<?= av($articulo,'impuesto','21') ?>"></div>
        <div class="record-form__row"><label>Tasa</label><input type="text" name="tasa" value="<?= av($articulo,'tasa','0') ?>"></div>
      </div>
      <div class="record-form__grid" style="grid-template-columns:repeat(7,1fr)">
        <div class="record-form__row"><label>Coste</label><input type="text" name="coste" value="<?= av($articulo,'coste','0') ?>"></div>
        <div class="record-form__row"><label>Peso</label><input type="text" name="peso" value="<?= av($articulo,'peso','0') ?>"></div>
        <div class="record-form__row"><label>Portes</label><input type="text" name="portes" value="<?= av($articulo,'portes','0') ?>"></div>
        <div class="record-form__row"><label>Costo medio</label><input type="text" name="costo_medio" value="<?= av($articulo,'costo_medio','0') ?>"></div>
        <div class="record-form__row"><label>Últ. precio compra</label><input type="text" name="ultimo_precio_compra" value="<?= av($articulo,'ultimo_precio_compra','0') ?>"></div>
        <div class="record-form__row"><label>Margen mín.</label><input type="text" name="margen_minimo" value="<?= av($articulo,'margen_minimo','0') ?>"></div>
        <div class="record-form__row"><label>Cuenta compra</label><input type="text" name="cuenta_compra" value="<?= av($articulo,'cuenta_compra') ?>"></div>
      </div>
      <div class="record-form__grid" style="grid-template-columns:repeat(7,1fr)">
        <div class="record-form__row"><label>PVP 1</label><input type="text" name="pvp" value="<?= av($articulo,'pvp','0') ?>"></div>
        <?php for ($i=2;$i<=5;$i++): ?>
          <div class="record-form__row"><label>PVP <?= $i ?></label><input type="text" name="pvp<?= $i ?>" value="<?= av($articulo,"pvp$i",'0') ?>"></div>
        <?php endfor; ?>
        <div class="record-form__row"><label>Precio mínimo</label><input type="text" name="precio_minimo" value="<?= av($articulo,'precio_minimo','0') ?>"></div>
        <div class="record-form__row"><label>Cuenta venta</label><input type="text" name="cuenta_venta" value="<?= av($articulo,'cuenta_venta') ?>"></div>
      </div>
    </div>

    <div class="art-tab" data-tab="existencias" style="<?= $subtab==='existencias'?'':'display:none' ?>">
      <div class="record-form__row record-form__row--checkbox"><label><input type="checkbox" name="inventariable" <?= (!$esExistente || !empty($articulo['inventariable']))?'checked':'' ?>> Inventariable</label></div>
      <div class="table-scroll">
        <table class="data-table data-table--compacta">
          <thead><tr><th>Almacén</th><th>Stock</th><th>Stock Máximo</th><th>Stock Mínimo</th><th>Entradas</th><th>Salidas</th></tr></thead>
          <tbody>
            <?php if (empty($stock)): ?>
              <tr><td colspan="6" class="empty-row">Sin existencias registradas.</td></tr>
            <?php else: foreach ($stock as $s): ?>
              <tr><td><?= htmlspecialchars($s['delegacion'] ?? '') ?></td>
                <td><?= number_format((float)$s['stock'],2,',','.') ?></td>
                <td><?= number_format((float)$s['stock_maximo'],2,',','.') ?></td>
                <td><?= number_format((float)$s['stock_minimo'],2,',','.') ?></td>
                <td><?= number_format((float)$s['entradas'],2,',','.') ?></td>
                <td><?= number_format((float)$s['salidas'],2,',','.') ?></td></tr>
            <?php endforeach; endif; ?>
          </tbody>
        </table>
      </div>
    </div>

    <div class="art-tab" data-tab="compras" style="<?= $subtab==='compras'?'':'display:none' ?>">
      <div class="table-scroll">
        <table class="data-table data-table--compacta">
          <thead><tr><th>Tipo</th><th>Fecha</th><th>Documento</th><th>Proveedor</th><th>Cantidad</th><th>Precio</th><th>Importe</th></tr></thead>
          <tbody>
            <?php if (empty($compras)): ?>
              <tr><td colspan="7" class="empty-row">Sin compras registradas.</td></tr>
            <?php else: foreach ($compras as $co): ?>
              <tr><td><?= htmlspecialchars($co['tipo_documento'] ?? 'Compra') ?></td><td><?= htmlspecialchars($co['fecha']??'') ?></td>
                <td><?= htmlspecialchars($co['documento']??'') ?></td><td><?= htmlspecialchars($co['proveedor']??'') ?></td>
                <td><?= number_format((float)($co['cantidad']??0),2,',','.') ?></td><td><?= number_format((float)($co['precio']??0),2,',','.') ?></td>
                <td><?= number_format((float)($co['importe']??0),2,',','.') ?></td></tr>
            <?php endforeach; endif; ?>
          </tbody>
        </table>
      </div>
    </div>

    <div class="art-tab" data-tab="observaciones" style="<?= $subtab==='observaciones'?'':'display:none' ?>">
      <div class="record-form__row"><label>Observaciones</label><textarea name="observaciones" rows="5"><?= av($articulo,'observaciones') ?></textarea></div>
    </div>

    <div class="art-tab" data-tab="extra" style="<?= $subtab==='extra'?'':'display:none' ?>">
      <?php if (empty($extras)): ?>
        <p class="listados-nota">Este apartado incluye los campos personalizados para el artículo. (La gestión de campos personalizados se añadirá en una fase posterior.)</p>
      <?php else: foreach ($extras as $ex): ?>
        <div class="record-form__row"><label><?= htmlspecialchars($ex['nombre']) ?></label><input type="text" value="<?= htmlspecialchars($ex['valor']) ?>" disabled></div>
      <?php endforeach; endif; ?>
    </div>

    <div class="art-tab" data-tab="web" style="<?= $subtab==='web'?'':'display:none' ?>">
      <div class="record-form__row"><label>Publicar Web</label>
        <select name="publicar_web"><option value="0" <?= empty($articulo['publicar_web'])?'selected':'' ?>>No publicar</option><option value="1" <?= !empty($articulo['publicar_web'])?'selected':'' ?>>Sí publicar artículo en WEB</option></select>
      </div>
      <div class="record-form__row"><label>Detalle</label><textarea name="detalle_web" rows="6"><?= av($articulo,'detalle_web') ?></textarea></div>
    </div>

    <div class="record-form__actions record-form__actions--distribuidas">
      <div class="record-form__actions-grupo">
        <button class="btn btn--secondary" type="submit" name="guardar" value="1">✅ Guardar</button>
        <a class="btn btn--secondary" href="articulo_form.php">➕ Nuevo</a>
        <?php if ($esExistente): ?>
          <button type="submit" form="form-borrar-articulo" class="btn btn--danger" onclick="return confirm('¿Eliminar este artículo?');">❌ Borrar</button>
        <?php else: ?>
          <span class="btn btn--disabled">❌ Borrar</span>
        <?php endif; ?>
      </div>
      <div class="record-form__actions-grupo record-form__actions-grupo--derecha">
        <?php if ($idAnterior): ?>
          <a class="btn btn--secondary" href="articulo_form.php?id=<?= (int) $idAnterior ?>&volver=<?= $volverParam ?>&origen=<?= $origenId ?>">⬅️ Anterior</a>
        <?php endif; ?>
        <?php if ($idSiguiente): ?>
          <a class="btn btn--secondary" href="articulo_form.php?id=<?= (int) $idSiguiente ?>&volver=<?= $volverParam ?>&origen=<?= $origenId ?>">➡️ Siguiente</a>
        <?php endif; ?>
        <a class="btn btn--secondary" href="<?= htmlspecialchars($volverListado) ?><?= strpos($volverListado, '?') !== false ? '&' : '?' ?>resaltar=<?= $esExistente ? (int) $articulo['id'] : 0 ?>&origen=<?= $origenId ?>">↩️ Volver</a>
      </div>
    </div>
  </form>

  <?php if ($esExistente): ?>
  <form id="form-borrar-articulo" method="post" action="articulo_borrar.php" style="display:none;">
    <input type="hidden" name="id" value="<?= (int) $articulo['id'] ?>">
  </form>
  <?php endif; ?>
</section>
<script>
function mostrarTabArt(tab, boton) {
  document.querySelectorAll('.art-tab').forEach(function (t) {
    t.style.display = (t.getAttribute('data-tab') === tab) ? '' : 'none';
  });
  document.querySelectorAll('.ficha-tabs__tab').forEach(function (b) { b.classList.remove('ficha-tabs__tab--active'); });
  boton.classList.add('ficha-tabs__tab--active');
}
</script>
<?php require __DIR__ . '/includes/footer.php'; ?>
