<?php
define('APP_NOMBRE', 'Cloud Opticas');
define('APP_VERSION', '1.0.122');
