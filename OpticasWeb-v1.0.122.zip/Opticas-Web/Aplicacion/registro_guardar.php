<?php
require __DIR__ . '/includes/auth.php';
requireLogin();
require __DIR__ . '/db.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: index.php');
    exit;
}

$config = require __DIR__ . '/includes/grids_config.php';
$tabla = $_POST['tabla'] ?? '';

if (!isset($config[$tabla])) {
    header('Location: index.php');
    exit;
}

$pdo = obtenerConexion();
$columnas = array_keys($config[$tabla]['columnas']);

$contexto = [];
foreach ($_POST as $clave => $valor) {
    if (str_starts_with($clave, 'ctx_')) {
        $contexto[substr($clave, 4)] = $valor;
    }
}

$datos = [];
foreach ($columnas as $col) {
    $valor = trim($_POST[$col] ?? '');
    $datos[$col] = ($col === 'fecha' && $valor === '') ? null : $valor;
}

// No guardamos filas completamente vacías (alguien pulsó "+" sin escribir nada)
$hayContenido = false;
foreach ($datos as $v) {
    if ($v !== null && $v !== '') {
        $hayContenido = true;
        break;
    }
}

if ($hayContenido) {
    $columnasSql = array_merge(array_keys($contexto), $columnas);
    $marcadores = array_map(fn($c) => ":$c", $columnasSql);
    $sql = "INSERT INTO `$tabla` (" . implode(', ', $columnasSql) . ') VALUES (' . implode(', ', $marcadores) . ')';
    $pdo->prepare($sql)->execute(array_merge($contexto, $datos));
}

$clienteId = (int) ($contexto['cliente_id'] ?? 0);
$volver = $_POST['volver'] ?? ('index.php?id=' . $clienteId);
header('Location: ' . $volver);
exit;
