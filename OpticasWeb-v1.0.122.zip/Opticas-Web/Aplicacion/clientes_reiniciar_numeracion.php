<?php
require __DIR__ . '/includes/auth.php';
requireAdmin();
require __DIR__ . '/db.php';

$pdo = obtenerConexion();

// Numeración preliminar: para cada cliente, su número actual y el que
// tendría (1, 2, 3...) siguiendo el orden actual de número.
$clientes = $pdo->query(
    'SELECT id, nombre, apellidos FROM clientes ORDER BY id ASC'
)->fetchAll();

$preliminar = [];
$nuevo = 1;
foreach ($clientes as $c) {
    $preliminar[] = [
        'actual'    => (int) $c['id'],
        'nuevo'     => $nuevo,
        'nombre'    => $c['nombre'],
        'apellidos' => $c['apellidos'],
        'cambia'    => ((int) $c['id']) !== $nuevo,
    ];
    $nuevo++;
}
$total = count($preliminar);
$cuantosCambian = count(array_filter($preliminar, fn($p) => $p['cambia']));

// --- Ejecutar la renumeración (solo tras confirmar en el segundo paso) ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && !empty($_POST['confirmar_definitivo'])) {
    $tablas = array_values(array_filter(tablasConClienteId(), fn($t) => tablaExiste($pdo, $t)));
    $idsActuales = array_column($preliminar, 'actual');

    $pdo->beginTransaction();
    try {
        $offset = 1000000; // rango temporal para no chocar con los ids reales durante el cambio

        $pdo->exec("UPDATE clientes SET id = id + $offset");
        foreach ($tablas as $tabla) {
            $pdo->exec("UPDATE `$tabla` SET cliente_id = cliente_id + $offset");
        }

        $nuevoId = 1;
        foreach ($idsActuales as $idAntiguo) {
            $idTemporal = $idAntiguo + $offset;

            $pdo->prepare('UPDATE clientes SET id = :nuevo WHERE id = :temp')
                ->execute(['nuevo' => $nuevoId, 'temp' => $idTemporal]);

            foreach ($tablas as $tabla) {
                $pdo->prepare("UPDATE `$tabla` SET cliente_id = :nuevo WHERE cliente_id = :temp")
                    ->execute(['nuevo' => $nuevoId, 'temp' => $idTemporal]);
            }

            $nuevoId++;
        }

        $pdo->commit();
    } catch (Throwable $e) {
        $pdo->rollBack();
        header('Location: index.php?error=' . urlencode('No se pudo reiniciar la numeración. No se ha cambiado nada.'));
        exit;
    }

    // ALTER TABLE es DDL (no transaccional en MySQL); se ejecuta aparte.
    $pdo->exec('ALTER TABLE clientes AUTO_INCREMENT = ' . $nuevoId);

    header('Location: index.php?renumerado=1');
    exit;
}

// ¿Se ha pedido ya ver la vista preliminar?
$mostrarPreliminar = ($_SERVER['REQUEST_METHOD'] === 'POST' && !empty($_POST['ver_preliminar']));

$titulo = 'Reiniciar numeración';
$activo = 'clientes';
require __DIR__ . '/includes/header.php';
?>
<section class="panel">
  <div class="panel__title-bar"><span class="panel__title-pill">Reiniciar numeración</span></div>

  <p>Vuelve a numerar <strong>todos</strong> los clientes de forma correlativa
  (1, 2, 3...) según su orden actual de número, cerrando los huecos que hayan
  quedado al borrar clientes intermedios.</p>

  <p>No se pierde ningún dato: todo lo que cuelga de cada cliente (Ficha
  Gafas, Ficha Lentillas, Audífonos...) se actualiza junto con su nuevo
  número. <strong>Esta operación no se puede deshacer.</strong></p>

  <p>Clientes: <strong><?= $total ?></strong> · Cambiarán de número:
  <strong><?= $cuantosCambian ?></strong></p>

  <?php if (!$mostrarPreliminar): ?>

    <!-- Paso 1: preguntar si está seguro y ofrecer ver la vista preliminar -->
    <div class="form-error">
      ¿Está seguro de que quiere reiniciar la numeración de <strong>todos</strong>
      los registros? Antes de aplicarla, puede revisar cómo quedaría.
    </div>
    <form method="post">
      <div class="record-form__actions">
        <a class="btn btn--secondary" href="index.php">↩️ Cancelar</a>
        <button class="btn btn--primary" type="submit" name="ver_preliminar" value="1">Ver vista preliminar</button>
      </div>
    </form>

  <?php else: ?>

    <!-- Paso 2: mostrar la tabla preliminar completa y la confirmación final -->
    <p class="panel__footer">Vista preliminar (los que cambian aparecen resaltados):</p>

    <div class="table-scroll" style="max-height:38vh; overflow-y:auto;">
      <table class="data-table">
        <thead>
          <tr>
            <th>Nº actual</th>
            <th>Nº nuevo</th>
            <th>Nombre</th>
            <th>Apellidos</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($preliminar as $p): ?>
            <tr <?= $p['cambia'] ? 'class="fila-resaltada"' : '' ?>>
              <td><?= $p['actual'] ?></td>
              <td><strong><?= $p['nuevo'] ?></strong></td>
              <td><?= htmlspecialchars($p['nombre']) ?></td>
              <td><?= htmlspecialchars($p['apellidos'] ?? '') ?></td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>

    <form method="post" style="margin-top:1.2rem;">
      <div class="record-form__row record-form__row--checkbox">
        <label><input type="checkbox" name="confirmar_definitivo" value="1" required>
          He revisado la vista preliminar y confirmo que quiero aplicar esta numeración. Entiendo que no se puede deshacer.</label>
      </div>
      <div class="record-form__actions">
        <a class="btn btn--secondary" href="index.php">↩️ Cancelar</a>
        <button class="btn btn--danger" type="submit">Aplicar numeración definitivamente</button>
      </div>
    </form>

  <?php endif; ?>
</section>
<?php require __DIR__ . '/includes/footer.php'; ?>
