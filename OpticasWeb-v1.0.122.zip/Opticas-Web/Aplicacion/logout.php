<?php
require __DIR__ . '/includes/auth.php';

$_SESSION = [];
session_destroy();
// Las peticiones de cierre automático se envían con sendBeacon y no necesitan
// una redirección HTML; responder sin contenido evita que el navegador intente
// pintar una página mientras la ventana se está cerrando.
if ($_SERVER['REQUEST_METHOD'] === 'POST' || ($_GET['auto'] ?? '') === '1') {
    http_response_code(204);
    exit;
}
header('Location: inicio.php');
exit;
