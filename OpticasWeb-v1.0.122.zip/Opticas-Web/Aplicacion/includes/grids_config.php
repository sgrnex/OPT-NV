<?php
// Lista blanca de tablas "repetibles" (filas que se van añadiendo con el
// icono "+", como en el programa original) y sus columnas editables, en
// el orden en que deben mostrarse. Los manejadores genéricos
// (registro_guardar.php / registro_borrar.php) solo actúan sobre las
// tablas que aparecen aquí.
return [
    'graduaciones' => [
        'columnas' => [
            'fecha' => 'Fecha', 'eje' => 'Eje', 'cil' => 'Cil.', 'esf' => 'Esf.',
            'av' => 'A.V.', 'avsin' => 'AVSin', 'di' => 'DI', 'alt' => 'Alt.',
            'adic' => 'Adic.', 'pris' => 'Pris.', 'vcor' => 'V.Cor.', 'optico' => 'Óptico',
        ],
    ],
    'graduaciones_productos' => [
        'columnas' => ['fecha' => 'Fecha', 'producto' => 'Producto', 'precio' => 'Precio'],
    ],
    'monturas' => [
        'columnas' => ['fecha' => 'Fecha', 'descripcion' => 'Descripción', 'precio' => 'Precio'],
    ],
    'gafas_sol' => [
        'columnas' => ['fecha' => 'Fecha', 'descripcion' => 'Descripción', 'precio' => 'Precio'],
    ],
    'lentillas_con_gafas' => [
        'columnas' => [
            'fecha' => 'Fecha', 'eje' => 'Eje', 'cil' => 'Cil.', 'esf' => 'Esf.',
            'av' => 'A.V.', 'avsin' => 'AVSin',
        ],
    ],
    'lentillas_prueba' => [
        'columnas' => [
            'fecha' => 'Fecha', 'eje' => 'Eje', 'cil' => 'Cil.', 'esf' => 'Esf.',
            'radio' => 'Radio', 'potencia' => 'Potencia', 'diametro' => 'Diám.', 'adicion' => 'Adición',
        ],
    ],
    'lentillas_definitivas' => [
        'columnas' => [
            'fecha' => 'Fecha', 'eje' => 'Eje', 'cil' => 'Cil.', 'esf' => 'Esf.',
            'radio' => 'Radio', 'potencia' => 'Pot.', 'adicion' => 'Adición', 'diametro' => 'Diám.',
            'diametro_zo' => 'Diam.Z.Op.', 'curva' => 'Curva', 'espesor' => 'Espesor',
            'tipo' => 'Tipo', 'material' => 'Material', 'formula' => 'Fórmula', 'obs' => 'Obs.',
        ],
    ],
    'lentillas_revisiones' => [
        'columnas' => [
            'fecha' => 'Fecha', 'ojo' => 'Ojo', 'radio' => 'Radio',
            'potencia' => 'Potencia', 'diametro' => 'Diámetro', 'observaciones' => 'Observaciones',
        ],
    ],
    'audiometrias' => [
        'columnas' => [
            'fecha' => 'Fecha', 'hz125' => '125', 'hz250' => '250', 'hz500' => '500',
            'hz750' => '750', 'hz1000' => '1000', 'hz1500' => '1500', 'hz2000' => '2000',
            'hz3000' => '3000', 'hz4000' => '4000', 'hz6000' => '6000', 'hz8000' => '8000',
            'haic' => 'HAIC',
        ],
    ],
];
