<?php if ($estaLogueado): ?>
      </main>
    </div>
  </div>
<?php else: ?>
      </main>
<?php endif; ?>
</body>
</html>
