<?php
require_once __DIR__ . '/../version.php';

// Estructura del menú lateral: cada grupo es una sección (como en el
// programa original). Los elementos sin "href" son apartados de fases
// futuras y se muestran deshabilitados, para que el menú ya se parezca
// al definitivo aunque todavía no todo funcione.
$estaLogueado = usuarioActual() !== null;
$u = usuarioActual();
$esAdmin = $estaLogueado && $u['rol'] === 'admin';
$mostrarPortadaLogin = !empty($portadaLogin) && !$estaLogueado;
$mostrarShell = $estaLogueado;

function iconoMenu(string $clave): string
{
    $paths = [
        'inicio' => '<path d="M3 11.5 12 4l9 7.5"/><path d="M5.5 10.5V20h13v-9.5"/><path d="M9.5 20v-6h5v6"/>',
        'clientes' => '<circle cx="9" cy="8" r="3"/><path d="M3.5 20v-2.2A4.8 4.8 0 0 1 8.3 13h1.4a4.8 4.8 0 0 1 4.8 4.8V20"/><path d="M15.5 5.4a3 3 0 0 1 0 5.2M16.5 13.2a4.8 4.8 0 0 1 4 4.7V20"/>',
        'ventas' => '<path d="M3 4h2l2.2 10.2h10.7l2-7.2H6"/><circle cx="9" cy="19" r="1.3"/><circle cx="17" cy="19" r="1.3"/>',
        'ficheros' => '<path d="M3 6.5h7l2 2H21V20H3z"/><path d="M3 6.5V4h7l2 2h6"/>',
        'almacen' => '<path d="m4 8 8-4 8 4-8 4z"/><path d="M4 8v9l8 4 8-4V8M12 12v9"/>',
        'compras' => '<path d="M6 3h12v18l-3-2-3 2-3-2-3 2z"/><path d="M9 8h6M9 12h6M9 16h4"/>',
        'contabilidad' => '<rect x="3" y="5" width="18" height="15" rx="2"/><path d="M16 12h5M7 9h5M7 13h2M7 17h2M12 13h2M12 17h2M17 17h.01"/>',
        'configuracion' => '<circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.7 1.7 0 0 0 .3 1.9l.1.1-2.8 2.8-.1-.1a1.7 1.7 0 0 0-1.9-.3 1.7 1.7 0 0 0-1 1.6v.2h-4V21a1.7 1.7 0 0 0-1-1.6 1.7 1.7 0 0 0-1.9.3l-.1.1L4.2 17l.1-.1a1.7 1.7 0 0 0 .3-1.9A1.7 1.7 0 0 0 3 14H2.8v-4H3a1.7 1.7 0 0 0 1.6-1 1.7 1.7 0 0 0-.3-1.9L4.2 7 7 4.2l.1.1a1.7 1.7 0 0 0 1.9.3A1.7 1.7 0 0 0 10 3V2.8h4V3a1.7 1.7 0 0 0 1 1.6 1.7 1.7 0 0 0 1.9-.3l.1-.1L19.8 7l-.1.1a1.7 1.7 0 0 0-.3 1.9 1.7 1.7 0 0 0 1.6 1h.2v4H21a1.7 1.7 0 0 0-1.6 1z"/>',
    ];
    return '<svg viewBox="0 0 24 24" aria-hidden="true" focusable="false">' . ($paths[$clave] ?? $paths['ficheros']) . '</svg>';
}

$menu = [
    [
        'clave' => 'clientes', 'nombre' => 'Clientes',
        'items' => [
            ['clave' => 'clientes', 'nombre' => 'Clientes', 'href' => 'index.php'],
            ['nombre' => 'Mailing'],
            ['nombre' => 'Agenda'],
        ],
    ],
    [
        'clave' => 'ventas', 'nombre' => 'Ventas',
        'items' => [
            ['nombre' => 'Nueva venta'], ['nombre' => 'Ventas'],
            ['nombre' => 'Estadísticas'], ['nombre' => 'Facturas'],
            ['clave'=>'encargos', 'nombre' => 'Encargos', 'href'=>'encargos.php'], ['nombre' => 'Presupuestos'],
        ],
    ],
    [
        'clave' => 'ficheros', 'nombre' => 'Ficheros',
        'items' => [
            ['clave' => 'proveedores', 'nombre' => 'Proveedores', 'href' => 'proveedores.php'],
            ['clave'=>'vendedores', 'nombre'=>'Vendedores', 'href'=>'fichero_mantenimiento.php?tipo=vendedores'],
            ['clave'=>'doctores', 'nombre'=>'Doctores', 'href'=>'fichero_mantenimiento.php?tipo=doctores'],
            ['clave'=>'opticos', 'nombre'=>'Ópticos', 'href'=>'fichero_mantenimiento.php?tipo=opticos'],
            $esAdmin
                ? ['clave' => 'usuarios', 'nombre' => 'Usuarios', 'href' => 'usuarios.php']
                : ['nombre' => 'Usuarios'],
        ],
    ],
    [
        'clave' => 'almacen', 'nombre' => 'Almacén',
        'items' => [
            ['clave' => 'articulos', 'nombre' => 'Artículos', 'href' => 'almacen_articulos.php'],
            ['clave' => 'inventario', 'nombre' => 'Inventario', 'href' => 'inventario.php'],
            ['clave' => 'marcas', 'nombre' => 'Marcas', 'href' => 'marcas.php'],
            ['nombre' => 'Almacenes'], ['nombre' => 'Etiquetas'],
        ],
    ],
    [
        'clave' => 'compras', 'nombre' => 'Compras',
        'items' => [['clave' => 'encargos', 'nombre' => 'Encargos/Pedidos', 'href' => 'encargos.php'], ['nombre' => 'Albaranes'], ['nombre' => 'Facturas']],
    ],
    [
        'clave' => 'contabilidad', 'nombre' => 'Contabilidad',
        'items' => [
            ['nombre' => 'Asientos'], ['nombre' => 'Apertura de caja'],
            ['nombre' => 'Cierre de caja'], ['nombre' => 'Exportación Contaplus'],
        ],
    ],
    [
        'clave' => 'configuracion', 'nombre' => 'Configuración',
        'items' => [
            ['nombre' => 'Empresas'],
            $esAdmin
                ? ['clave' => 'delegaciones', 'nombre' => 'Delegaciones', 'href' => 'delegaciones.php']
                : ['nombre' => 'Delegaciones'],
            ['nombre' => 'Tablas auxiliares'], ['nombre' => 'Envío SMS'],
            ['clave' => 'backup_restauracion', 'nombre' => 'Backup y Restauración (Local)', 'href' => 'backup_restauracion.php'],
            ['clave' => 'migracion_datos', 'nombre' => 'Migración de datos', 'href' => 'migracion_datos.php'],
        ],
    ],
];

// Abre automáticamente el grupo al que pertenece la página actual, y
// calcula el nombre de la sección activa (el pequeño rótulo de arriba,
// como "Clientes" o "Ficheros" en el programa original).
$seccionActual = (($activo ?? '') === 'inicio') ? 'Inicio' : '';
foreach ($menu as $i => $grupo) {
    $menu[$i]['abierto'] = false;
    foreach ($grupo['items'] as $item) {
        if (($item['clave'] ?? null) === ($activo ?? null)) {
            $menu[$i]['abierto'] = true;
            $seccionActual = $grupo['nombre'];
        }
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title><?= htmlspecialchars(APP_NOMBRE) ?> v<?= htmlspecialchars(APP_VERSION) ?> · <?= htmlspecialchars($titulo ?? '') ?></title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link href="https://fonts.googleapis.com/css2?family=IBM+Plex+Sans:wght@400;500;600;700&family=IBM+Plex+Mono:wght@500&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="css/style.css?v=1.0.91">
  <link rel="icon" href="icono_cloud_opticas.ico?v=1.0.91-icon-1" type="image/x-icon">
<?php if ($estaLogueado): ?>
  <script src="js/session_guard.js?v=1.0.91" defer></script>
<?php endif; ?>
</head>
<body class="<?= $mostrarPortadaLogin ? 'body--portada-login' : '' ?>">
<?php if ($estaLogueado): ?>
  <div class="app-shell">
    <aside class="sidebar">
      <a class="sidebar__brand" href="inicio.php"><img class="sidebar__brand-icon" src="icono_cloud_opticas.ico" alt=""><span><?= htmlspecialchars(APP_NOMBRE) ?></span><span class="sidebar__version">v<?= htmlspecialchars(APP_VERSION) ?></span></a>
      <nav class="sidebar__nav" aria-label="Menú principal">
        <a href="inicio.php" class="sidebar__home <?= ($activo ?? '') === 'inicio' ? 'sidebar__home--active' : '' ?>"><span class="sidebar__icon"><?= iconoMenu('inicio') ?></span><span>Inicio</span></a>
        <?php foreach ($menu as $grupo): ?>
          <details class="sidebar__group" <?= $grupo['abierto'] ? 'open' : '' ?>>
            <summary class="sidebar__group-title">
              <span class="sidebar__icon"><?= iconoMenu($grupo['clave']) ?></span>
              <?= htmlspecialchars($grupo['nombre']) ?>
            </summary>
            <ul class="sidebar__items">
              <?php foreach ($grupo['items'] as $item): ?>
                <li>
                  <?php if (!empty($item['href']) && $estaLogueado): ?>
                    <a href="<?= htmlspecialchars($item['href']) ?>"
                       class="sidebar__item <?= ($activo ?? '') === $item['clave'] ? 'sidebar__item--active' : '' ?>">
                      <?= htmlspecialchars($item['nombre']) ?>
                    </a>
                  <?php else: ?>
                    <span class="sidebar__item sidebar__item--disabled" title="Inicia sesión para acceder">
                      <?= htmlspecialchars($item['nombre']) ?>
                    </span>
                  <?php endif; ?>
                </li>
              <?php endforeach; ?>
            </ul>
          </details>
        <?php endforeach; ?>
      </nav>
      <a class="sidebar__logout" href="logout.php">↪ Salir</a>
    </aside>

    <div class="main">
      <div class="topbar">
        <span class="topbar__section"><?= htmlspecialchars($mostrarPortadaLogin ? 'CLOUD OPTICAS' : $seccionActual) ?></span>
        <span class="topbar__spacer"></span>
        <?php if ($estaLogueado): ?>
          <span class="topbar__user"><?= htmlspecialchars($u['nombre']) ?></span>
          <a href="logout.php" class="topbar__link">Salir</a>
        <?php else: ?>
          <span class="topbar__user">Acceso seguro</span>
        <?php endif; ?>
      </div>
      <main class="page">
<?php elseif ($mostrarPortadaLogin): ?>
      <main class="page page--portada-login">
<?php else: ?>
      <main class="page page--center">
<?php endif; ?>
