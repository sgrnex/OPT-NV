<?php

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

function usuarioActual(): ?array
{
    return $_SESSION['usuario'] ?? null;
}

/**
 * Devuelve una ruta local para continuar después del inicio de sesión.
 * Nunca se aceptan destinos absolutos para evitar redirecciones externas.
 */
function destinoLocalSeguro(?string $destino, string $predeterminado = 'index.php'): string
{
    $destino = trim((string) $destino);
    if ($destino === '' || preg_match('/^(?:[a-z][a-z0-9+.-]*:)?\\/\\//i', $destino)) {
        return $predeterminado;
    }
    return str_replace(["\r", "\n"], '', $destino);
}

function requireLogin(): void
{
    if (!usuarioActual()) {
        $destino = 'inicio.php?next=' . urlencode(destinoLocalSeguro($_SERVER['REQUEST_URI'] ?? 'index.php'));
        header('Location: ' . $destino);
        exit;
    }
}

function requireAdmin(): void
{
    requireLogin();
    if (usuarioActual()['rol'] !== 'admin') {
        header('Location: index.php');
        exit;
    }
}
