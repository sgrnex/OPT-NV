<?php
// Se espera que la página que incluye este fichero ya haya definido:
//   $cliente   -> array del cliente (o null si es un alta nueva)
//   $tabActiva -> 'datos' | 'gafas' | '21puntos' | 'lentillas' | 'audifonos' | 'observaciones'
$idCliente = $cliente['id'] ?? null;
$volverQS = !empty($_GET['volver']) ? '&volver=' . urlencode($_GET['volver']) : '';
$origenQS = !empty($_GET['origen']) ? '&origen=' . (int)$_GET['origen'] : ($idCliente ? '&origen=' . (int)$idCliente : '');

$pestanas = [
    ['clave' => 'datos', 'nombre' => 'Datos Cliente', 'href' => 'cliente_form.php' . ($idCliente ? "?id=$idCliente$volverQS$origenQS" : '')],
    ['clave' => 'gafas', 'nombre' => 'Ficha Gafas', 'href' => $idCliente ? "ficha_gafas.php?id=$idCliente$volverQS$origenQS" : null],
    ['clave' => '21puntos', 'nombre' => '21 Puntos', 'href' => $idCliente ? "cliente_21puntos.php?id=$idCliente$volverQS$origenQS" : null],
    ['clave' => 'lentillas', 'nombre' => 'Ficha Lentillas', 'href' => $idCliente ? "ficha_lentillas.php?id=$idCliente$volverQS$origenQS" : null],
    ['clave' => 'audifonos', 'nombre' => 'Audífonos', 'href' => $idCliente ? "cliente_audifonos.php?id=$idCliente$volverQS$origenQS" : null],
    ['clave' => 'observaciones', 'nombre' => 'Observaciones', 'href' => $idCliente ? "cliente_observaciones.php?id=$idCliente$volverQS$origenQS" : null],
    ['clave' => 'ventas_cliente', 'nombre' => 'Ventas Cliente', 'href' => $idCliente ? "cliente_ventas.php?id=$idCliente$volverQS$origenQS" : null],
    ['clave' => 'cuentas_cliente', 'nombre' => 'Cuentas Cliente'],
];
?>
<div class="ficha-tabs">
  <?php foreach ($pestanas as $p): ?>
    <?php $activa = $tabActiva === $p['clave']; ?>
    <?php if (!empty($p['href']) && $idCliente): ?>
      <a href="<?= htmlspecialchars($p['href']) ?>"
         class="ficha-tabs__tab <?= $activa ? 'ficha-tabs__tab--active' : '' ?>"><?= htmlspecialchars($p['nombre']) ?></a>
    <?php else: ?>
      <span class="ficha-tabs__tab ficha-tabs__tab--disabled"
            title="<?= $idCliente ? 'Próxima fase' : 'Guarda primero los datos de contacto' ?>"><?= htmlspecialchars($p['nombre']) ?></span>
    <?php endif; ?>
  <?php endforeach; ?>
</div>
