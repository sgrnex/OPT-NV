<?php
require_once __DIR__ . '/pdf_simple.php';

// ---------- Helpers HTML ----------

function listadoTablaHtml(array $columnas, array $filas, string $clase = 'data-table'): string
{
    $h = '<table class="' . $clase . '"><thead><tr>';
    foreach ($columnas as $col) {
        $h .= '<th>' . htmlspecialchars($col) . '</th>';
    }
    $h .= '</tr></thead><tbody>';
    if (empty($filas)) {
        $h .= '<tr><td colspan="' . count($columnas) . '" class="empty-row">Sin resultados.</td></tr>';
    }
    foreach ($filas as $fila) {
        $h .= '<tr>';
        foreach ($fila as $celda) {
            $h .= '<td>' . htmlspecialchars((string) $celda) . '</td>';
        }
        $h .= '</tr>';
    }
    $h .= '</tbody></table>';
    return $h;
}

function listadoCuerpoHtml(array $datos): string
{
    if (($datos['modo'] ?? 'tabla') === 'ficha') {
        $h = '';
        foreach ($datos['fichas'] as $ficha) {
            $h .= '<div class="listado-ficha">';
            $h .= '<h3 class="listado-ficha__cli">' . htmlspecialchars($ficha['cliente']) . '</h3>';
            $colsPaciente = array_slice($datos['cols_cliente'], 2);
            $datosPaciente = array_slice($ficha['datos'], 2);
            if ($colsPaciente) $h .= listadoTablaHtml($colsPaciente, [$datosPaciente]);
            if (!empty($ficha['detalle']['filas'])) {
                $h .= '<div class="listado-ficha__det">' . listadoTablaHtml($ficha['detalle']['columnas'], $ficha['detalle']['filas']) . '</div>';
            } else {
                $h .= '<p class="listado-ficha__vacio">Sin registros de detalle.</p>';
            }
            $h .= '</div>';
        }
        return $h;
    }
    return listadoTablaHtml($datos['columnas'], $datos['filas']);
}

function listadoNumRegistros(array $datos): int
{
    return ($datos['modo'] ?? 'tabla') === 'ficha' ? count($datos['fichas']) : count($datos['filas']);
}

// ---------- Salidas ----------

function exportarListadoPantalla(array $datos): void
{
    $titulo = $datos['titulo'];
    $activo = $datos['activo'] ?? 'clientes';
    require __DIR__ . '/header.php';
    echo '<section class="panel">';
    echo '<div class="panel__title-bar"><span class="panel__title-pill">' . htmlspecialchars($titulo) . '</span></div>';
    echo '<p class="panel__footer">' . listadoNumRegistros($datos) . ' registro' . (listadoNumRegistros($datos) !== 1 ? 's' : '') . '</p>';
    echo '<div class="table-scroll">' . listadoCuerpoHtml($datos) . '</div>';
    echo '<div class="record-form__actions"><a class="btn btn--secondary" href="' . htmlspecialchars($datos['volver'] ?? 'clientes_listados.php') . '">Volver a listados</a></div>';
    echo '</section>';
    require __DIR__ . '/footer.php';
}

function exportarListadoImprimir(array $datos, array $opciones): void
{
    $tam = ['muy_pequeno'=>'8px','pequeno'=>'10px','normal'=>'12px','grande'=>'15px','muy_grande'=>'18px'][$opciones['tam_letra'] ?? 'normal'] ?? '12px';
    $fuente = ['arial'=>'Arial,Helvetica,sans-serif','times'=>'Times New Roman,serif','courier'=>'Courier New,monospace'][$opciones['fuente'] ?? 'arial'] ?? 'Arial,Helvetica,sans-serif';
    $orient = ($opciones['orientacion'] ?? 'vertical') === 'horizontal' ? 'landscape' : 'portrait';
    header('Content-Type: text/html; charset=utf-8');
    echo "<!DOCTYPE html><html lang='es'><head><meta charset='utf-8'><title>" . htmlspecialchars($datos['titulo']) . "</title>";
    echo "<style>";
    echo "@page { size: A4 $orient; margin: 12mm; }";
    echo "body{font-family:$fuente;font-size:$tam;color:#000}";
    echo "h2{font-size:1.3em}h3{font-size:1.05em;margin:0.8em 0 0.3em}";
    echo "table{border-collapse:collapse;width:100%;margin-bottom:0.4em}";
    echo "th,td{border:1px solid #999;padding:3px 5px;text-align:left}th{background:#e0e0e0}";
    echo ".listado-ficha{margin-bottom:1em;page-break-inside:avoid}";
    echo ".listado-ficha__det{margin-left:1em}";
    echo ".barra-print{margin-bottom:1em}";
    echo "@media print{.barra-print{display:none}}";
    echo "</style></head><body>";
    echo "<div class='barra-print'><button onclick='window.print()'>🖨️ Imprimir</button> <a href='clientes_listados.php'>Volver</a></div>";
    echo "<h2>" . htmlspecialchars($datos['titulo']) . "</h2>";
    echo listadoCuerpoHtml($datos);
    echo "<script>window.onload=function(){window.print();}</script>";
    echo "</body></html>";
}

function exportarListadoHtml(array $datos): void
{
    $nombre = ($datos['archivo'] ?? 'listado_clientes') . '_' . date('Ymd') . '.html';
    header('Content-Type: text/html; charset=utf-8');
    header('Content-Disposition: attachment; filename="' . $nombre . '"');
    echo "<!DOCTYPE html><html lang='es'><head><meta charset='utf-8'><title>" . htmlspecialchars($datos['titulo']) . "</title>";
    echo "<style>body{font-family:sans-serif;font-size:12px}table{border-collapse:collapse;width:100%;margin-bottom:6px}th,td{border:1px solid #999;padding:4px 6px;text-align:left}th{background:#5f8069;color:#fff}h3{margin:12px 0 4px}</style>";
    echo "</head><body><h2>" . htmlspecialchars($datos['titulo']) . "</h2>";
    echo listadoCuerpoHtml($datos);
    echo "</body></html>";
}

// Para CSV/Excel/XML en modo ficha, se aplana: cada fila de detalle
// repite los datos del cliente delante.
function listadoAplanado(array $datos, bool $repetirCliente = true): array
{
    if (($datos['modo'] ?? 'tabla') !== 'ficha') {
        return ['columnas' => $datos['columnas'], 'filas' => $datos['filas']];
    }
    $primera = $datos['fichas'][0] ?? null;
    $colsDetalle = $primera ? $primera['detalle']['columnas'] : [];
    $columnas = array_merge($datos['cols_cliente'], $colsDetalle);
    $filas = [];
    foreach ($datos['fichas'] as $ficha) {
        if (empty($ficha['detalle']['filas'])) {
            $filas[] = array_merge($ficha['datos'], array_fill(0, count($colsDetalle), ''));
        } else {
            foreach ($ficha['detalle']['filas'] as $indice => $fd) {
                $datosCliente = ($repetirCliente || $indice === 0)
                    ? $ficha['datos']
                    : array_fill(0, count($ficha['datos']), '');
                $filas[] = array_merge($datosCliente, $fd);
            }
        }
    }
    return ['columnas' => $columnas, 'filas' => $filas];
}

function exportarListadoCsv(array $datos): void
{
    $plano = listadoAplanado($datos);
    while (ob_get_level() > 0) { ob_end_clean(); }
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="' . ($datos['archivo'] ?? 'listado_clientes') . '_' . date('Ymd') . '.csv"');
    $out = fopen('php://output', 'w');
    fprintf($out, "\xEF\xBB\xBF");
    fputcsv($out, $plano['columnas'], ';');
    foreach ($plano['filas'] as $fila) {
        fputcsv($out, $fila, ';');
    }
    fclose($out);
}

function exportarListadoExcel(array $datos): void
{
    $plano = listadoAplanado($datos);
    while (ob_get_level() > 0) { ob_end_clean(); }
    header('Content-Type: application/vnd.ms-excel; charset=utf-8');
    header('Content-Disposition: attachment; filename="' . ($datos['archivo'] ?? 'listado_clientes') . '_' . date('Ymd') . '.xls"');
    echo "\xEF\xBB\xBF<!doctype html><html><head><meta charset=\"utf-8\"><style>td,th{border:1px solid #ccc;padding:4px}th{background:#5f8069;color:#fff}</style></head><body><table><thead><tr>";
    foreach ($plano['columnas'] as $col) {
        echo '<th>' . htmlspecialchars((string)$col, ENT_QUOTES, 'UTF-8') . '</th>';
    }
    echo '</tr></thead><tbody>';
    foreach ($plano['filas'] as $fila) {
        echo '<tr>';
        foreach ($fila as $celda) {
            echo '<td>' . htmlspecialchars((string) $celda, ENT_QUOTES, 'UTF-8') . '</td>';
        }
        echo '</tr>';
    }
    echo '</tbody></table></body></html>';
}

function exportarListadoXml(array $datos): void
{
    $plano = listadoAplanado($datos);
    header('Content-Type: application/xml; charset=utf-8');
    header('Content-Disposition: attachment; filename="' . ($datos['archivo'] ?? 'listado_clientes') . '_' . date('Ymd') . '.xml"');
    $claves = array_map(function ($c) {
        $c = strtolower($c);
        $c = strtr($c, ['á'=>'a','é'=>'e','í'=>'i','ó'=>'o','ú'=>'u','ñ'=>'n','º'=>'','.'=>'']);
        $c = preg_replace('/[^a-z0-9]+/', '_', $c);
        return trim($c, '_') ?: 'campo';
    }, $plano['columnas']);
    echo '<?xml version="1.0" encoding="UTF-8"?>' . "\n<listado>\n";
    foreach ($plano['filas'] as $fila) {
        echo "  <registro>\n";
        foreach ($fila as $i => $celda) {
            $tag = $claves[$i] ?? ('campo' . $i);
            echo "    <$tag>" . htmlspecialchars((string) $celda) . "</$tag>\n";
        }
        echo "  </registro>\n";
    }
    echo "</listado>\n";
}

function exportarListadoRtf(array $datos): void
{
    $plano = listadoAplanado($datos);
    header('Content-Type: application/rtf; charset=utf-8');
    header('Content-Disposition: attachment; filename="' . ($datos['archivo'] ?? 'listado_clientes') . '_' . date('Ymd') . '.rtf"');
    $esc = function ($t) {
        $t = (string) $t;
        $out = '';
        foreach (preg_split('//u', $t, -1, PREG_SPLIT_NO_EMPTY) as $ch) {
            $code = mb_ord($ch, 'UTF-8');
            if ($ch === '\\' || $ch === '{' || $ch === '}') $out .= '\\' . $ch;
            elseif ($code > 127) $out .= '\\u' . $code . '?';
            else $out .= $ch;
        }
        return $out;
    };
    echo '{\rtf1\ansi\deff0{\fonttbl{\f0 Arial;}}\fs18 ';
    echo '{\b ' . $esc($datos['titulo']) . '}\par\par ';
    echo '{\b ' . implode(' | ', array_map($esc, $plano['columnas'])) . '}\par ';
    foreach ($plano['filas'] as $fila) {
        echo $esc(implode(' | ', $fila)) . '\par ';
    }
    echo '}';
}

function exportarListadoPdf(array $datos, array $opciones = []): void
{
    $tamMap = ['muy_pequeno'=>7.5,'pequeno'=>8.5,'normal'=>9.5,'grande'=>11,'muy_grande'=>13];
    $fs = $tamMap[$opciones['tam_letra'] ?? 'normal'] ?? 7.5;
    $horizontal = ($opciones['orientacion'] ?? 'vertical') === 'horizontal';
    $numColumnasEstimadas = ($datos['modo'] ?? 'tabla') === 'ficha' ? count($datos['cols_cliente'] ?? []) + count(($datos['fichas'][0]['detalle']['columnas'] ?? [])) : count($datos['columnas'] ?? []);
    if (!$horizontal && $numColumnasEstimadas >= 9) $horizontal = true;

    $ancho = $horizontal ? 842 : 595;
    $alto = $horizontal ? 595 : 842;
    $margen = 40;
    $anchoUtil = $ancho - 2 * $margen;
    $yInicio = $alto - 42;
    $yMin = 40;
    $interlinea = $fs + 2.5;
    // El ancho se expresa en caracteres de la fuente elegida. Cada columna
    // suma tres espacios de separación, y las columnas principales tienen
    // un ancho fijo solicitado por el usuario.
    $anchoCaracter = $fs * 0.56;
    $padCol = $anchoCaracter * 2;

    $c = new ConstructorPdf($ancho, $alto);
    [$fontRegular,$fontBold] = ['arial'=>['F1','F2'],'times'=>['F3','F4'],'courier'=>['F5','F6']][$opciones['fuente'] ?? 'arial'] ?? ['F1','F2'];
    $plano = listadoAplanado($datos, false);
    $numCols = max(1, count($plano['columnas']));
    // Calcula el ancho a partir de cabeceras y datos, con límites para que
    // una descripción excepcional no expulse al resto de columnas.
    $minCol = 38; $maxCol = 150;
    $anchosFijos = [
        'nº' => 5, 'n°' => 5, 'no' => 5,
        'cliente' => 25,
        'nif' => 12, 'cif/nif' => 12, 'cif' => 12,
        'teléfono' => 10, 'telefono' => 10,
        'población' => 12, 'poblacion' => 12,
        'fecha' => 10,
    ];
    $anchos = array_fill(0, $numCols, $minCol);
    foreach ($plano['columnas'] as $i => $col) {
        $clave = function_exists('mb_strtolower') ? mb_strtolower(trim((string)$col), 'UTF-8') : strtolower(trim((string)$col));
        if (isset($anchosFijos[$clave])) {
            $anchos[$i] = max($minCol, $anchosFijos[$clave] * $anchoCaracter + $padCol);
            continue;
        }
        $anchos[$i] = min($maxCol, max($minCol, $c->medirAncho((string)$col, $fontBold, $fs) + $padCol));
        foreach ($plano['filas'] as $fila) {
            $valor = (string)($fila[$i] ?? '');
            $anchos[$i] = min($maxCol, max($anchos[$i], $c->medirAncho($valor, $fontRegular, $fs) + $padCol));
        }
    }
    $suma = array_sum($anchos);
    if ($suma > $anchoUtil) {
        $reducible = $suma - $anchoUtil;
        while ($reducible > 0.1) {
            $candidatas = array_filter($anchos, fn($v) => $v > $minCol + 0.1);
            if (!$candidatas) break;
            $paso = min($reducible / count($candidatas), 10);
            foreach ($anchos as $i => $v) if ($v > $minCol + 0.1) { $d = min($paso, $v - $minCol); $anchos[$i] -= $d; $reducible -= $d; }
        }
    }
    $recortar = function (string $txt, float $ancho, string $fuente = 'F1') use ($c, $fs, $padCol) {
        $limite = max(8, $ancho - $padCol);
        if ($c->medirAncho($txt, $fuente, $fs) <= $limite) {
            return $txt;
        }
        // Ir quitando caracteres hasta que quepa, añadiendo "…"
        $t = $txt;
        while ($t !== '' && $c->medirAncho($t . '...', $fuente, $fs) > $limite) {
            $t = mb_substr($t, 0, -1);
        }
        return $t . '...';
    };

    $pintarCabecera = function () use ($c, $datos, $plano, $margen, $anchoUtil, $anchos, $yInicio, $fs, $interlinea, $recortar, $fontBold) {
        $y = $yInicio;
        $y = $c->parrafo($margen, $y, 90, $datos['titulo'], $fontBold, $fs + 4, $fs + 6);
        $y -= 4;
        $x = $margen;
        foreach ($plano['columnas'] as $i => $col) {
            $c->textoRecortado($x, $y, $anchos[$i], $interlinea, $recortar((string) $col, $anchos[$i], $fontBold), $fontBold, $fs);
            $x += $anchos[$i];
        }
        $y -= 3;
        $c->linea($margen, $y, $margen + $anchoUtil, $y, '0.4 0.4 0.4');
        return $y - $interlinea + 2;
    };

    $y = $pintarCabecera();
    foreach ($plano['filas'] as $fila) {
        if ($y < $yMin) {
            $c->nuevaPagina();
            $y = $pintarCabecera();
        }
        $x = $margen;
        foreach ($fila as $i => $celda) {
            $c->textoRecortado($x, $y, $anchos[$i] ?? $minCol, $interlinea, $recortar((string) $celda, $anchos[$i] ?? $minCol, $fontRegular), $fontRegular, $fs);
            $x += $anchos[$i] ?? $minCol;
        }
        $y -= $interlinea;
    }

    while (ob_get_level() > 0) { ob_end_clean(); }
    header('Content-Type: application/pdf');
    header('Content-Disposition: inline; filename="' . ($datos['archivo'] ?? 'listado_clientes') . '_' . date('Ymd') . '.pdf"');
    echo $c->generarPdf();
}
