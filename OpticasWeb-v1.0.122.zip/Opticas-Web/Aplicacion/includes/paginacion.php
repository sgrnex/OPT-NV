<?php
// Espera: $totalFiltrado, $porPagina, $mostrarTodos, $pagina, $totalPaginas,
//         $tamanosPagina, $porPaginaParam, y la función urlPagina().
$desde = $totalFiltrado === 0 ? 0 : ($mostrarTodos ? 1 : ($pagina - 1) * $porPagina + 1);
$hasta = $mostrarTodos ? $totalFiltrado : min($pagina * $porPagina, $totalFiltrado);
?>
<div class="paginacion">
  <div class="paginacion__info">
    <?php if ($totalFiltrado === 0): ?>
      Sin resultados
    <?php else: ?>
      Mostrando <?= $desde ?>–<?= $hasta ?> de <?= $totalFiltrado ?>
    <?php endif; ?>
  </div>

  <div class="paginacion__tamano">
    <span>Por página:</span>
    <?php foreach ($tamanosPagina as $t): ?>
      <a href="<?= htmlspecialchars(urlPagina(['por_pagina' => $t, 'pagina' => 1])) ?>"
         class="paginacion__op <?= (!$mostrarTodos && $porPagina === $t) ? 'paginacion__op--activa' : '' ?>"><?= $t ?></a>
    <?php endforeach; ?>
    <a href="<?= htmlspecialchars(urlPagina(['por_pagina' => 'todos', 'pagina' => 1])) ?>"
       class="paginacion__op <?= $mostrarTodos ? 'paginacion__op--activa' : '' ?>">Todos</a>
  </div>

  <?php if (!$mostrarTodos && $totalPaginas > 1): ?>
    <div class="paginacion__nav">
      <form method="get" class="paginacion__ir" action="<?= strpos($_SERVER['PHP_SELF'], 'almacen') !== false ? 'almacen_articulos.php' : 'index.php' ?>">
        <?php foreach ($_GET as $k => $v): ?>
          <?php if ($k !== 'pagina' && !is_array($v)): ?>
            <input type="hidden" name="<?= htmlspecialchars($k) ?>" value="<?= htmlspecialchars($v) ?>">
          <?php endif; ?>
        <?php endforeach; ?>
        <label>Ir a pág.</label>
        <input type="number" name="pagina" min="1" max="<?= $totalPaginas ?>" value="<?= $pagina ?>" class="paginacion__ir-input">
        <button type="submit" class="btn btn--secondary">Ir</button>
      </form>
      <?php if ($pagina > 1): ?>
        <a class="btn btn--secondary" href="<?= htmlspecialchars(urlPagina(['pagina' => $pagina - 1])) ?>">◀ Anterior</a>
      <?php else: ?>
        <span class="btn btn--secondary btn--disabled">◀ Anterior</span>
      <?php endif; ?>
      <span class="paginacion__actual">Página <?= $pagina ?> de <?= $totalPaginas ?></span>
      <?php if ($pagina < $totalPaginas): ?>
        <a class="btn btn--secondary" href="<?= htmlspecialchars(urlPagina(['pagina' => $pagina + 1])) ?>">Siguiente ▶</a>
      <?php else: ?>
        <span class="btn btn--secondary btn--disabled">Siguiente ▶</span>
      <?php endif; ?>
    </div>
  <?php endif; ?>
</div>
