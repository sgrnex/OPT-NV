<?php
// Se espera que la página que incluye este fichero ya haya definido:
//   $pdo            -> conexión PDO
//   $cliente        -> array del cliente (o null si es alta nueva)
//   $esExistente    -> bool
//   $tabActiva      -> pestaña actual, para mantenerla al ir a Anterior/Siguiente
//   $formGuardarId  -> id del <form> de esta pestaña que debe guardar
//                      "Guardar", o null si esta pestaña no tiene un
//                      formulario único (p. ej. Ficha Gafas, que se
//                      guarda fila a fila con el icono ➕ de cada tabla)

$paginasPorTab = [
    'datos'         => 'cliente_form.php',
    'gafas'         => 'ficha_gafas.php',
    '21puntos'      => 'cliente_21puntos.php',
    'lentillas'     => 'ficha_lentillas.php',
    'audifonos'     => 'cliente_audifonos.php',
    'observaciones' => 'cliente_observaciones.php',
    'ventas_cliente' => 'cliente_ventas.php',
];
$paginaActual = $paginasPorTab[$tabActiva ?? 'datos'] ?? 'cliente_form.php';

$volverListado = $_GET['volver'] ?? $_POST['volver'] ?? 'index.php';
$volverParam = urlencode($volverListado);
$origenId = (int)($_GET['origen'] ?? $_POST['origen'] ?? ($cliente['id'] ?? 0));

$idAnterior = null;
$idSiguiente = null;
if ($esExistente) {
    $stmt = $pdo->prepare('SELECT MAX(id) AS id FROM clientes WHERE id < :id');
    $stmt->execute(['id' => $cliente['id']]);
    $idAnterior = $stmt->fetch()['id'];

    $stmt = $pdo->prepare('SELECT MIN(id) AS id FROM clientes WHERE id > :id');
    $stmt->execute(['id' => $cliente['id']]);
    $idSiguiente = $stmt->fetch()['id'];
}
?>
<div class="ficha-acciones ficha-acciones--distribuida">
  <div class="ficha-acciones__grupo ficha-acciones__grupo--izquierda">
    <?php if ($formGuardarId): ?>
      <button type="submit" form="<?= htmlspecialchars($formGuardarId) ?>" class="ficha-acciones__item btn btn--secondary">✅ Guardar</button>
    <?php else: ?>
      <span class="ficha-acciones__item ficha-acciones__item--disabled" title="Esta pestaña se guarda con el ➕ de cada tabla">✅ Guardar</span>
    <?php endif; ?>

    <a href="cliente_form.php<?= $volverListado !== 'index.php' ? '?volver=' . $volverParam : '' ?>" class="ficha-acciones__item btn btn--secondary">➕ Nuevo</a>

    <?php if ($esExistente): ?>
      <button type="submit" form="form-borrar-cliente"
              class="ficha-acciones__item btn btn--danger"
              onclick="return confirm('¿Eliminar a <?= htmlspecialchars(addslashes($cliente['nombre'])) ?>?');">❌ Borrar</button>
    <?php else: ?>
      <span class="ficha-acciones__item ficha-acciones__item--disabled">❌ Borrar</span>
    <?php endif; ?>
  </div>

  <div class="ficha-acciones__grupo ficha-acciones__grupo--centro ficha-acciones__grupo--cliente-extra">
    <span class="ficha-acciones__item ficha-acciones__item--disabled" title="Próxima fase">🛒 Nueva Venta</span>
    <span class="ficha-acciones__item ficha-acciones__item--disabled" title="Próxima fase">📦 Nuevo Encargo</span>
    <span class="ficha-acciones__item ficha-acciones__item--disabled" title="Próxima fase">🖨️ Imprimir</span>
    <span class="ficha-acciones__item ficha-acciones__item--disabled" title="Próxima fase">📧 Email</span>
  </div>

  <div class="ficha-acciones__grupo ficha-acciones__grupo--derecha">
    <?php if ($idAnterior): ?>
      <a href="<?= $paginaActual ?>?id=<?= (int) $idAnterior ?>&volver=<?= $volverParam ?>&origen=<?= $origenId ?>" class="ficha-acciones__item btn btn--secondary">⬅️ Anterior</a>
    <?php endif; ?>
    <?php if ($idSiguiente): ?>
      <a href="<?= $paginaActual ?>?id=<?= (int) $idSiguiente ?>&volver=<?= $volverParam ?>&origen=<?= $origenId ?>" class="ficha-acciones__item btn btn--secondary">➡️ Siguiente</a>
    <?php endif; ?>
    <a href="<?= htmlspecialchars($volverListado) ?><?= strpos($volverListado, '?') !== false ? '&' : '?' ?>resaltar=<?= $esExistente ? (int) $cliente['id'] : 0 ?>&origen=<?= $origenId ?>" class="ficha-acciones__item btn btn--secondary">↩️ Volver</a>
  </div>
</div>

<?php if ($esExistente): ?>
<form id="form-borrar-cliente" method="post" action="cliente_borrar.php" style="display:none;">
  <input type="hidden" name="id" value="<?= (int) $cliente['id'] ?>">
  <input type="hidden" name="volver" value="<?= htmlspecialchars($volverListado) ?>">
</form>
<?php endif; ?>

<script>
(function () {
  var formId = <?= $formGuardarId ? json_encode($formGuardarId) : 'null' ?>;
  var urlAnterior = <?= $idAnterior ? json_encode($paginaActual . '?id=' . $idAnterior . '&volver=' . $volverParam . '&origen=' . $origenId) : 'null' ?>;
  var urlSiguiente = <?= $idSiguiente ? json_encode($paginaActual . '?id=' . $idSiguiente . '&volver=' . $volverParam . '&origen=' . $origenId) : 'null' ?>;

  var formEl = formId ? document.getElementById(formId) : null;
  var sucio = false;

  var selectDelegacion = document.querySelector('select[name="delegacion_id"][form]');
  if (selectDelegacion) {
    selectDelegacion.addEventListener('change', function () { sucio = true; });
  }

  if (formEl) {
    formEl.addEventListener('input', function () { sucio = true; });
    formEl.addEventListener('change', function () { sucio = true; });
    formEl.addEventListener('submit', function () { sucio = false; });

    window.addEventListener('beforeunload', function (e) {
      if (sucio) {
        e.preventDefault();
        e.returnValue = '';
      }
    });
  }

  document.addEventListener('keydown', function (e) {
    if (!e.ctrlKey || e.altKey) return;
    var tecla = e.key.toLowerCase();
    if (tecla === 'g') {
      e.preventDefault();
      if (formEl) formEl.requestSubmit();
    } else if (tecla === 'a') {
      e.preventDefault();
      if (urlAnterior) window.location.href = urlAnterior;
    } else if (tecla === 's') {
      e.preventDefault();
      if (urlSiguiente) window.location.href = urlSiguiente;
    }
  });
})();
</script>
