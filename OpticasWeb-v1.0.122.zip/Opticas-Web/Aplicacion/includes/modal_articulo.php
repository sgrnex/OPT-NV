<?php
// Modal para buscar un artículo por nombre parecido al producto de la ficha.
?>
<div id="modal-articulo" class="modal-articulo" style="display:none;">
  <div class="modal-articulo__fondo" onclick="cerrarModalArticulo()"></div>
  <div class="modal-articulo__caja">
    <div class="modal-articulo__cabecera">
      <span id="modal-articulo-titulo">Artículos encontrados</span>
      <button type="button" class="modal-articulo__cerrar" onclick="cerrarModalArticulo()">✕</button>
    </div>
    <div id="modal-articulo-cuerpo" class="modal-articulo__cuerpo">
      <p>Buscando…</p>
    </div>
  </div>
</div>
<script>
function cerrarModalArticulo() {
  document.getElementById('modal-articulo').style.display = 'none';
}
function buscarArticulo(texto) {
  var modal = document.getElementById('modal-articulo');
  var cuerpo = document.getElementById('modal-articulo-cuerpo');
  document.getElementById('modal-articulo-titulo').textContent = 'Artículos parecidos a: ' + texto;
  cuerpo.innerHTML = '<p>Buscando…</p>';
  modal.style.display = 'flex';

  fetch('buscar_articulo.php?q=' + encodeURIComponent(texto))
    .then(function (r) { return r.json(); })
    .then(function (data) {
      if (!data.candidatos || data.candidatos.length === 0) {
        cuerpo.innerHTML = '<p>No se ha encontrado ningún artículo parecido en el almacén.</p>';
        return;
      }
      var html = '<table class="data-table data-table--compacta"><thead><tr>' +
                 '<th>Código</th><th>Referencia</th><th>Nombre</th><th>Marca</th><th>PVP</th></tr></thead><tbody>';
      data.candidatos.forEach(function (a) {
        html += '<tr class="fila-clicable" onclick="window.open(\'articulo_form.php?id=' + a.id + '\', \'_blank\')" title="Abrir ficha del artículo">' +
                '<td>' + (a.codigo || '') + '</td>' +
                '<td>' + (a.referencia || '') + '</td>' +
                '<td>' + (a.nombre || '') + '</td>' +
                '<td>' + (a.marca || '') + '</td>' +
                '<td>' + (a.pvp || '') + '</td></tr>';
      });
      html += '</tbody></table>';
      cuerpo.innerHTML = html;
    })
    .catch(function () {
      cuerpo.innerHTML = '<p>Error al buscar el artículo.</p>';
    });
}
</script>
