<?php

/**
 * Construye la parte WHERE del filtro común "a qué clientes incluir".
 * Devuelve [sqlWhere, params]. Los campos de cliente van con alias c.
 */
function filtroComunClientes(array $f): array
{
    $sql = '';
    $params = [];

    if (!empty($f['nombre'])) {
        $sql .= " AND (c.nombre LIKE :fn OR c.apellidos LIKE :fn)";
        $params['fn'] = '%' . $f['nombre'] . '%';
    }
    foreach (['nif' => 'nif', 'telefono' => 'telefono', 'poblacion' => 'poblacion', 'provincia' => 'provincia', 'email' => 'email'] as $campo => $col) {
        if (!empty($f[$campo])) {
            $sql .= " AND c.$col LIKE :f_$campo";
            $params["f_$campo"] = '%' . $f[$campo] . '%';
        }
    }
    if (($f['edad_desde'] ?? '') !== '') { $sql .= " AND TIMESTAMPDIFF(YEAR, c.fecha_nacimiento, CURDATE()) >= :fed"; $params['fed'] = (int) $f['edad_desde']; }
    if (($f['edad_hasta'] ?? '') !== '') { $sql .= " AND TIMESTAMPDIFF(YEAR, c.fecha_nacimiento, CURDATE()) <= :feh"; $params['feh'] = (int) $f['edad_hasta']; }
    if (!empty($f['alta_desde'])) { $sql .= " AND c.fecha_alta >= :fad"; $params['fad'] = $f['alta_desde']; }
    if (!empty($f['alta_hasta'])) { $sql .= " AND c.fecha_alta <= :fah"; $params['fah'] = $f['alta_hasta']; }
    if (!empty($f['nac_desde'])) { $sql .= " AND c.fecha_nacimiento >= :fnd"; $params['fnd'] = $f['nac_desde']; }
    if (!empty($f['nac_hasta'])) { $sql .= " AND c.fecha_nacimiento <= :fnh"; $params['fnh'] = $f['nac_hasta']; }
    if (($f['delegacion'] ?? '') !== '') { $sql .= " AND c.delegacion_id = :fdl"; $params['fdl'] = (int) $f['delegacion']; }
    if (($f['estado'] ?? '') !== '') { $sql .= " AND c.activo = :fes"; $params['fes'] = (int) $f['estado']; }
    if (($f['mailing'] ?? '') !== '') { $sql .= " AND c.acepta_mailing_sms = :fma"; $params['fma'] = (int) $f['mailing']; }
    if (($f['revision'] ?? '') === '1') { $sql .= " AND c.proxima_revision IS NOT NULL AND c.proxima_revision >= CURDATE()"; }
    if (($f['revision'] ?? '') === '0') { $sql .= " AND (c.proxima_revision IS NULL OR c.proxima_revision < CURDATE())"; }

    return [$sql, $params];
}

/**
 * Genera los datos de un listado de clientes (título, modo, columnas/filas
 * o fichas). El filtro común 'filtros' se aplica a todos los tipos.
 */
function generarDatosListadoClientes(PDO $pdo, string $tipo, array $opciones): array
{
    $cols = $opciones['cols'] ?? ['nif', 'telefono', 'poblacion', 'provincia', 'email', 'delegacion'];

    $etiquetasCol = ['nif' => 'NIF', 'telefono' => 'Teléfono', 'poblacion' => 'Población', 'provincia' => 'Provincia', 'email' => 'Email', 'delegacion' => 'Delegación'];
    $cabeceraBase = function (array $extra = []) use ($cols, $etiquetasCol) {
        $c = ['Nº', 'Cliente'];
        foreach ($cols as $col) {
            if (isset($etiquetasCol[$col])) $c[] = $etiquetasCol[$col];
        }
        return array_merge($c, $extra);
    };
    $filaBase = function (array $c) use ($cols) {
        $nombre = trim((string)($c['nombre'] ?? ''));
        $apellidos = preg_split('/\s+/', trim((string)($c['apellidos'] ?? '')), -1, PREG_SPLIT_NO_EMPTY);
        $cliente = $nombre . (!empty($apellidos) ? ' ' . $apellidos[0] : '');
        $f = [$c['id'], trim($cliente)];
        foreach ($cols as $col) {
            $f[] = $col === 'delegacion' ? ($c['delegacion_nombre'] ?? '') : ($c[$col] ?? '');
        }
        return $f;
    };

    // La delegación siempre se trae (para poder mostrarla como columna y
    // para el filtro por delegación); no cuesta y simplifica.
    $selCliente = 'c.*, d.nombre AS delegacion_nombre';
    $joinDelegacion = ' LEFT JOIN delegaciones d ON d.id = c.delegacion_id';

    [$fWhere, $fParams] = filtroComunClientes($opciones['filtros'] ?? []);

    switch ($tipo) {
        case 'graduaciones':
            $desde = $opciones['grad_desde'] !== '' ? $opciones['grad_desde'] : null;
            $hasta = $opciones['grad_hasta'] !== '' ? $opciones['grad_hasta'] : null;
            $conDetalle = !empty($opciones['grad_detalle']);

            $sql = "SELECT DISTINCT $selCliente FROM clientes c INNER JOIN graduaciones g ON g.cliente_id = c.id$joinDelegacion WHERE 1=1";
            $params = [];
            if ($desde !== null) { $sql .= " AND g.fecha >= :d"; $params['d'] = $desde; }
            if ($hasta !== null) { $sql .= " AND g.fecha <= :h"; $params['h'] = $hasta; }
            $sql .= $fWhere; $params += $fParams;
            $sql .= " ORDER BY c.apellidos, c.nombre";
            $stmt = $pdo->prepare($sql);
            $stmt->execute($params);
            $clientes = $stmt->fetchAll();

            if (!$conDetalle) {
                return ['titulo' => 'Listado por Graduaciones', 'modo' => 'tabla', 'columnas' => $cabeceraBase(), 'filas' => array_map($filaBase, $clientes)];
            }
            $catNombre = ['lejos' => 'Lejos', 'cerca' => 'Cerca', 'multifocal' => 'Multifocal'];
            $ojoNombre = ['D' => 'OD', 'I' => 'OI'];
            $fichas = [];
            foreach ($clientes as $c) {
                $sqlG = "SELECT * FROM graduaciones WHERE cliente_id = :id";
                $pG = ['id' => $c['id']];
                if ($desde !== null) { $sqlG .= " AND fecha >= :d"; $pG['d'] = $desde; }
                if ($hasta !== null) { $sqlG .= " AND fecha <= :h"; $pG['h'] = $hasta; }
                $sqlG .= " ORDER BY fecha DESC";
                $stmtG = $pdo->prepare($sqlG); $stmtG->execute($pG);
                $filasDet = [];
                foreach ($stmtG->fetchAll() as $g) {
                    $filasDet[] = [$g['fecha'], $catNombre[$g['categoria']] ?? $g['categoria'], $ojoNombre[$g['ojo']] ?? $g['ojo'], $g['esf'], $g['cil'], $g['eje'], $g['av'], $g['adic']];
                }
                $fichas[] = [
                    'cliente' => '#' . $c['id'] . ' — ' . trim($c['nombre'] . ' ' . $c['apellidos']),
                    'datos' => $filaBase($c),
                    'detalle' => ['columnas' => ['Fecha', 'Cat.', 'Ojo', 'Esf.', 'Cil.', 'Eje', 'A.V.', 'Adic.'], 'filas' => $filasDet],
                ];
            }
            return ['titulo' => 'Listado por Graduaciones (con detalle)', 'modo' => 'ficha', 'cols_cliente' => $cabeceraBase(), 'fichas' => $fichas];

        case 'lentillas':
            $conDetalle = !empty($opciones['lent_detalle']);
            $sql = "SELECT DISTINCT $selCliente FROM clientes c INNER JOIN lentillas_definitivas l ON l.cliente_id = c.id$joinDelegacion WHERE 1=1" . $fWhere . " ORDER BY c.apellidos, c.nombre";
            $stmt = $pdo->prepare($sql); $stmt->execute($fParams);
            $clientes = $stmt->fetchAll();
            if (!$conDetalle) {
                return ['titulo' => 'Listado de Clientes con Lentillas', 'modo' => 'tabla', 'columnas' => $cabeceraBase(), 'filas' => array_map($filaBase, $clientes)];
            }
            $ojoNombre = ['D' => 'OD', 'I' => 'OI'];
            $fichas = [];
            foreach ($clientes as $c) {
                $stmtL = $pdo->prepare("SELECT * FROM lentillas_definitivas WHERE cliente_id = :id ORDER BY fecha DESC");
                $stmtL->execute(['id' => $c['id']]);
                $filasDet = [];
                foreach ($stmtL->fetchAll() as $l) {
                    $filasDet[] = [$l['fecha'], $ojoNombre[$l['ojo']] ?? $l['ojo'], $l['esf'], $l['cil'], $l['radio'], $l['potencia'], $l['diametro'], $l['tipo'], $l['material']];
                }
                $fichas[] = [
                    'cliente' => '#' . $c['id'] . ' — ' . trim($c['nombre'] . ' ' . $c['apellidos']),
                    'datos' => $filaBase($c),
                    'detalle' => ['columnas' => ['Fecha', 'Ojo', 'Esf.', 'Cil.', 'Radio', 'Pot.', 'Diám.', 'Tipo', 'Material'], 'filas' => $filasDet],
                ];
            }
            return ['titulo' => 'Listado de Clientes con Lentillas (con detalle)', 'modo' => 'ficha', 'cols_cliente' => $cabeceraBase(), 'fichas' => $fichas];

        case 'audifonos':
            $conDetalle = !empty($opciones['audi_detalle']);
            $sql = "SELECT DISTINCT $selCliente FROM clientes c$joinDelegacion
                    WHERE ((c.audifono_od_marca_modelo IS NOT NULL AND c.audifono_od_marca_modelo <> '')
                       OR (c.audifono_oi_marca_modelo IS NOT NULL AND c.audifono_oi_marca_modelo <> '')
                       OR EXISTS (SELECT 1 FROM audiometrias a WHERE a.cliente_id = c.id))" . $fWhere . "
                    ORDER BY c.apellidos, c.nombre";
            $stmt = $pdo->prepare($sql); $stmt->execute($fParams);
            $clientes = $stmt->fetchAll();
            if (!$conDetalle) {
                return ['titulo' => 'Listado de Clientes con Audífonos', 'modo' => 'tabla', 'columnas' => $cabeceraBase(), 'filas' => array_map($filaBase, $clientes)];
            }
            $tipoNombre = ['aerea' => 'Aérea', 'osea' => 'Ósea'];
            $oidoNombre = ['D' => 'OD', 'I' => 'OI'];
            $fichas = [];
            foreach ($clientes as $c) {
                $stmtA = $pdo->prepare("SELECT * FROM audiometrias WHERE cliente_id = :id ORDER BY fecha DESC");
                $stmtA->execute(['id' => $c['id']]);
                $filasDet = [];
                foreach ($stmtA->fetchAll() as $a) {
                    $filasDet[] = [$a['fecha'], $tipoNombre[$a['tipo']] ?? $a['tipo'], $oidoNombre[$a['oido']] ?? $a['oido'], $a['hz500'], $a['hz1000'], $a['hz2000'], $a['hz4000'], $a['hz8000']];
                }
                $extra = [];
                if ($c['audifono_od_marca_modelo']) $extra[] = ['Audífono OD', $c['audifono_od_marca_modelo'], '', '', '', '', '', ''];
                if ($c['audifono_oi_marca_modelo']) $extra[] = ['Audífono OI', $c['audifono_oi_marca_modelo'], '', '', '', '', '', ''];
                $fichas[] = [
                    'cliente' => '#' . $c['id'] . ' — ' . trim($c['nombre'] . ' ' . $c['apellidos']),
                    'datos' => $filaBase($c),
                    'detalle' => ['columnas' => ['Fecha', 'Tipo', 'Oído', '500', '1000', '2000', '4000', '8000'], 'filas' => array_merge($filasDet, $extra)],
                ];
            }
            return ['titulo' => 'Listado de Clientes con Audífonos (con detalle)', 'modo' => 'ficha', 'cols_cliente' => $cabeceraBase(), 'fichas' => $fichas];

        case 'general':
        default:
            $sql = "SELECT $selCliente FROM clientes c$joinDelegacion WHERE 1=1" . $fWhere . " ORDER BY c.apellidos, c.nombre";
            $stmt = $pdo->prepare($sql); $stmt->execute($fParams);
            return ['titulo' => 'Listado General de Clientes', 'modo' => 'tabla', 'columnas' => $cabeceraBase(), 'filas' => array_map($filaBase, $stmt->fetchAll())];
    }
}
