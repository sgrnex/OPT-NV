<?php

function pintarGridRepetible(PDO $pdo, string $tabla, array $columnas, array $contexto, string $volver, ?string $subtitulo = null): void
{
    $esPrecio = static function (string $campo): bool {
        return in_array($campo, ['precio','importe','coste','pvp'], true);
    };
    $mostrarValor = static function ($valor, string $campo) use ($esPrecio): string {
        if ($esPrecio($campo) && $valor !== null && $valor !== '') {
            return number_format((float)$valor, 2, '.', '');
        }
        return (string)($valor ?? '');
    };
    $whereSql = [];
    foreach (array_keys($contexto) as $col) {
        $whereSql[] = "`$col` = :$col";
    }
    $sql = "SELECT * FROM `$tabla` WHERE " . implode(' AND ', $whereSql) . ' ORDER BY fecha DESC, id DESC';
    $stmt = $pdo->prepare($sql);
    $stmt->execute($contexto);
    $filas = $stmt->fetchAll();
    ?>
    <?php if ($subtitulo): ?><p class="grid-repetible__subtitulo"><?= htmlspecialchars($subtitulo) ?></p><?php endif; ?>
    <form method="post" action="registro_guardar.php" class="grid-repetible">
      <input type="hidden" name="tabla" value="<?= htmlspecialchars($tabla) ?>">
      <input type="hidden" name="volver" value="<?= htmlspecialchars($volver) ?>">
      <?php foreach ($contexto as $col => $val): ?>
        <input type="hidden" name="ctx_<?= htmlspecialchars($col) ?>" value="<?= htmlspecialchars($val) ?>">
      <?php endforeach; ?>

      <div class="table-scroll">
      <table class="data-table data-table--compacta">
        <thead>
          <tr>
            <?php foreach ($columnas as $campo => $etiqueta): ?><th class="grid-col-<?= htmlspecialchars((string)$campo, ENT_QUOTES, 'UTF-8') ?>"><?= htmlspecialchars($etiqueta) ?></th><?php endforeach; ?>
            <th class="col-actions"></th>
          </tr>
        </thead>
        <tbody>
          <tr class="grid-repetible__alta">
            <?php foreach (array_keys($columnas) as $campo): ?>
              <td class="grid-col-<?= htmlspecialchars((string)$campo, ENT_QUOTES, 'UTF-8') ?>">
                <?php if ($campo === 'fecha'): ?>
                  <input type="date" name="fecha">
                <?php else: ?>
                  <input type="text" name="<?= htmlspecialchars($campo) ?>"<?= $esPrecio($campo) ? ' inputmode="decimal" placeholder="0.00"' : '' ?>>
                <?php endif; ?>
              </td>
            <?php endforeach; ?>
            <td class="col-actions">
              <button type="submit" class="icon-link" title="Añadir">➕</button>
            </td>
          </tr>
          <?php if (empty($filas)): ?>
            <tr><td colspan="<?= count($columnas) + 1 ?>" class="empty-row">Sin registros.</td></tr>
          <?php else: foreach ($filas as $fila): ?>
            <?php
              // Si la fila tiene un producto asociado (texto libre), la hacemos
              // doble-clicable para buscar ese artículo en el almacén.
              $textoProducto = $fila['producto'] ?? ($fila['descripcion'] ?? null);
              $dblclick = $textoProducto
                ? 'ondblclick="buscarArticulo(' . htmlspecialchars(json_encode($textoProducto), ENT_QUOTES) . ')" class="fila-clicable" title="Doble clic para ver el artículo en el almacén"'
                : '';
            ?>
            <tr <?= $dblclick ?>>
              <?php foreach (array_keys($columnas) as $campo): ?>
                <td class="grid-col-<?= htmlspecialchars((string)$campo, ENT_QUOTES, 'UTF-8') ?>"><?= htmlspecialchars($mostrarValor($fila[$campo] ?? '', $campo)) ?></td>
              <?php endforeach; ?>
              <td class="col-actions">
                <button type="submit" formaction="registro_borrar.php" formmethod="post"
                        name="id" value="<?= (int) $fila['id'] ?>"
                        class="icon-link icon-link--danger" title="Eliminar"
                        onclick="return confirm('¿Eliminar este registro?');">✕</button>
              </td>
            </tr>
          <?php endforeach; endif; ?>
        </tbody>
      </table>
      </div>
    </form>
    <?php
}
