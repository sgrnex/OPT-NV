<?php

function pdfEscape(string $texto): string
{
    $texto = mb_convert_encoding($texto, 'ISO-8859-1', 'UTF-8');
    return str_replace(['\\', '(', ')'], ['\\\\', '\\(', '\\)'], $texto);
}

function construirPdfDesdeStream(string $stream): string
{
    return construirPdfMultipagina([$stream]);
}

/**
 * Construye un PDF con una o varias páginas. Cada elemento de $streams
 * es el contenido (stream de operadores) de una página A4.
 */
function construirPdfMultipagina(array $streams, float $ancho = 595, float $alto = 842): string
{
    if (empty($streams)) {
        $streams = [''];
    }

    $mediaBox = '[0 0 ' . round($ancho) . ' ' . round($alto) . ']';
    $numPaginas = count($streams);

    // Numeración de objetos:
    //   1 = Catalog
    //   2 = Pages
    //   3..8 = familias Helvetica, Times y Courier (normal/negrita)
    //   luego, por cada página: un objeto Page y un objeto Contents.
    $objetos = [];
    $objetos[1] = '<< /Type /Catalog /Pages 2 0 R >>';

    $idsPaginas = [];
    $obj = 9;
    $paginasObj = [];
    $contenidosObj = [];
    foreach ($streams as $stream) {
        $idPage = $obj;
        $idContents = $obj + 1;
        $idsPaginas[] = $idPage;
        $paginasObj[$idPage] = '<< /Type /Page /Parent 2 0 R /MediaBox ' . $mediaBox . ' '
            . '/Resources << /Font << /F1 3 0 R /F2 4 0 R /F3 5 0 R /F4 6 0 R /F5 7 0 R /F6 8 0 R >> >> /Contents ' . $idContents . ' 0 R >>';
        $contenidosObj[$idContents] = "<< /Length " . strlen($stream) . " >>\nstream\n$stream\nendstream";
        $obj += 2;
    }

    $kids = implode(' ', array_map(fn($id) => "$id 0 R", $idsPaginas));
    $objetos[2] = "<< /Type /Pages /Kids [$kids] /Count $numPaginas >>";
    $objetos[3] = '<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>';
    $objetos[4] = '<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold /Encoding /WinAnsiEncoding >>';
    $objetos[5] = '<< /Type /Font /Subtype /Type1 /BaseFont /Times-Roman /Encoding /WinAnsiEncoding >>';
    $objetos[6] = '<< /Type /Font /Subtype /Type1 /BaseFont /Times-Bold /Encoding /WinAnsiEncoding >>';
    $objetos[7] = '<< /Type /Font /Subtype /Type1 /BaseFont /Courier /Encoding /WinAnsiEncoding >>';
    $objetos[8] = '<< /Type /Font /Subtype /Type1 /BaseFont /Courier-Bold /Encoding /WinAnsiEncoding >>';
    foreach ($paginasObj as $id => $cuerpo) {
        $objetos[$id] = $cuerpo;
    }
    foreach ($contenidosObj as $id => $cuerpo) {
        $objetos[$id] = $cuerpo;
    }

    ksort($objetos);

    $pdf = "%PDF-1.4\n";
    $offsets = [];
    foreach ($objetos as $numero => $cuerpo) {
        $offsets[$numero] = strlen($pdf);
        $pdf .= "$numero 0 obj\n$cuerpo\nendobj\n";
    }

    $totalObjetos = max(array_keys($objetos)) + 1;
    $inicioXref = strlen($pdf);
    $pdf .= "xref\n0 $totalObjetos\n0000000000 65535 f \n";
    for ($i = 1; $i < $totalObjetos; $i++) {
        $pdf .= isset($offsets[$i]) ? sprintf("%010d 00000 n \n", $offsets[$i]) : "0000000000 00000 f \n";
    }
    $pdf .= "trailer\n<< /Size $totalObjetos /Root 1 0 R >>\nstartxref\n$inicioXref\n%%EOF";

    return $pdf;
}

/**
 * Pequeño "lienzo" para maquetar un PDF de una página a mano (sin
 * librerías externas), con texto en color, párrafos con salto de línea
 * automático, líneas y recuadros.
 */
class ConstructorPdf
{
    private string $stream = '';
    private array $paginas = [];
    private bool $enTexto = false;
    private ?string $fuenteActual = null;
    private ?float $tamActual = null;
    private ?string $colorActual = null;
    private float $ancho;
    private float $alto;

    public function __construct(float $ancho = 595, float $alto = 842)
    {
        $this->ancho = $ancho;
        $this->alto = $alto;
    }

    /** Cierra la página actual y empieza una nueva en blanco. */
    public function nuevaPagina(): void
    {
        $this->asegurarGrafico();
        $this->paginas[] = $this->stream;
        $this->stream = '';
        $this->fuenteActual = null;
        $this->colorActual = null;
    }

    private function asegurarTexto(): void
    {
        if (!$this->enTexto) {
            $this->stream .= "BT\n";
            $this->enTexto = true;
            $this->fuenteActual = null;
            $this->colorActual = null;
        }
    }

    private function asegurarGrafico(): void
    {
        if ($this->enTexto) {
            $this->stream .= "ET\n";
            $this->enTexto = false;
        }
    }

    public function texto(float $x, float $y, string $texto, string $fuente, float $tam, string $color = '0 0 0'): void
    {
        $this->asegurarTexto();
        if ($this->fuenteActual !== $fuente || $this->tamActual !== $tam) {
            $this->stream .= "/$fuente $tam Tf\n";
            $this->fuenteActual = $fuente;
            $this->tamActual = $tam;
        }
        if ($this->colorActual !== $color) {
            $this->stream .= "$color rg\n";
            $this->colorActual = $color;
        }
        $this->stream .= "1 0 0 1 " . round($x, 2) . " " . round($y, 2) . " Tm\n(" . pdfEscape($texto) . ") Tj\n";
    }

    public function textoRecortado(float $x, float $y, float $ancho, float $alto, string $texto, string $fuente, float $tam, string $color = '0 0 0'): void
    {
        // Clip real de PDF: aunque una métrica de fuente sea aproximada, el
        // texto jamás puede invadir la columna contigua.
        $this->asegurarGrafico();
        // En PDF, $y es la línea base: las letras ascienden por encima de ella.
        // El recorte anterior terminaba en y+2 y amputaba casi todo el carácter.
        // Se conserva el límite horizontal, ampliando la caja vertical para
        // incluir ascendentes y descendentes completos.
        $clipY = $y - max($alto, $tam * 0.35);
        $clipAlto = max($alto, $tam * 1.35) + $tam;
        $this->stream .= "q " . round($x,2) . " " . round($clipY,2) . " " . round($ancho,2) . " " . round($clipAlto,2) . " re W n\n";
        $this->texto($x, $y, $texto, $fuente, $tam, $color);
        $this->asegurarGrafico();
        $this->stream .= "Q\n";
    }

    /** Escribe un párrafo con salto de línea automático; devuelve la Y final.
     *  Si se indica $anchoPuntosJustificar, cada línea (excepto la última
     *  de cada párrafo) se "justifica" colocando cada palabra a mano en su
     *  posición exacta, de modo que la línea llegue justo al margen
     *  derecho — igual que un párrafo justificado de Word. */
    public function parrafo(float $x, float $y, int $anchoCaracteres, string $texto, string $fuente, float $tam, float $interlineado, string $color = '0 0 0', ?float $anchoPuntosJustificar = null): float
    {
        $lineas = explode("\n", wordwrap($texto, $anchoCaracteres, "\n", true));
        $ultimoIndice = count($lineas) - 1;

        foreach ($lineas as $indice => $linea) {
            if ($anchoPuntosJustificar !== null && $indice !== $ultimoIndice) {
                $this->lineaJustificada($x, $y, $anchoPuntosJustificar, $linea, $fuente, $tam, $color);
            } else {
                $this->texto($x, $y, $linea, $fuente, $tam, $color);
            }
            $y -= $interlineado;
        }

        return $y;
    }

    public function medirAncho(string $texto, string $fuente, float $tam): float
    {
        return $this->anchoTexto($texto, $fuente, $tam);
    }

    private function anchoTexto(string $texto, string $fuente, float $tam): float
    {
        $factor = in_array($fuente, ['F2','F4','F6'], true) ? 0.60 : 0.56;
        return mb_strlen($texto) * $tam * $factor;
    }

    /** Coloca cada palabra de la línea a mano, repartiendo el espacio
     *  sobrante entre los huecos, para que la línea llegue exactamente
     *  al ancho indicado (justificado real, sin depender de Tw). */
    public function lineaJustificada(float $x, float $y, float $anchoObjetivo, string $linea, string $fuente, float $tam, string $color): void
    {
        $palabras = preg_split('/\s+/', trim($linea));
        $numPalabras = count($palabras);

        if ($numPalabras <= 1) {
            $this->texto($x, $y, $linea, $fuente, $tam, $color);
            return;
        }

        $anchoPalabras = 0;
        foreach ($palabras as $palabra) {
            $anchoPalabras += $this->anchoTexto($palabra, $fuente, $tam);
        }

        $hueco = ($anchoObjetivo - $anchoPalabras) / ($numPalabras - 1);
        $hueco = max($hueco, $this->anchoTexto(' ', $fuente, $tam)); // nunca más estrecho que un espacio normal

        $cursor = $x;
        foreach ($palabras as $palabra) {
            $this->texto($cursor, $y, $palabra, $fuente, $tam, $color);
            $cursor += $this->anchoTexto($palabra, $fuente, $tam) + $hueco;
        }
    }

    public function rectangulo(float $x, float $y, float $w, float $h, string $color = '0 0 0'): void
    {
        $this->asegurarGrafico();
        $this->stream .= "$color RG\n" . round($x, 2) . ' ' . round($y, 2) . ' ' . round($w, 2) . ' ' . round($h, 2) . " re S\n";
    }

    public function linea(float $x1, float $y1, float $x2, float $y2, string $color = '0 0 0'): void
    {
        $this->asegurarGrafico();
        $this->stream .= "$color RG\n" . round($x1, 2) . ' ' . round($y1, 2) . " m " . round($x2, 2) . ' ' . round($y2, 2) . " l S\n";
    }

    public function generarPdf(): string
    {
        $this->asegurarGrafico();
        $paginas = $this->paginas;
        $paginas[] = $this->stream; // la página en curso
        return construirPdfMultipagina($paginas, $this->ancho, $this->alto);
    }
}

/**
 * Generador genérico de un PDF de una sola página con un título y una
 * lista de párrafos (se mantiene por si se necesita para otros
 * documentos sencillos).
 */
function generarPdfSimple(string $titulo, array $parrafos): string
{
    $c = new ConstructorPdf();
    $margen = 60;
    $y = 780;
    $y = $c->parrafo($margen, $y, 85, $titulo, 'F2', 15, 20);
    $y -= 14;
    foreach ($parrafos as $parrafo) {
        if ($parrafo === '') {
            $y -= 14;
            continue;
        }
        $y = $c->parrafo($margen, $y, 85, $parrafo, 'F1', 11, 16);
        $y -= 8;
    }
    return $c->generarPdf();
}
