<?php
require __DIR__ . '/includes/auth.php';
requireLogin();
require __DIR__ . '/db.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: index.php');
    exit;
}

$pdo = obtenerConexion();
$ids = array_values(array_filter(array_map('intval', $_POST['ids'] ?? [])));
$accion = $_POST['accion'] ?? '';
$volver = $_GET['volver'] ?? $_POST['volver'] ?? 'index.php';
$separador = strpos($volver, '?') !== false ? '&' : '?';

if (empty($ids) || !in_array($accion, ['activar', 'desactivar', 'borrar'], true)) {
    header('Location: ' . $volver);
    exit;
}

$placeholders = implode(',', array_fill(0, count($ids), '?'));

if ($accion === 'activar') {
    $pdo->prepare("UPDATE clientes SET activo = 1 WHERE id IN ($placeholders)")->execute($ids);
    header("Location: {$volver}{$separador}accion_masiva=activados&n=" . count($ids));
    exit;
}

if ($accion === 'desactivar') {
    $pdo->prepare("UPDATE clientes SET activo = 0 WHERE id IN ($placeholders)")->execute($ids);
    header("Location: {$volver}{$separador}accion_masiva=desactivados&n=" . count($ids));
    exit;
}

// Borrar: igual que el borrado individual, respeta la protección de
// clientes con ficha óptica, ventas o facturas asociadas.
$borrados = 0;
$omitidos = 0;
foreach ($ids as $id) {
    if (clienteTieneRegistrosAsociados($pdo, $id)) {
        $omitidos++;
        continue;
    }
    $pdo->prepare('DELETE FROM clientes WHERE id = :id')->execute(['id' => $id]);
    $borrados++;
}
header("Location: {$volver}{$separador}accion_masiva=borrados&n=$borrados&omitidos=$omitidos");
exit;
