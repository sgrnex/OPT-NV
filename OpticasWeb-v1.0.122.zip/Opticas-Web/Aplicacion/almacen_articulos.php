<?php
require __DIR__ . '/includes/auth.php';
requireLogin();
require __DIR__ . '/db.php';

$pdo = obtenerConexion();

$camposFiltro = ['id', 'codigo', 'referencia', 'nombre', 'codigo_barras', 'marca', 'coste', 'pvp', 'existencias', 'delegacion'];
$etiquetas = ['codigo' => 'Código', 'referencia' => 'Referencia', 'nombre' => 'Nombre', 'codigo_barras' => 'Cód. Barras'];
$etiquetasBusqueda = ['id' => 'Número'] + $etiquetas;

$query = trim($_GET['q'] ?? '');
$resaltarId = (int)($_GET['resaltar'] ?? 0);
$origenId = (int)($_GET['origen'] ?? 0);
$campoGeneral = $_GET['campo'] ?? 'nombre';
if (!in_array($campoGeneral, array_keys($etiquetasBusqueda), true)) {
    $campoGeneral = 'nombre';
}
$delegacionId = trim($_GET['delegacion_id'] ?? '');
$activoFiltro = $_GET['activo'] ?? '';

$columnasOrdenables = [
    'id' => 'a.id', 'codigo' => 'a.codigo', 'referencia' => 'a.referencia', 'nombre' => 'a.nombre',
    'codigo_barras' => 'a.codigo_barras', 'marca' => 'm.nombre', 'coste' => 'a.coste', 'pvp' => 'a.pvp',
    'existencias' => 'a.existencias', 'delegacion' => 'd.nombre',
];
$ordenActual = $_GET['orden'] ?? 'nombre';
if (!isset($columnasOrdenables[$ordenActual])) {
    $ordenActual = 'nombre';
}
$dirActual = strtolower($_GET['dir'] ?? 'asc') === 'desc' ? 'desc' : 'asc';

function urlOrdenar(string $columna): string
{
    $params = $_GET;
    $mismaColumna = ($params['orden'] ?? '') === $columna;
    $dirPrevia = $mismaColumna ? (($params['dir'] ?? 'asc') === 'desc' ? 'desc' : 'asc') : null;
    $params['orden'] = $columna;
    $params['dir'] = $dirPrevia === 'asc' ? 'desc' : 'asc';
    return 'almacen_articulos.php?' . http_build_query($params);
}

function indicadorOrden(string $columna, string $ordenActual, string $dirActual): string
{
    if ($columna !== $ordenActual) {
        return '';
    }
    return $dirActual === 'asc' ? ' ▲' : ' ▼';
}

$sqlFromWhere = 'FROM articulos a
        LEFT JOIN marcas m ON m.id = a.marca_id
        LEFT JOIN delegaciones d ON d.id = a.delegacion_id
        WHERE 1=1';
$params = [];

if ($query !== '') {
    $sqlFromWhere .= " AND a.$campoGeneral LIKE :q";
    $params['q'] = "%$query%";
}
if ($delegacionId !== '') {
    $sqlFromWhere .= ' AND a.delegacion_id = :delegacion_id';
    $params['delegacion_id'] = (int) $delegacionId;
}
if ($activoFiltro !== '') {
    $sqlFromWhere .= ' AND a.activo = :activo_filtro';
    $params['activo_filtro'] = (int) $activoFiltro;
}

// Expresión SQL de cada columna filtrable (las de JOIN no son a.columna)
$exprFiltro = [
    'id' => 'a.id', 'codigo' => 'a.codigo', 'referencia' => 'a.referencia',
    'nombre' => 'a.nombre', 'codigo_barras' => 'a.codigo_barras',
    'marca' => 'm.nombre', 'coste' => 'a.coste', 'pvp' => 'a.pvp',
    'existencias' => 'a.existencias', 'delegacion' => 'd.nombre',
];

$filtrosColumna = [];
foreach ($camposFiltro as $campo) {
    $valor = trim($_GET["filtro_$campo"] ?? '');
    if ($valor !== '' && isset($exprFiltro[$campo])) {
        $filtrosColumna[$campo] = $valor;
        $sqlFromWhere .= " AND " . $exprFiltro[$campo] . " LIKE :filtro_$campo";
        $params["filtro_$campo"] = "%$valor%";
    }
}

// --- Paginación ---
$tamanosPagina = [50, 100, 200, 500, 1000];
$porPaginaParam = $_GET['por_pagina'] ?? '100';
$mostrarTodos = ($porPaginaParam === 'todos');
$porPagina = $mostrarTodos ? 0 : (in_array((int) $porPaginaParam, $tamanosPagina, true) ? (int) $porPaginaParam : 100);

$stmtCount = $pdo->prepare('SELECT COUNT(*) AS n ' . $sqlFromWhere);
$stmtCount->execute($params);
$totalFiltrado = (int) $stmtCount->fetch()['n'];

$sql = 'SELECT a.*, m.nombre AS marca_nombre, d.nombre AS delegacion_nombre ' . $sqlFromWhere
     . ' ORDER BY ' . $columnasOrdenables[$ordenActual] . ' ' . strtoupper($dirActual);

if (!$mostrarTodos) {
    $totalPaginas = max(1, (int) ceil($totalFiltrado / $porPagina));
    $pagina = max(1, (int) ($_GET['pagina'] ?? 1));
    if ($pagina > $totalPaginas) {
        $pagina = $totalPaginas;
    }
    $offset = ($pagina - 1) * $porPagina;
    $sql .= " LIMIT $porPagina OFFSET $offset";
} else {
    $totalPaginas = 1;
    $pagina = 1;
}

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$articulos = $stmt->fetchAll();

// Carga solo los dos registros destacados que puedan quedar fuera de la página.
if ($resaltarId > 0 && $origenId > 0 && $resaltarId !== $origenId) {
    $idsExtra = [$origenId, $resaltarId];
    $phExtra = ':extra0,:extra1';
    $sqlExtra = 'SELECT a.*, m.nombre AS marca_nombre, d.nombre AS delegacion_nombre ' . $sqlFromWhere . " AND a.id IN ($phExtra) ORDER BY " . $columnasOrdenables[$ordenActual] . ' ' . strtoupper($dirActual);
    $stExtra = $pdo->prepare($sqlExtra);
    $paramsExtra = $params;
    foreach ($idsExtra as $n => $idExtra) $paramsExtra['extra' . $n] = $idExtra;
    $stExtra->execute($paramsExtra);
    $presentes = array_fill_keys(array_map(fn($r) => (int)$r['id'], $articulos), true);
    foreach ($stExtra->fetchAll() as $extra) if (empty($presentes[(int)$extra['id']])) $articulos[] = $extra;
}

$totalArticulos = (int) $pdo->query('SELECT COUNT(*) AS n FROM articulos')->fetch()['n'];

$qsListado = $_GET; unset($qsListado['resaltar'], $qsListado['origen']);
$urlListadoActual = 'almacen_articulos.php' . ($qsListado ? '?' . http_build_query($qsListado) : '');
$volverParam = urlencode($urlListadoActual);
$delegaciones = $pdo->query('SELECT * FROM delegaciones ORDER BY nombre COLLATE utf8mb4_general_ci')->fetchAll();

function urlPagina(array $cambios): string
{
    $params = array_merge($_GET, $cambios);
    return 'almacen_articulos.php?' . http_build_query($params);
}

$titulo = 'Artículos';
$activo = 'articulos';
require __DIR__ . '/includes/header.php';
?>
<section class="panel panel--listado">
  <div class="panel--listado__fijo">
  <div class="panel__title-bar"><span class="panel__title-pill">Mantenimiento artículos</span></div>

  <?php if (!empty($_GET['error'])): ?><p class="form-error"><?= htmlspecialchars($_GET['error']) ?></p><?php endif; ?>

  <form class="search-bar" method="get" action="almacen_articulos.php">
    <div class="search-bar__fila">
      <label class="search-bar__label" for="q">Búsqueda</label>
      <input class="search-bar__input" type="text" id="q" name="q"
             value="<?= htmlspecialchars($query) ?>" placeholder="Escribe para buscar…">
      <select class="search-bar__select" name="campo">
        <?php foreach ($etiquetasBusqueda as $campo => $etiqueta): ?>
          <option value="<?= $campo ?>" <?= $campo === $campoGeneral ? 'selected' : '' ?>><?= $etiqueta ?></option>
        <?php endforeach; ?>
      </select>
      <button class="btn btn--primary" type="submit">🔍 Buscar</button>
      <select class="search-bar__select" name="delegacion_id" onchange="this.form.submit()">
        <option value="">Todas las delegaciones</option>
        <?php foreach ($delegaciones as $d): ?>
          <option value="<?= (int) $d['id'] ?>" <?= $delegacionId === (string) $d['id'] ? 'selected' : '' ?>><?= htmlspecialchars($d['nombre']) ?></option>
        <?php endforeach; ?>
      </select>
      <select class="search-bar__select" name="activo" onchange="this.form.submit()">
        <option value="">Activos e inactivos</option>
        <option value="1" <?= $activoFiltro === '1' ? 'selected' : '' ?>>Solo activos</option>
        <option value="0" <?= $activoFiltro === '0' ? 'selected' : '' ?>>Solo inactivos</option>
      </select>
    </div>
    <div class="search-bar__fila">
      <a class="btn btn--secondary" href="articulo_form.php">➕ Nuevo artículo</a>
      <button type="button" class="btn btn--secondary" id="btn-modo-seleccion" onclick="alternarModoSeleccion()">☑️ Seleccionar</button>
      <a class="btn btn--secondary" href="marcas.php">🏷️ Marcas</a>
      <span class="search-bar__hueco"></span>
      <button type="button" class="btn btn--secondary" data-reset-columns-for="tabla-articulos">↔️ Restablecer columnas</button>
      <button type="submit" form="form-filtros-art" class="btn btn--secondary">🔎 Filtrar</button>
      <a class="btn btn--secondary" href="almacen_articulos.php">🧹 Limpiar</a>
    </div>
  </form>

  <?php if (!empty($_GET['accion_masiva'])): $n = (int) ($_GET['n'] ?? 0); ?>
    <p class="form-ok"><?= $n ?> artículo<?= $n !== 1 ? 's' : '' ?>
      <?= ['activados' => 'activado', 'desactivados' => 'desactivado', 'borrados' => 'eliminado'][$_GET['accion_masiva']] ?? '' ?><?= $n !== 1 ? 's' : '' ?>.</p>
  <?php endif; ?>

  <div class="panel__seleccion" id="contador-seleccion" style="display:none;">
    <span id="texto-contador-seleccion">0 seleccionados</span>
    <button type="submit" form="form-accion-masiva-art" formaction="articulos_accion_masiva.php?volver=<?= $volverParam ?>" name="accion" value="borrar" class="btn btn--danger" onclick="return confirm('¿Eliminar todos los artículos seleccionados?');">🗑️ Borrar seleccionados</button>
    <button type="submit" form="form-accion-masiva-art" formaction="articulos_accion_masiva.php?volver=<?= $volverParam ?>" name="accion" value="activar" class="btn btn--secondary">✅ Activar seleccionados</button>
    <button type="submit" form="form-accion-masiva-art" formaction="articulos_accion_masiva.php?volver=<?= $volverParam ?>" name="accion" value="desactivar" class="btn btn--secondary">🚫 Desactivar seleccionados</button>
  </div>

  <?php require __DIR__ . '/includes/paginacion.php'; ?>

  <form method="get" action="almacen_articulos.php" id="form-filtros-art">
    <?php if ($query !== ''): ?><input type="hidden" name="q" value="<?= htmlspecialchars($query) ?>"><?php endif; ?>
    <?php if ($campoGeneral !== 'nombre'): ?><input type="hidden" name="campo" value="<?= htmlspecialchars($campoGeneral) ?>"><?php endif; ?>
    <?php if ($delegacionId !== ''): ?><input type="hidden" name="delegacion_id" value="<?= htmlspecialchars($delegacionId) ?>"><?php endif; ?>
    <?php if ($activoFiltro !== ''): ?><input type="hidden" name="activo" value="<?= htmlspecialchars($activoFiltro) ?>"><?php endif; ?>
    <?php if ($porPaginaParam !== '100'): ?><input type="hidden" name="por_pagina" value="<?= htmlspecialchars($porPaginaParam) ?>"><?php endif; ?>
  </form>
  </div><!-- fin zona fija -->

  <div class="panel--listado__scroll">
  <form method="post" id="form-accion-masiva-art">
    <table class="data-table data-table--resizable" id="tabla-articulos" data-column-storage-key="opticas:listado:articulos:columnas">
      <thead>
        <tr>
          <th class="col-check" data-col-key="seleccion" data-col-fixed="1"><input type="checkbox" id="chk-todos" onclick="alternarTodos(this)"></th>
          <th class="col-id" data-col-key="numero"><a href="<?= urlOrdenar('id') ?>" class="th-orden">Número<?= indicadorOrden('id', $ordenActual, $dirActual) ?></a></th>
          <th data-col-key="codigo"><a href="<?= urlOrdenar('codigo') ?>" class="th-orden">Código<?= indicadorOrden('codigo', $ordenActual, $dirActual) ?></a></th>
          <th data-col-key="referencia"><a href="<?= urlOrdenar('referencia') ?>" class="th-orden">Referencia<?= indicadorOrden('referencia', $ordenActual, $dirActual) ?></a></th>
          <th data-col-key="nombre"><a href="<?= urlOrdenar('nombre') ?>" class="th-orden">Nombre<?= indicadorOrden('nombre', $ordenActual, $dirActual) ?></a></th>
          <th data-col-key="codigo_barras"><a href="<?= urlOrdenar('codigo_barras') ?>" class="th-orden">Cód. Barras<?= indicadorOrden('codigo_barras', $ordenActual, $dirActual) ?></a></th>
          <th data-col-key="marca"><a href="<?= urlOrdenar('marca') ?>" class="th-orden">Marca<?= indicadorOrden('marca', $ordenActual, $dirActual) ?></a></th>
          <th data-col-key="coste"><a href="<?= urlOrdenar('coste') ?>" class="th-orden">Coste<?= indicadorOrden('coste', $ordenActual, $dirActual) ?></a></th>
          <th data-col-key="pvp"><a href="<?= urlOrdenar('pvp') ?>" class="th-orden">PVP<?= indicadorOrden('pvp', $ordenActual, $dirActual) ?></a></th>
          <th data-col-key="existencias"><a href="<?= urlOrdenar('existencias') ?>" class="th-orden">Existencias<?= indicadorOrden('existencias', $ordenActual, $dirActual) ?></a></th>
          <th data-col-key="delegacion"><a href="<?= urlOrdenar('delegacion') ?>" class="th-orden">Delegación<?= indicadorOrden('delegacion', $ordenActual, $dirActual) ?></a></th>
        </tr>
        <tr class="data-table__filters">
          <td></td>
          <?php foreach ($camposFiltro as $campo): ?>
            <td data-col-key="<?= htmlspecialchars($campo) ?>"><input type="text" name="filtro_<?= $campo ?>" form="form-filtros-art" value="<?= htmlspecialchars($filtrosColumna[$campo] ?? '') ?>"></td>
          <?php endforeach; ?>
        </tr>
      </thead>
      <tbody>
        <?php if (empty($articulos)): ?>
          <tr><td colspan="11" class="empty-row">No hay artículos que coincidan con la búsqueda.</td></tr>
        <?php else: foreach ($articulos as $a): ?>
          <tr id="fila-articulo-<?= (int) $a['id'] ?>"
              ondblclick="if (!event.target.closest('input,button,a,select,textarea')) location.href='articulo_form.php?id=<?= (int) $a['id'] ?>&volver=<?= $volverParam ?>&origen=<?= (int)$a['id'] ?>'"
              class="fila-clicable <?= $origenId && $origenId === (int)$a['id'] ? 'fila-origen' : '' ?> <?= $resaltarId && $resaltarId !== $origenId && $resaltarId === (int)$a['id'] ? 'fila-resaltada' : '' ?>">
            <td class="col-check"><input type="checkbox" class="chk-articulo" name="ids[]" value="<?= (int) $a['id'] ?>" onclick="event.stopPropagation(); actualizarContadorSeleccion();"></td>
            <td class="col-id"><?= (int) $a['id'] ?></td>
            <td><?= htmlspecialchars($a['codigo'] ?? '') ?></td>
            <td><?= htmlspecialchars($a['referencia'] ?? '') ?></td>
            <td><?= htmlspecialchars($a['nombre'] ?? '') ?></td>
            <td><?= htmlspecialchars($a['codigo_barras'] ?? '') ?></td>
            <td><?= htmlspecialchars($a['marca_nombre'] ?? '') ?></td>
            <td><?= number_format((float) $a['coste'], 2, ',', '.') ?></td>
            <td><?= number_format((float) $a['pvp'], 2, ',', '.') ?></td>
            <td><?= number_format((float) $a['existencias'], 0, ',', '.') ?></td>
            <td><?= htmlspecialchars($a['delegacion_nombre'] ?? '') ?></td>
          </tr>
        <?php endforeach; endif; ?>
      </tbody>
    </table>
  </form>
  </div><!-- fin zona scroll -->
</section>
<?php if ($resaltarId): ?>
<script>
  var f = document.getElementById('fila-articulo-<?= $resaltarId ?>');
  if (f) f.scrollIntoView({ block: 'center' });
</script>
<?php endif; ?>
<script>
function alternarModoSeleccion() {
  var t = document.getElementById('tabla-articulos');
  var cont = document.getElementById('contador-seleccion');
  var b = document.getElementById('btn-modo-seleccion');
  var activo = t.classList.toggle('modo-seleccion');
  cont.style.display = activo ? '' : 'none';
  b.textContent = activo ? '☑️ Cancelar selección' : '☑️ Seleccionar';
  if (!activo) {
    document.querySelectorAll('.chk-articulo').forEach(function (c) { c.checked = false; });
    document.getElementById('chk-todos').checked = false;
    actualizarContadorSeleccion();
  }
}
function alternarTodos(o) {
  document.querySelectorAll('.chk-articulo').forEach(function (c) { c.checked = o.checked; });
  actualizarContadorSeleccion();
}
function actualizarContadorSeleccion() {
  var n = document.querySelectorAll('.chk-articulo:checked').length;
  document.getElementById('texto-contador-seleccion').textContent = n + (n === 1 ? ' seleccionado' : ' seleccionados');
}
</script>
<script src="js/listado_columnas.js?v=1056"></script>
<?php require __DIR__ . '/includes/footer.php'; ?>
