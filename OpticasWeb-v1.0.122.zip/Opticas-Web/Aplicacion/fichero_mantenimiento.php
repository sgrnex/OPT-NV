<?php
require __DIR__.'/includes/auth.php'; requireLogin(); require __DIR__.'/db.php';
$pdo=obtenerConexion();
$tipos=['vendedores'=>['Vendedores','vendedores'],'doctores'=>['Doctores','doctores'],'opticos'=>['Ópticos','opticos']];
$tipo=$_GET['tipo']??'vendedores'; if(!isset($tipos[$tipo]))$tipo='vendedores';
[$titulo,$tabla]=$tipos[$tipo]; $existe=tablaExiste($pdo,$tabla); $filas=[];
if($existe)$filas=$pdo->query('SELECT * FROM '.$tabla.' ORDER BY nombre')->fetchAll();
$activo=$tipo; require __DIR__.'/includes/header.php';
?><section class="panel"><div class="panel__title-bar"><span class="panel__title-pill"><?=htmlspecialchars($titulo)?></span></div>
<div class="record-form__actions"><a class="btn btn--secondary" href="fichero_listado.php?tipo=<?=urlencode($tipo)?>">📋 Listados de <?=htmlspecialchars($titulo)?></a></div>
<?php if(!$existe):?><p>La base de datos aún no contiene la tabla de <?=htmlspecialchars($titulo)?>.</p><?php else:?><p><?=count($filas)?> registros</p><div class="table-scroll"><table class="data-table"><thead><tr><th>Número</th><th>Nombre</th><th>Email</th><th>Teléfono</th></tr></thead><tbody><?php foreach($filas as $f):?><tr><td><?=(int)($f['id']??0)?></td><td><?=htmlspecialchars((string)($f['nombre']??''))?></td><td><?=htmlspecialchars((string)($f['email']??''))?></td><td><?=htmlspecialchars((string)($f['telefono']??''))?></td></tr><?php endforeach;?></tbody></table></div><?php endif;?></section><?php require __DIR__.'/includes/footer.php';?>
