<?php
require __DIR__ . '/includes/auth.php';
requireLogin();
require __DIR__ . '/db.php';
require __DIR__ . '/includes/grid_repetible.php';

$pdo = obtenerConexion();
$id = (int) ($_GET['id'] ?? 0);

$stmt = $pdo->prepare('SELECT * FROM clientes WHERE id = :id');
$stmt->execute(['id' => $id]);
$cliente = $stmt->fetch();
if (!$cliente) {
    header('Location: index.php');
    exit;
}

$config = require __DIR__ . '/includes/grids_config.php';
$volver = "ficha_gafas.php?id=$id";

$categorias = [
    'lejos' => 'Graduación y Cristales LEJOS',
    'cerca' => 'Graduación y Cristales CERCA',
    'multifocal' => 'Graduación y Cristales MULTIFOCAL',
];

$esExistente = true;
$titulo = 'Ficha Gafas';
$activo = 'clientes';
$tabActiva = 'gafas';
require __DIR__ . '/includes/header.php';
?>
<section class="panel">
  <div class="panel__title-bar"><span class="panel__title-pill">Ficha cliente</span><span class="panel__title-cliente"><?= htmlspecialchars(trim(($cliente['nombre'] ?? '') . ' ' . ($cliente['apellidos'] ?? ''))) ?></span></div>
  <?php require __DIR__ . '/includes/ficha_cliente_tabs.php'; ?>

  <?php $formGuardarId = null; require __DIR__ . '/includes/ficha_acciones.php'; ?>

  <?php foreach ($categorias as $clave => $nombre): ?>
    <details class="ficha-seccion" <?= $clave === 'lejos' ? 'open' : '' ?>>
      <summary class="ficha-seccion__titulo"><?= htmlspecialchars($nombre) ?></summary>

      <?php foreach (['D' => 'Ojo Derecho', 'I' => 'Ojo Izquierdo'] as $ojo => $nombreOjo): ?>
        <p class="ficha-seccion__ojo">👁️ <?= $nombreOjo ?></p>
        <div class="grid-repetible-par">
          <div class="grid-repetible-par__col">
            <?php pintarGridRepetible($pdo, 'graduaciones', $config['graduaciones']['columnas'],
                ['cliente_id' => $id, 'categoria' => $clave, 'ojo' => $ojo], $volver); ?>
          </div>
          <div class="grid-repetible-par__col grid-repetible-par__col--estrecha">
            <?php pintarGridRepetible($pdo, 'graduaciones_productos', $config['graduaciones_productos']['columnas'],
                ['cliente_id' => $id, 'categoria' => $clave, 'ojo' => $ojo], $volver); ?>
          </div>
        </div>
      <?php endforeach; ?>
    </details>
  <?php endforeach; ?>

  <details class="ficha-seccion">
    <summary class="ficha-seccion__titulo">Monturas</summary>
    <?php pintarGridRepetible($pdo, 'monturas', $config['monturas']['columnas'], ['cliente_id' => $id], $volver); ?>
  </details>

  <details class="ficha-seccion">
    <summary class="ficha-seccion__titulo">Gafas de Sol</summary>
    <?php pintarGridRepetible($pdo, 'gafas_sol', $config['gafas_sol']['columnas'], ['cliente_id' => $id], $volver); ?>
  </details>

  <div class="record-form__actions">
    <a class="btn btn--secondary" href="<?= htmlspecialchars($volverListado) ?><?= strpos($volverListado, '?') !== false ? '&' : '?' ?>resaltar=<?= (int) $id ?>&origen=<?= (int)($_GET['origen'] ?? $id) ?>">↩️ Volver</a>
  </div>
</section>
<?php require __DIR__ . '/includes/modal_articulo.php'; ?>
<?php require __DIR__ . '/includes/footer.php'; ?>
