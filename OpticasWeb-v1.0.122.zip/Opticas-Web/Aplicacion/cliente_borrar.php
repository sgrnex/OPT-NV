<?php
require __DIR__ . '/includes/auth.php';
requireLogin();
require __DIR__ . '/db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = (int) ($_POST['id'] ?? 0);
    $pdo = obtenerConexion();
    $volver = $_POST['volver'] ?? $_GET['volver'] ?? 'index.php';

    if (clienteTieneRegistrosAsociados($pdo, $id)) {
        $mensaje = 'No se puede eliminar: el cliente tiene ficha óptica, ventas o facturas asociadas.';
        header('Location: index.php?error=' . urlencode($mensaje));
        exit;
    }

    $pdo->prepare('DELETE FROM clientes WHERE id = :id')->execute(['id' => $id]);
    header('Location: ' . $volver);
    exit;
}

header('Location: index.php');
exit;
