<?php
require __DIR__ . '/includes/auth.php';
requireLogin();
require __DIR__ . '/db.php';
$pdo = obtenerConexion();
$q = trim($_GET['q'] ?? '');
$activoFiltro = $_GET['activo'] ?? '';
$delegacionId = $_GET['delegacion_id'] ?? '';
$where=[]; $par=[];
if ($q !== '') {
  $where[] = '(p.nombre LIKE :q OR p.nif LIKE :q OR p.contacto LIKE :q OR p.telefono LIKE :q OR p.email LIKE :q)';
  $par['q']='%'.$q.'%';
}
if ($activoFiltro === '0' || $activoFiltro === '1') { $where[]='p.activo=:activo'; $par['activo']=(int)$activoFiltro; }
if ($delegacionId !== '') { $where[]='p.delegacion_id=:deleg'; $par['deleg']=(int)$delegacionId; }
$sql='SELECT p.*, d.nombre AS delegacion_nombre FROM proveedores p LEFT JOIN delegaciones d ON d.id=p.delegacion_id';
if ($where) $sql.=' WHERE '.implode(' AND ',$where);
$sql.=' ORDER BY p.nombre COLLATE utf8mb4_general_ci, p.id';
$st=$pdo->prepare($sql); $st->execute($par); $proveedores=$st->fetchAll();
$delegaciones=$pdo->query('SELECT * FROM delegaciones ORDER BY nombre COLLATE utf8mb4_general_ci')->fetchAll();
$titulo='Proveedores'; $activo='proveedores'; require __DIR__ . '/includes/header.php';
?>
<section class="panel panel--listado">
  <div class="panel--listado__fijo">
    <div class="panel__title-bar"><span class="panel__title-pill">Mantenimiento proveedores</span></div>
    <?php if (!empty($_GET['desactivado'])): ?><p class="form-ok">Proveedor desactivado porque tiene histórico asociado.</p><?php endif; ?>
    <form class="search-bar" method="get" action="proveedores.php">
      <div class="search-bar__fila">
        <label class="search-bar__label" for="q">Búsqueda</label>
        <input class="search-bar__input" id="q" name="q" value="<?= htmlspecialchars($q) ?>" placeholder="Nombre, NIF, contacto, teléfono, email…">
        <button class="btn btn--primary" type="submit">🔍 Buscar</button>
        <select class="search-bar__select" name="delegacion_id" onchange="this.form.submit()">
          <option value="">Todas las delegaciones</option>
          <?php foreach ($delegaciones as $d): ?><option value="<?= (int)$d['id'] ?>" <?= $delegacionId===(string)$d['id']?'selected':'' ?>><?= htmlspecialchars($d['nombre']) ?></option><?php endforeach; ?>
        </select>
        <select class="search-bar__select" name="activo" onchange="this.form.submit()">
          <option value="">Activos e inactivos</option><option value="1" <?= $activoFiltro==='1'?'selected':'' ?>>Solo activos</option><option value="0" <?= $activoFiltro==='0'?'selected':'' ?>>Solo inactivos</option>
        </select>
      </div>
      <div class="search-bar__fila"><a class="btn btn--secondary" href="proveedor_form.php">➕ Nuevo proveedor</a><a class="btn btn--secondary" href="proveedores_listados.php">📋 Listados de Proveedores</a><span class="search-bar__hueco"></span><a class="btn btn--secondary" href="proveedores.php">🧹 Limpiar</a></div>
    </form>
    <div class="paginacion"><span class="paginacion__info"><?= count($proveedores) ?> proveedor<?= count($proveedores)===1?'':'es' ?></span></div>
  </div>
  <div class="panel--listado__scroll">
    <table class="data-table data-table--resizable" id="tabla-proveedores" data-column-storage-key="opticas:listado:proveedores:columnas">
      <thead><tr><th class="col-id" data-col-key="numero">Número</th><th data-col-key="nombre">Nombre</th><th data-col-key="nif">NIF</th><th data-col-key="contacto">Contacto</th><th data-col-key="telefono">Teléfono</th><th data-col-key="poblacion">Población</th><th data-col-key="email">Email</th><th data-col-key="delegacion">Delegación</th></tr></thead>
      <tbody>
      <?php if (!$proveedores): ?><tr><td colspan="8" class="empty-row">No hay proveedores.</td></tr><?php else: foreach($proveedores as $p): ?>
        <tr class="fila-clicable <?= empty($p['activo'])?'fila-inactiva':'' ?>" ondblclick="location.href='proveedor_form.php?id=<?= (int)$p['id'] ?>'">
          <td class="col-id"><?= (int)$p['id'] ?></td><td><?= htmlspecialchars($p['nombre']) ?></td><td><?= htmlspecialchars($p['nif']??'') ?></td><td><?= htmlspecialchars($p['contacto']??'') ?></td><td><?= htmlspecialchars($p['telefono']??'') ?></td><td><?= htmlspecialchars($p['poblacion']??'') ?></td><td><?= htmlspecialchars($p['email']??'') ?></td><td><?= htmlspecialchars($p['delegacion_nombre']??'') ?></td>
        </tr>
      <?php endforeach; endif; ?>
      </tbody>
    </table>
  </div>
</section>
<script src="js/listado_columnas.js?v=1056"></script>
<?php require __DIR__ . '/includes/footer.php'; ?>
