<?php
require __DIR__ . '/includes/auth.php';
requireLogin();
require __DIR__ . '/db.php';
$pdo = obtenerConexion();
$formatos = ['pantalla'=>'Ver en pantalla', 'pdf'=>'PDF', 'excel'=>'Excel', 'rtf'=>'RTF', 'csv'=>'CSV', 'xml'=>'XML', 'html'=>'HTML'];
if (isset($_GET['formato']) && isset($formatos[$_GET['formato']])) {
    require __DIR__ . '/includes/listados_export.php';
    $st = $pdo->query('SELECT p.id, p.nombre, p.nif, p.contacto, p.telefono, p.poblacion, p.email, d.nombre AS delegacion FROM proveedores p LEFT JOIN delegaciones d ON d.id=p.delegacion_id ORDER BY p.nombre, p.id');
    $datos = ['titulo'=>'Listado Proveedores', 'activo'=>'proveedores', 'volver'=>'proveedores_listados.php', 'archivo'=>'listado_proveedores', 'modo'=>'tabla', 'columnas'=>['Número','Proveedor','NIF','Contacto','Teléfono','Población','Email','Delegación'], 'filas'=>$st->fetchAll(PDO::FETCH_NUM)];
    $opciones = ['orientacion'=>'horizontal', 'tam_letra'=>'pequeno', 'fuente'=>'arial'];
    switch ($_GET['formato']) {
        case 'pdf': exportarListadoPdf($datos, $opciones); break;
        case 'excel': exportarListadoExcel($datos); break;
        case 'rtf': exportarListadoRtf($datos); break;
        case 'csv': exportarListadoCsv($datos); break;
        case 'xml': exportarListadoXml($datos); break;
        case 'html': exportarListadoHtml($datos); break;
        default: exportarListadoPantalla($datos);
    }
    exit;
}
$titulo = 'Listados Proveedores'; $activo = 'proveedores';
require __DIR__ . '/includes/header.php';
?>
<section class="panel">
  <div class="panel__title-bar"><span class="panel__title-pill">Listado Proveedores</span></div>
  <div class="record-form__actions" style="justify-content:center;flex-wrap:wrap">
    <?php foreach ($formatos as $valor=>$nombre): ?>
      <a class="btn btn--secondary" href="proveedores_listados.php?formato=<?= $valor ?>"><?= $nombre ?></a>
    <?php endforeach; ?>
  </div>
</section>
<?php require __DIR__ . '/includes/footer.php'; ?>
