<?php
require __DIR__ . '/includes/auth.php';
requireLogin();
require __DIR__ . '/db.php';
require __DIR__ . '/includes/listados_datos.php';
require __DIR__ . '/includes/listados_export.php';

$pdo = obtenerConexion();

$tiposPermitidos = ['general', 'graduaciones', 'lentillas', 'audifonos'];
$tipo = $_GET['tipo'] ?? 'general';
if (!in_array($tipo, $tiposPermitidos, true)) {
    $tipo = 'general';
}

$formatosPermitidos = ['pantalla', 'imprimir', 'pdf', 'excel', 'csv', 'rtf', 'xml', 'html'];
$formato = $_GET['formato'] ?? 'pantalla';
if (!in_array($formato, $formatosPermitidos, true)) {
    $formato = 'pantalla';
}

$colsPermitidas = ['nif', 'telefono', 'poblacion', 'provincia', 'email', 'delegacion'];
$seleccionColumnasExplicita = array_key_exists('columnas_definidas', $_GET);
$cols = array_values(array_intersect($colsPermitidas, (array) ($_GET['col'] ?? [])));
if (!$seleccionColumnasExplicita && empty($cols)) {
    $cols = $colsPermitidas;
}

// Filtro común "a qué clientes incluir"
$filtros = [
    'nombre'     => trim($_GET['f_nombre'] ?? ''),
    'nif'        => trim($_GET['f_nif'] ?? ''),
    'telefono'   => trim($_GET['f_telefono'] ?? ''),
    'poblacion'  => trim($_GET['f_poblacion'] ?? ''),
    'provincia'  => trim($_GET['f_provincia'] ?? ''),
    'email'      => trim($_GET['f_email'] ?? ''),
    'edad_desde' => trim($_GET['f_edad_desde'] ?? ''),
    'edad_hasta' => trim($_GET['f_edad_hasta'] ?? ''),
    'alta_desde' => trim($_GET['f_alta_desde'] ?? ''),
    'alta_hasta' => trim($_GET['f_alta_hasta'] ?? ''),
    'nac_desde'  => trim($_GET['f_nac_desde'] ?? ''),
    'nac_hasta'  => trim($_GET['f_nac_hasta'] ?? ''),
    'delegacion' => trim($_GET['f_delegacion'] ?? ''),
    'estado'     => trim($_GET['f_estado'] ?? ''),
    'mailing'    => trim($_GET['f_mailing'] ?? ''),
    'revision'   => trim($_GET['f_revision'] ?? ''),
];

$opciones = [
    'grad_desde'   => trim($_GET['grad_desde'] ?? ''),
    'grad_hasta'   => trim($_GET['grad_hasta'] ?? ''),
    'grad_detalle' => !empty($_GET['grad_detalle']),
    'lent_detalle' => !empty($_GET['lent_detalle']),
    'audi_detalle' => !empty($_GET['audi_detalle']),
    'cols'         => $cols,
    'filtros'      => $filtros,
    'orientacion'  => ($_GET['orientacion'] ?? 'vertical') === 'horizontal' ? 'horizontal' : 'vertical',
    'tam_letra'    => in_array($_GET['tam_letra'] ?? '', ['muy_pequeno', 'pequeno', 'normal', 'grande', 'muy_grande'], true) ? $_GET['tam_letra'] : 'normal',
    'fuente'       => in_array($_GET['fuente'] ?? '', ['arial', 'times', 'courier'], true) ? $_GET['fuente'] : 'arial',
];

$datos = generarDatosListadoClientes($pdo, $tipo, $opciones);

switch ($formato) {
    case 'imprimir': exportarListadoImprimir($datos, $opciones); break;
    case 'pdf':      exportarListadoPdf($datos, $opciones); break;
    case 'excel':    exportarListadoExcel($datos); break;
    case 'csv':      exportarListadoCsv($datos); break;
    case 'rtf':      exportarListadoRtf($datos); break;
    case 'xml':      exportarListadoXml($datos); break;
    case 'html':     exportarListadoHtml($datos); break;
    case 'pantalla':
    default:         exportarListadoPantalla($datos); break;
}
