<?php
// Datos de la óptica para el documento de autorización de Mailing/SMS.
// Esto es un valor provisional: cuando construyamos la fase de
// Configuración, estos datos se editarán desde ahí en vez de aquí.
return [
    'nombre'          => 'Óptica Nueva Visión',
    'nif'             => '00000000M',
    'direccion'       => 'Paseo de San Antón, 10, Carmona (Sevilla)',
    'email'           => '',
    'poblacion_firma' => 'Carmona',
];
