<?php
require __DIR__ . '/includes/auth.php'; requireLogin(); require __DIR__ . '/db.php';
$pdo=obtenerConexion(); $id=(int)($_POST['id']??0);
if($id){$pdo->prepare('UPDATE proveedores SET activo=0, fecha_baja=COALESCE(fecha_baja,CURDATE()), fecha_modificacion=CURDATE() WHERE id=:id')->execute(['id'=>$id]);}
header('Location: proveedores.php?desactivado=1'); exit;
