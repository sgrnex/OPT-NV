<?php
// Compatibilidad con accesos antiguos: la portada retocada es ahora también
// la pantalla única de inicio de sesión.
$next = urlencode($_GET['next'] ?? 'index.php');
header('Location: inicio.php?next=' . $next);
exit;
