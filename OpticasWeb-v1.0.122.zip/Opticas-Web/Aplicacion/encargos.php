<?php
require __DIR__.'/includes/auth.php';
requireLogin();
require __DIR__.'/db.php';
$pdo=obtenerConexion();
function encTexto($datos,$clave,$defecto='') { return isset($datos[$clave])&&is_scalar($datos[$clave])?trim((string)$datos[$clave]):$defecto; }
function encHtml($valor) { return htmlspecialchars((string)$valor,ENT_QUOTES,'UTF-8'); }
$estados=['pendiente','pedido','recibido','avisado','entregado','cancelado'];
$columnas=['id'=>'Número','fecha'=>'Fecha','cliente'=>'Cliente','articulo'=>'Artículo','estado'=>'Estado','observaciones'=>'Observaciones'];
$ordenSql=['id'=>'e.id','fecha'=>'e.fecha','cliente'=>'cliente','articulo'=>'e.articulo','estado'=>'e.estado','observaciones'=>'e.observaciones'];
$q=encTexto($_GET,'q'); $estadoFiltro=encTexto($_GET,'estado');
if (!in_array($estadoFiltro,$estados,true)) $estadoFiltro='';
$orden=encTexto($_GET,'orden','fecha'); if (!isset($ordenSql[$orden])) $orden='fecha';
$dir=encTexto($_GET,'dir')==='asc'?'asc':'desc';
$porPagina=(int)encTexto($_GET,'por_pagina','50'); if (!in_array($porPagina,[25,50,100,200],true)) $porPagina=50;
$pagina=max(1,(int)encTexto($_GET,'pagina','1'));
$contexto=['q'=>$q,'estado'=>$estadoFiltro,'orden'=>$orden,'dir'=>$dir,'por_pagina'=>$porPagina,'pagina'=>$pagina];
function encUrl($cambios=[]) { global $contexto; return 'encargos.php?'.http_build_query(array_merge($contexto,$cambios)); }
$existe=tablaExiste($pdo,'encargos');
$error=''; $id=max(0,(int)encTexto($_GET,'id'));
$editar=$id>0||isset($_GET['nuevo'])||$_SERVER['REQUEST_METHOD']==='POST';
$f=['cliente_id'=>'','fecha'=>date('Y-m-d'),'articulo'=>'','estado'=>'pendiente','observaciones'=>''];
$_SESSION['encargos_token']=$_SESSION['encargos_token']??bin2hex(random_bytes(32));
if ($existe&&$id) {
    $st=$pdo->prepare('SELECT * FROM encargos WHERE id=?');$st->execute([$id]);$existente=$st->fetch();
    if (!$existente) {http_response_code(404);exit('Encargo no encontrado.');}
    $f=$existente;
}
if ($existe&&$_SERVER['REQUEST_METHOD']==='POST') {
    foreach (['cliente_id','fecha','articulo','estado','observaciones'] as $k) $f[$k]=encTexto($_POST,$k);
    $fecha=DateTime::createFromFormat('!Y-m-d',$f['fecha']);
    $st=$pdo->prepare('SELECT id FROM clientes WHERE id=?');$st->execute([(int)$f['cliente_id']]);
    $clienteExiste=$st->fetchColumn();
    if (!hash_equals($_SESSION['encargos_token'],encTexto($_POST,'token'))) $error='Formulario caducado. Revisa los datos y vuelve a guardar.';
    elseif (!ctype_digit($f['cliente_id'])||!$clienteExiste) $error='El número de cliente no existe.';
    elseif (!$fecha||$fecha->format('Y-m-d')!==$f['fecha']) $error='La fecha no es válida.';
    elseif ($f['articulo']===''||preg_match_all('/./us',$f['articulo'])>180) $error='Indica un artículo de hasta 180 caracteres.';
    elseif (!in_array($f['estado'],$estados,true)) $error='Estado no válido.';
    elseif (strlen($f['observaciones'])>60000) $error='Las observaciones son demasiado extensas.';
    else {
        $valores=[(int)$f['cliente_id'],$f['fecha'],$f['articulo'],$f['estado'],$f['observaciones']];
        if ($id) {
            $st=$pdo->prepare('UPDATE encargos SET cliente_id=?,fecha=?,articulo=?,estado=?,observaciones=?,fecha_modificacion=NOW() WHERE id=?');
            $valores[]=$id;
        } else $st=$pdo->prepare('INSERT INTO encargos(cliente_id,fecha,articulo,estado,observaciones,fecha_modificacion) VALUES(?,?,?,?,?,NOW())');
        $st->execute($valores);
        header('Location: '.encUrl(['guardado'=>1]));exit;
    }
}
$filas=[];$total=0;$paginas=1;
if ($existe) {
    $base=" FROM encargos e LEFT JOIN clientes c ON c.id=e.cliente_id";
    $where=[];$params=[];
    if ($q!=='') {
        $where[]="(e.articulo LIKE ? OR CONCAT(COALESCE(c.nombre,''),' ',COALESCE(c.apellidos,'')) LIKE ? OR e.observaciones LIKE ?)";
        $params=array_fill(0,3,'%'.$q.'%');
    }
    if ($estadoFiltro!=='') {$where[]='e.estado=?';$params[]=$estadoFiltro;}
    if ($where) $base.=' WHERE '.implode(' AND ',$where);
    $st=$pdo->prepare('SELECT COUNT(*)'.$base);$st->execute($params);$total=(int)$st->fetchColumn();
    $paginas=max(1,(int)ceil($total/$porPagina));$pagina=min($pagina,$paginas);$contexto['pagina']=$pagina;
    $st=$pdo->prepare("SELECT e.*,CONCAT(COALESCE(c.nombre,''),' ',COALESCE(c.apellidos,'')) cliente".$base.' ORDER BY '.$ordenSql[$orden].' '.$dir.', e.id DESC LIMIT '.$porPagina.' OFFSET '.(($pagina-1)*$porPagina));
    $st->execute($params);$filas=$st->fetchAll();
}
$titulo='Encargos/Pedidos';$activo='encargos';require __DIR__.'/includes/header.php';
?>
<section class="panel panel--listado">
<div class="panel--listado__fijo">
<div class="panel__title-bar"><span class="panel__title-pill">Encargos/Pedidos</span></div>
<?php if (!$existe): ?><p>Ejecuta el actualizador de base de datos de la instalación para habilitar Encargos.</p><?php else: ?>
<?php if (isset($_GET['guardado'])): ?><p class="form-ok">Encargo guardado.</p><?php endif; ?>
<?php if ($error): ?><p class="form-error"><?=encHtml($error)?></p><?php endif; ?>
<?php if ($editar): ?>
<form method="post" action="<?=encHtml(encUrl($id?['id'=>$id]:['nuevo'=>1]))?>" class="record-form">
<h3><?=$id?'Editar encargo nº '.$id:'Nuevo encargo'?></h3>
<input type="hidden" name="token" value="<?=encHtml($_SESSION['encargos_token'])?>">
<div class="form-grid">
<label>Nº cliente<input type="number" min="1" name="cliente_id" required value="<?=encHtml($f['cliente_id'])?>"></label>
<label>Fecha<input type="date" name="fecha" required value="<?=encHtml($f['fecha'])?>"></label>
<label>Artículo/encargo<input name="articulo" maxlength="180" required value="<?=encHtml($f['articulo'])?>"></label>
<label>Estado<select name="estado"><?php foreach($estados as $e):?><option <?=$f['estado']===$e?'selected':''?>><?=$e?></option><?php endforeach;?></select></label>
<label>Observaciones<textarea name="observaciones"><?=encHtml($f['observaciones'])?></textarea></label>
</div>
<button class="btn btn--primary">Guardar</button> <a class="btn btn--secondary" href="<?=encHtml(encUrl())?>">Volver</a>
</form>
<?php endif; ?>
<form method="get" class="search-bar encargos-search">
<input name="q" value="<?=encHtml($q)?>" placeholder="Cliente, artículo u observaciones">
<select name="estado"><option value="">Todos los estados</option><?php foreach($estados as $e):?><option <?=$estadoFiltro===$e?'selected':''?>><?=$e?></option><?php endforeach;?></select>
<input type="hidden" name="orden" value="<?=encHtml($orden)?>"><input type="hidden" name="dir" value="<?=$dir?>">
<button class="btn btn--primary">Buscar</button>
<a class="btn btn--secondary" href="encargos.php">Limpiar</a>
<a class="btn btn--secondary" href="<?=encHtml(encUrl(['nuevo'=>1]))?>">Nuevo encargo</a>
</form>
<div class="paginacion"><span><?=$total?> encargos · Página <?=$pagina?> de <?=$paginas?></span>
<?php if($pagina>1):?><a class="btn btn--secondary" href="<?=encHtml(encUrl(['pagina'=>$pagina-1]))?>">Anterior</a><?php endif;?>
<?php if($pagina<$paginas):?><a class="btn btn--secondary" href="<?=encHtml(encUrl(['pagina'=>$pagina+1]))?>">Siguiente</a><?php endif;?>
<form method="get">
<?php foreach($contexto as $k=>$v): if(in_array($k,['pagina','por_pagina'],true))continue;?><input type="hidden" name="<?=$k?>" value="<?=encHtml($v)?>"><?php endforeach;?>
<label>Por página <select name="por_pagina"><?php foreach([25,50,100,200] as $n):?><option <?=$porPagina===$n?'selected':''?>><?=$n?></option><?php endforeach;?></select></label>
<label>Ir a página <input type="number" name="pagina" min="1" max="<?=$paginas?>" value="<?=$pagina?>"></label><button class="btn btn--secondary">Ir</button>
</form></div>
<?php endif;?>
</div>
<div class="panel--listado__scroll"><table class="data-table"><thead><tr>
<?php foreach($columnas as $k=>$nombre):?><th><a href="<?=encHtml(encUrl(['orden'=>$k,'dir'=>$orden===$k&&$dir==='asc'?'desc':'asc','pagina'=>1]))?>"><?=$nombre?><?=$orden===$k?($dir==='asc'?' ▲':' ▼'):''?></a></th><?php endforeach;?>
</tr></thead><tbody>
<?php foreach($filas as $fila):?><tr ondblclick="location.href=this.querySelector('a').href">
<?php foreach($columnas as $k=>$nombre):?><td><?php if($k==='id'):?><a href="<?=encHtml(encUrl(['id'=>(int)$fila['id']]))?>"><?=(int)$fila['id']?></a><?php else:?><?=encHtml($fila[$k]??'')?><?php endif;?></td><?php endforeach;?>
</tr><?php endforeach;?>
<?php if(!$filas):?><tr><td colspan="6">No hay encargos para estos filtros.</td></tr><?php endif;?>
</tbody></table></div></section>
<?php require __DIR__.'/includes/footer.php'; ?>
