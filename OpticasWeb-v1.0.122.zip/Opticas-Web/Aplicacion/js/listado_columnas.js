(function () {
  'use strict';

  // La versión 8 cambia de anchos absolutos a un reparto adaptable al ancho
  // real de cada listado. Los datos guardados con versiones anteriores se
  // descartan para evitar que una distribución antigua deforme la cabecera.
  var STORE_VERSION = 8;
  var MAX_COL_WIDTH = 900;
  var DEFAULTS = {
    'tabla-clientes': { seleccion:32, numero:58, nombre:138, apellidos:138, nif:112, telefono:118, poblacion:138, provincia:118, email:170, delegacion:122 },
    'tabla-articulos': { seleccion:32, numero:58, codigo:90, referencia:145, nombre:245, codigo_barras:125, marca:120, coste:82, pvp:82, existencias:96, delegacion:118 },
    'tabla-proveedores': { numero:58, nombre:220, nif:112, contacto:140, telefono:118, poblacion:138, email:210, delegacion:118 },
    'tabla-usuarios': { usuario:130, nombre:180, rol:120, ultimo_acceso:150, activo:76, acciones:118 },
    'tabla-marcas': { nombre:250, articulos:100, acciones:90 },
    'tabla-inventario': { numero:58, codigo:100, referencia:150, nombre:245, delegacion:125, stock:82, minimo:82, coste:90, pvp:90, estado:110 }
  };
  var MIN = {
    seleccion:28, acciones:44, numero:50, nombre:90, apellidos:90, nif:72,
    telefono:78, poblacion:86, provincia:76, email:96, delegacion:86,
    codigo:70, referencia:92, codigo_barras:88, marca:78, contacto:90,
    coste:64, pvp:64, existencias:76, stock:58, minimo:58, estado:78,
    usuario:90, rol:70, ultimo_acceso:110, activo:54, articulos:64
  };

  function gs(k) { try { return localStorage.getItem(k); } catch (e) { return null; } }
  function ss(k, v) { try { localStorage.setItem(k, v); } catch (e) {} }
  function rs(k) { try { localStorage.removeItem(k); } catch (e) {} }
  function ths(t) { return t.tHead && t.tHead.rows.length ? Array.from(t.tHead.rows[0].cells) : []; }
  function key(c) { return c.dataset.colKey || ''; }
  function min(k) { return MIN[k] || 72; }
  function clamp(k, v) {
    v = Number(v);
    return Number.isFinite(v) ? Math.max(min(k), Math.min(MAX_COL_WIDTH, Math.round(v))) : null;
  }
  function sk(t) { return (t.dataset.columnStorageKey || t.id || 'tabla') + ':v8'; }
  function clearOld(t) {
    var b = t.dataset.columnStorageKey || '';
    [b, b + ':v2', b + ':v3', b + ':v4', b + ':v5', b + ':v8',
      'opticas:listado:clientes:columnas:v1', 'opticas:listado:clientes:columnas:v2',
      'opticas:listado:clientes:columnas:v3', 'opticas:listado:articulos:columnas:v1',
      'opticas:listado:articulos:columnas:v2', 'opticas:listado:articulos:columnas:v3']
      .filter(Boolean).forEach(function (item) { if (item !== sk(t)) rs(item); });
  }
  function ensure(t, heads) {
    var old = t.querySelector('colgroup[data-resizable-columns]');
    if (old) old.remove();
    var cg = document.createElement('colgroup');
    cg.dataset.resizableColumns = '1';
    heads.forEach(function (h) {
      var c = document.createElement('col');
      c.dataset.colKey = key(h);
      cg.appendChild(c);
    });
    t.insertBefore(cg, t.firstChild);
  }
  function col(t, k) {
    return Array.from(t.querySelectorAll('colgroup[data-resizable-columns] col'))
      .find(function (c) { return c.dataset.colKey === k; }) || null;
  }
  function visibleHeads(t, heads) {
    return heads.filter(function (h) {
      return key(h) && !(key(h) === 'seleccion' && !t.classList.contains('modo-seleccion'));
    });
  }
  function isFixed(h) { return h.dataset.colFixed === '1'; }
  function defs(t, heads) {
    var m = DEFAULTS[t.id] || {}, r = {};
    heads.forEach(function (h) {
      var k = key(h);
      if (k) r[k] = clamp(k, m[k] || h.getBoundingClientRect().width || min(k)) || min(k);
    });
    return r;
  }
  function load(t, heads) {
    var raw = gs(sk(t));
    if (!raw) return null;
    try {
      var d = JSON.parse(raw), r = {};
      if (!d || d.version !== STORE_VERSION || !d.widths) throw 0;
      heads.forEach(function (h) {
        var k = key(h), w = clamp(k, d.widths[k]);
        if (!k || w === null) throw 0;
        r[k] = w;
      });
      return r;
    } catch (e) {
      rs(sk(t));
      return null;
    }
  }
  function logicalWidths(t, heads) {
    var r = {};
    heads.forEach(function (h) {
      var k = key(h), c = col(t, k);
      var w = c ? parseFloat(c.dataset.logicalWidth || c.style.width) : NaN;
      r[k] = clamp(k, w) || ((DEFAULTS[t.id] || {})[k] || min(k));
    });
    return r;
  }
  function availableWidth(t) {
    var box = t.closest('.panel--listado__scroll') || t.parentElement;
    return box ? Math.max(0, box.clientWidth) : 0;
  }
  function sumWidths(t, heads, w) {
    return visibleHeads(t, heads).reduce(function (total, h) {
      return total + (w[key(h)] || min(key(h)));
    }, 0);
  }
  function distributeAdd(items, w, amount) {
    var remaining = amount;
    for (var pass = 0; pass < 8 && remaining > 0.5; pass++) {
      var capacity = items.reduce(function (n, h) {
        return n + Math.max(0, MAX_COL_WIDTH - w[key(h)]);
      }, 0);
      if (capacity <= 0) break;
      items.forEach(function (h) {
        var k = key(h), room = Math.max(0, MAX_COL_WIDTH - w[k]);
        if (!room) return;
        var add = Math.min(room, remaining * (room / capacity));
        w[k] += add;
        remaining -= add;
      });
    }
  }
  function distributeRemove(items, w, amount) {
    var remaining = amount;
    for (var pass = 0; pass < 8 && remaining > 0.5; pass++) {
      var capacity = items.reduce(function (n, h) {
        return n + Math.max(0, w[key(h)] - min(key(h)));
      }, 0);
      if (capacity <= 0) break;
      items.forEach(function (h) {
        var k = key(h), room = Math.max(0, w[k] - min(k));
        if (!room) return;
        var take = Math.min(room, remaining * (room / capacity));
        w[k] -= take;
        remaining -= take;
      });
    }
    return amount - remaining;
  }
  function flexibleHeads(t, heads) {
    return visibleHeads(t, heads).filter(function (h) { return !isFixed(h); });
  }
  function fitToContainer(t, heads, source) {
    var w = Object.assign({}, source), available = availableWidth(t);
    if (!available) return w;
    var total = sumWidths(t, heads, w), flexible = flexibleHeads(t, heads);
    if (available > total) {
      distributeAdd(flexible.length ? flexible : visibleHeads(t, heads), w, available - total);
    } else if (available < total) {
      var removed = distributeRemove(flexible, w, total - available);
      if (total - removed > available) {
        distributeRemove(visibleHeads(t, heads), w, total - removed - available);
      }
    }
    return w;
  }
  function rebalanceRight(t, heads, source, target, delta) {
    var w = Object.assign({}, source), visible = visibleHeads(t, heads);
    var index = visible.findIndex(function (h) { return key(h) === target; });
    if (index < 0) return w;
    var right = visible.slice(index + 1).filter(function (h) { return !isFixed(h); });
    if (!right.length) return w;
    var base = source[target], wanted = clamp(target, base + delta);
    if (wanted === null) return w;
    var change = wanted - base;
    if (change > 0) {
      var actualGrow = distributeRemove(right, w, change);
      w[target] = base + actualGrow;
    } else if (change < 0) {
      var actualShrink = Math.min(-change, right.reduce(function (n, h) {
        return n + Math.max(0, MAX_COL_WIDTH - w[key(h)]);
      }, 0));
      distributeAdd(right, w, actualShrink);
      w[target] = base - actualShrink;
    }
    return w;
  }
  function apply(t, heads, source, fit) {
    var w = fit ? fitToContainer(t, heads, source) : source;
    var selectionHidden = !t.classList.contains('modo-seleccion');
    heads.forEach(function (h) {
      var k = key(h), c = col(t, k);
      if (!k || !c) return;
      var logical = w[k] || min(k);
      c.dataset.logicalWidth = logical;
      c.style.width = (k === 'seleccion' && selectionHidden ? 0 : logical) + 'px';
    });
    var total = sumWidths(t, heads, w), available = availableWidth(t);
    t.style.width = total > available + 1 ? total + 'px' : '100%';
    t.style.minWidth = total > available + 1 ? total + 'px' : '100%';
    return w;
  }
  function save(t, w) {
    ss(sk(t), JSON.stringify({ version: STORE_VERSION, widths: w, tableWidth: Math.round(t.getBoundingClientRect().width || 0) }));
  }
  function reset(t) {
    if (!t) return;
    rs(sk(t));
    clearOld(t);
    var h = ths(t), w = fitToContainer(t, h, defs(t, h));
    apply(t, h, w, false);
    t.classList.remove('data-table--columnas-personalizadas');
  }
  function adapt(t, heads) {
    var w = fitToContainer(t, heads, logicalWidths(t, heads));
    apply(t, heads, w, false);
  }
  function handles(t, heads) {
    heads.forEach(function (h) {
      var k = key(h);
      if (!k || h.dataset.colFixed === '1') return;
      h.classList.add('col-resize-host');
      var x = document.createElement('span');
      x.className = 'col-resize-handle';
      x.dataset.colTarget = k;
      x.setAttribute('role', 'separator');
      x.setAttribute('aria-label', 'Cambiar ancho de ' + k);
      h.appendChild(x);
      x.addEventListener('pointerdown', function (ev) {
        if (ev.button !== 0) return;
        ev.preventDefault();
        ev.stopPropagation();
        var target = x.dataset.colTarget, base = logicalWidths(t, heads), sx = ev.clientX;
        try { x.setPointerCapture(ev.pointerId); } catch (_) {}
        document.documentElement.classList.add('col-resize-activo');
        function mv(e) { apply(t, heads, rebalanceRight(t, heads, base, target, e.clientX - sx), false); }
        function end() {
          try { x.releasePointerCapture(ev.pointerId); } catch (_) {}
          x.removeEventListener('pointermove', mv);
          x.removeEventListener('pointerup', end);
          x.removeEventListener('pointercancel', end);
          document.documentElement.classList.remove('col-resize-activo');
          t.classList.add('data-table--columnas-personalizadas');
          save(t, logicalWidths(t, heads));
        }
        x.addEventListener('pointermove', mv);
        x.addEventListener('pointerup', end);
        x.addEventListener('pointercancel', end);
      });
    });
  }
  function init(t) {
    if (!t || t.dataset.columnResizeReady === '1') return;
    var heads = ths(t);
    if (heads.length < 2) return;
    t.dataset.columnResizeReady = '1';
    clearOld(t);
    ensure(t, heads);
    apply(t, heads, fitToContainer(t, heads, load(t, heads) || defs(t, heads)), false);
    requestAnimationFrame(function () { adapt(t, heads); });
    handles(t, heads);
    if (window.ResizeObserver) {
      var box = t.closest('.panel--listado__scroll') || t.parentElement;
      if (box) new ResizeObserver(function () { adapt(t, heads); }).observe(box);
    } else {
      window.addEventListener('resize', function () { adapt(t, heads); });
    }
    if (window.MutationObserver) {
      new MutationObserver(function (ms) {
        if (ms.some(function (m) { return m.attributeName === 'class'; })) adapt(t, heads);
      }).observe(t, { attributes:true, attributeFilter:['class'] });
    }
  }
  document.querySelectorAll('table.data-table--resizable[data-column-storage-key]').forEach(init);
  document.querySelectorAll('[data-reset-columns-for]').forEach(function (b) {
    b.addEventListener('click', function () { reset(document.getElementById(b.getAttribute('data-reset-columns-for'))); });
  });
})();
