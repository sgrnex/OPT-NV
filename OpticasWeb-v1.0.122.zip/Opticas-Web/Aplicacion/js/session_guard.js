/* Cierra la sesión al cerrar la última ventana de Cloud Opticas.
 * Las ventanas abiertas comparten una pequeña lista en localStorage para que
 * cerrar una de ellas no eche al usuario de las demás. Los enlaces y
 * formularios internos se marcan como navegación y no disparan el cierre.
 */
(function () {
  'use strict';

  var STORAGE_KEY = 'cloud-opticas:ventanas-activas';
  var VIGENCIA_MS = 180000;
  var id = (window.crypto && typeof window.crypto.randomUUID === 'function')
    ? window.crypto.randomUUID()
    : String(Date.now()) + '-' + Math.random().toString(36).slice(2);
  var navegando = false;
  var cerrado = false;

  function leer() {
    try {
      var valor = JSON.parse(localStorage.getItem(STORAGE_KEY) || '{}');
      return valor && typeof valor === 'object' ? valor : {};
    } catch (e) {
      return {};
    }
  }

  function guardar(ventanas) {
    try { localStorage.setItem(STORAGE_KEY, JSON.stringify(ventanas)); } catch (e) {}
  }

  function registrar() {
    var ventanas = leer();
    ventanas[id] = Date.now();
    guardar(ventanas);
  }

  function quitar() {
    var ventanas = leer();
    delete ventanas[id];
    var ahora = Date.now();
    Object.keys(ventanas).forEach(function (clave) {
      if (ahora - Number(ventanas[clave]) > VIGENCIA_MS) delete ventanas[clave];
    });
    guardar(ventanas);
    return Object.keys(ventanas).length === 0;
  }

  function cerrarSesionSiEsLaUltima() {
    if (cerrado || navegando) return;
    cerrado = true;
    if (!quitar()) return;
    try {
      var datos = new Blob(['auto=1'], { type: 'application/x-www-form-urlencoded;charset=UTF-8' });
      if (navigator.sendBeacon) {
        navigator.sendBeacon('logout.php?auto=1', datos);
      } else {
        fetch('logout.php?auto=1', {
          method: 'POST',
          body: datos,
          credentials: 'same-origin',
          keepalive: true
        }).catch(function () {});
      }
    } catch (e) {}
  }

  function marcarNavegacion() { navegando = true; }

  registrar();
  window.setInterval(registrar, 60000);

  document.addEventListener('click', function (evento) {
    var enlace = evento.target.closest ? evento.target.closest('a') : null;
    if (!enlace || enlace.target === '_blank' || enlace.hasAttribute('download')) return;
    var href = enlace.getAttribute('href') || '';
    if (!href || href.charAt(0) === '#' || /^javascript:|^mailto:|^tel:/i.test(href)) return;
    if (/logout\.php(?:[?#]|$)/i.test(href)) {
      quitar();
      marcarNavegacion();
      return;
    }
    try {
      var destino = new URL(href, window.location.href);
      if (destino.origin === window.location.origin) marcarNavegacion();
    } catch (e) {}
  }, true);
  document.addEventListener('submit', marcarNavegacion, true);
  window.addEventListener('pagehide', function (evento) {
    if (!evento.persisted) cerrarSesionSiEsLaUltima();
  });
})();
