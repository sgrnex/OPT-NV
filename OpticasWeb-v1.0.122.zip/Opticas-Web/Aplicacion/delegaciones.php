<?php
require __DIR__ . '/includes/auth.php';
requireAdmin();
require __DIR__ . '/db.php';

$pdo = obtenerConexion();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['nombre_nueva'])) {
        $n = trim($_POST['nombre_nueva']);
        if ($n !== '') {
            $pdo->prepare('INSERT INTO delegaciones (nombre) VALUES (:n)')->execute(['n' => $n]);
        }
    } elseif (isset($_POST['editar_id'])) {
        $pdo->prepare('UPDATE delegaciones SET nombre=:n, direccion=:d, telefono=:t, email=:e WHERE id=:id')->execute([
            'n' => trim($_POST['nombre'] ?? ''),
            'd' => trim($_POST['direccion'] ?? ''),
            't' => trim($_POST['telefono'] ?? ''),
            'e' => trim($_POST['email'] ?? ''),
            'id' => (int) $_POST['editar_id'],
        ]);
    } elseif (isset($_POST['borrar_id'])) {
        $id = (int) $_POST['borrar_id'];
        $pdo->prepare('UPDATE clientes SET delegacion_id = NULL WHERE delegacion_id = :id')->execute(['id' => $id]);
        $pdo->prepare('DELETE FROM delegaciones WHERE id = :id')->execute(['id' => $id]);
    }
    header('Location: delegaciones.php');
    exit;
}

$delegaciones = $pdo->query(
    'SELECT d.*, (SELECT COUNT(*) FROM clientes c WHERE c.delegacion_id = d.id) AS total_clientes
     FROM delegaciones d ORDER BY d.nombre COLLATE utf8mb4_general_ci'
)->fetchAll();

$titulo = 'Delegaciones';
$activo = 'delegaciones';
require __DIR__ . '/includes/header.php';
?>
<section class="panel panel--estrecha">
  <div class="panel__title-bar"><span class="panel__title-pill">Delegaciones</span></div>

  <p class="panel__footer">Cada cliente se etiqueta con su delegación (tienda). El listado de Clientes los muestra siempre todos.</p>

  <form method="post" class="alta-simple">
    <input class="alta-simple__input" type="text" name="nombre_nueva" placeholder="Nombre de la nueva delegación..." required>
    <button class="btn btn--primary" type="submit">➕ Añadir</button>
  </form>

  <?php foreach ($delegaciones as $d): ?>
    <form method="post" class="deleg-card">
      <input type="hidden" name="editar_id" value="<?= (int) $d['id'] ?>">
      <div class="deleg-card__cab">
        <strong><?= htmlspecialchars($d['nombre']) ?></strong>
        <span class="listados-nota"><?= (int) $d['total_clientes'] ?> clientes</span>
        <span class="record-form__actions-spacer"></span>
        <button type="submit" class="btn btn--secondary">💾 Guardar</button>
        <button type="submit" formnovalidate onclick="this.form.querySelector('[name=editar_id]').name='borrar_id'; return confirm('¿Eliminar la delegación <?= htmlspecialchars(addslashes($d['nombre'])) ?>? Sus clientes quedarán sin delegación.');" class="btn btn--danger">❌ Borrar</button>
      </div>
      <div class="record-form__grid">
        <div class="record-form__row"><label>Nombre</label><input type="text" name="nombre" value="<?= htmlspecialchars($d['nombre']) ?>"></div>
        <div class="record-form__row"><label>Teléfono</label><input type="text" name="telefono" value="<?= htmlspecialchars($d['telefono'] ?? '') ?>"></div>
      </div>
      <div class="record-form__row"><label>Dirección</label><input type="text" name="direccion" value="<?= htmlspecialchars($d['direccion'] ?? '') ?>"></div>
      <div class="record-form__row"><label>Email</label><input type="text" name="email" value="<?= htmlspecialchars($d['email'] ?? '') ?>"></div>
    </form>
  <?php endforeach; ?>

  <div class="record-form__actions">
    <a class="btn btn--secondary" href="index.php">↩️ Volver</a>
  </div>
</section>
<?php require __DIR__ . '/includes/footer.php'; ?>
