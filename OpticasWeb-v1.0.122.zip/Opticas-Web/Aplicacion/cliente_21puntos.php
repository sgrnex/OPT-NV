<?php
require __DIR__ . '/includes/auth.php';
requireLogin();
require __DIR__ . '/db.php';

$pdo = obtenerConexion();
$id = isset($_GET['id']) ? (int) $_GET['id'] : (isset($_POST['id']) ? (int) $_POST['id'] : 0);

$stmt = $pdo->prepare('SELECT * FROM clientes WHERE id = :id');
$stmt->execute(['id' => $id]);
$cliente = $stmt->fetch();
if (!$cliente) {
    header('Location: index.php');
    exit;
}

$subPestanas = [
    'historia'       => 'Historia',
    'biomicroscopia' => 'Biomicroscopía',
    'oftalmoscopia'  => 'Oftalmoscopía',
    'resto'          => 'Resto',
    'diagnostico'    => 'Diagnóstico',
];
$sub = $_GET['sub'] ?? $_POST['sub'] ?? 'historia';
if (!isset($subPestanas[$sub])) {
    $sub = 'historia';
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $sub = isset($subPestanas[$_POST['sub'] ?? '']) ? $_POST['sub'] : 'historia';
    $pdo->prepare("UPDATE clientes SET {$sub}_21p = :texto, fecha_21p = :fecha WHERE id = :id")->execute([
        'texto' => trim($_POST['texto'] ?? ''),
        'fecha' => ($_POST['fecha_21p'] ?? '') !== '' ? $_POST['fecha_21p'] : null,
        'id'    => $id,
    ]);
    header("Location: cliente_21puntos.php?id=$id&sub=$sub&guardado=1");
    exit;
}

$esExistente = true;
$titulo = '21 Puntos';
$activo = 'clientes';
$tabActiva = '21puntos';
require __DIR__ . '/includes/header.php';
?>
<section class="panel">
  <div class="panel__title-bar"><span class="panel__title-pill">Ficha cliente</span><span class="panel__title-cliente"><?= htmlspecialchars(trim(($cliente['nombre'] ?? '') . ' ' . ($cliente['apellidos'] ?? ''))) ?></span></div>

  <?php require __DIR__ . '/includes/ficha_cliente_tabs.php'; ?>

  <?php $formGuardarId = 'form-21puntos'; require __DIR__ . '/includes/ficha_acciones.php'; ?>

  <div class="ficha-tabs ficha-tabs--sub">
    <?php foreach ($subPestanas as $clave => $nombre): ?>
      <a href="cliente_21puntos.php?id=<?= $id ?>&sub=<?= $clave ?>"
         class="ficha-tabs__tab <?= $sub === $clave ? 'ficha-tabs__tab--active' : '' ?>"><?= $nombre ?></a>
    <?php endforeach; ?>
  </div>

  <?php if (!empty($_GET['guardado'])): ?>
    <p class="form-ok">Guardado correctamente.</p>
  <?php endif; ?>

  <form method="post" id="form-21puntos" class="record-form">
    <input type="hidden" name="id" value="<?= $id ?>">
    <input type="hidden" name="sub" value="<?= $sub ?>">

    <div class="record-form__row" style="max-width:220px;">
      <label for="fecha_21p">Fecha</label>
      <input type="date" id="fecha_21p" name="fecha_21p" value="<?= htmlspecialchars($cliente['fecha_21p'] ?? '') ?>">
    </div>

    <div class="record-form__row">
      <textarea name="texto" rows="16"><?= htmlspecialchars($cliente[$sub . '_21p'] ?? '') ?></textarea>
    </div>

  </form>
</section>
<?php require __DIR__ . '/includes/footer.php'; ?>
