<?php
require __DIR__ . '/includes/auth.php';
requireLogin();
require __DIR__ . '/db.php';

$pdo = obtenerConexion();
$delegaciones = $pdo->query('SELECT * FROM delegaciones ORDER BY nombre COLLATE utf8mb4_general_ci')->fetchAll();

$titulo = 'Listados Clientes';
$activo = 'clientes';
require __DIR__ . '/includes/header.php';
?>
<section class="panel panel--centrada">
  <div class="panel__title-bar"><span class="panel__title-pill">Listados Clientes</span></div>

  <form method="get" action="clientes_listado_generar.php" target="_blank" class="listados-form">
    <input type="hidden" name="columnas_definidas" value="1">

    <!-- 1) TIPO DE LISTADO (define el contenido del informe) -->
    <div class="listados-tipos">
      <span class="listados-seccion-titulo">Tipo de listado:</span>
      <div class="listados-op">
        <label><input type="radio" name="tipo" value="general" checked> Listado General</label>
      </div>

    <div class="listados-op">
      <label><input type="radio" name="tipo" value="graduaciones"> Listado por Graduaciones</label>
      <div class="listados-sub">
        Fecha graduación desde: <input type="date" name="grad_desde">
        A: <input type="date" name="grad_hasta">
        <label class="listados-check"><input type="checkbox" name="grad_detalle" value="1"> Incluir el detalle de graduaciones de cada cliente</label>
      </div>
    </div>

    <div class="listados-op">
      <label><input type="radio" name="tipo" value="lentillas"> Listado de Clientes con Lentillas</label>
      <div class="listados-sub">
        <label class="listados-check"><input type="checkbox" name="lent_detalle" value="1"> Incluir el detalle de lentillas de cada cliente</label>
      </div>
    </div>

    <div class="listados-op">
      <label><input type="radio" name="tipo" value="audifonos"> Listado de Clientes con Audífonos</label>
      <div class="listados-sub">
        <label class="listados-check"><input type="checkbox" name="audi_detalle" value="1"> Incluir el detalle de audiometrías/audífonos de cada cliente</label>
      </div>
    </div>

    <div class="listados-op listados-op--disabled">
      <label><input type="radio" name="tipo" value="deudores" disabled> Listado de Deudores <span class="listados-nota">(disponible cuando exista Ventas)</span></label>
    </div>
    <div class="listados-op listados-op--disabled">
      <label><input type="radio" name="tipo" value="preferenciales" disabled> Listado Preferenciales <span class="listados-nota">(disponible cuando exista Ventas)</span></label>
    </div>
    <div class="listados-op listados-op--disabled">
      <label><input type="radio" name="tipo" value="doctor" disabled> Listado por Doctor <span class="listados-nota">(disponible cuando exista Ficheros → Doctores)</span></label>
    </div>
    <div class="listados-op listados-op--disabled">
      <label><input type="radio" name="tipo" value="vendedor" disabled> Listado por Vendedor <span class="listados-nota">(disponible cuando exista Ficheros → Vendedores)</span></label>
    </div>
    </div>

    <!-- 2) FILTRO COMÚN: a qué clientes aplicar el listado -->
    <details class="listados-filtro-comun">
      <summary>▸ Filtrar qué clientes incluir (opcional)</summary>
      <div class="listados-filtros__grid">
        <label>Nombre/Apellidos <input type="text" name="f_nombre"></label>
        <label>NIF <input type="text" name="f_nif"></label>
        <label>Teléfono <input type="text" name="f_telefono"></label>
        <label>Población <input type="text" name="f_poblacion"></label>
        <label>Provincia <input type="text" name="f_provincia"></label>
        <label>Email <input type="text" name="f_email"></label>
        <label>Edad desde <input type="number" name="f_edad_desde" min="0" max="120" class="listados-num"></label>
        <label>Edad hasta <input type="number" name="f_edad_hasta" min="0" max="120" class="listados-num"></label>
        <label>Alta desde <input type="date" name="f_alta_desde"></label>
        <label>Alta hasta <input type="date" name="f_alta_hasta"></label>
        <label>Nacim. desde <input type="date" name="f_nac_desde"></label>
        <label>Nacim. hasta <input type="date" name="f_nac_hasta"></label>
        <label>Delegación
          <select name="f_delegacion">
            <option value="">— Todas —</option>
            <?php foreach ($delegaciones as $d): ?>
              <option value="<?= (int) $d['id'] ?>"><?= htmlspecialchars($d['nombre']) ?></option>
            <?php endforeach; ?>
          </select>
        </label>
        <label>Estado
          <select name="f_estado">
            <option value="">Todos</option>
            <option value="1">Solo activos</option>
            <option value="0">Solo inactivos</option>
          </select>
        </label>
        <label>Acepta Mailing/SMS
          <select name="f_mailing">
            <option value="">Indiferente</option>
            <option value="1">Sí</option>
            <option value="0">No</option>
          </select>
        </label>
        <label>Revisión pendiente
          <select name="f_revision">
            <option value="">Indiferente</option>
            <option value="1">Sí (hoy o futura)</option>
            <option value="0">No / sin fecha</option>
          </select>
        </label>
      </div>
    </details>

    <!-- 3) FORMATO DE SALIDA -->
    <div class="listados-formatos">
      <span class="listados-formatos__titulo">Formato de salida:</span>
      <div class="listados-formatos__linea">
        <label><input type="radio" name="formato" value="pantalla" checked> Ver en pantalla</label>
        <label><input type="radio" name="formato" value="imprimir"> 🖨️ Imprimir</label>
        <label><input type="radio" name="formato" value="pdf"> PDF</label>
        <label><input type="radio" name="formato" value="excel"> Excel</label>
        <label><input type="radio" name="formato" value="csv"> CSV</label>
        <label><input type="radio" name="formato" value="rtf"> RTF</label>
        <label><input type="radio" name="formato" value="xml"> XML</label>
        <label><input type="radio" name="formato" value="html"> HTML</label>
      </div>
    </div>

    <div class="listados-opciones">
      <span class="listados-seccion-titulo">Opciones de salida (para Ver en pantalla, Imprimir y PDF):</span>
      <div class="listados-opciones__linea">
        <label>Orientación:
          <select name="orientacion">
            <option value="vertical">Vertical</option>
            <option value="horizontal">Horizontal</option>
          </select>
        </label>
        <label>Tamaño de letra:
          <select name="tam_letra">
            <option value="muy_pequeno">Muy pequeño</option>
            <option value="pequeno">Pequeño</option>
            <option value="normal" selected>Normal</option>
            <option value="grande">Grande</option>
            <option value="muy_grande">Muy grande</option>
          </select>
        </label>
        <label>Fuente:
          <select name="fuente">
            <option value="arial" selected>Arial / Helvetica</option>
            <option value="times">Times</option>
            <option value="courier">Courier</option>
          </select>
        </label>
      </div>
      <div class="listados-opciones__cols-titulo">Columnas a incluir:</div>
      <div class="listados-opciones__linea listados-opciones__linea--cols">
        <label><input type="checkbox" id="col-todas" checked onclick="alternarColumnas(this)"> <strong>Todas</strong></label>
        <label><input type="checkbox" id="col-ninguna" onclick="alternarNinguna(this)"> <strong>Ninguna</strong></label>
        <label><input type="checkbox" name="col[]" value="nif" class="col-check-item" checked> NIF</label>
        <label><input type="checkbox" name="col[]" value="telefono" class="col-check-item" checked> Teléfono</label>
        <label><input type="checkbox" name="col[]" value="poblacion" class="col-check-item" checked> Población</label>
        <label><input type="checkbox" name="col[]" value="provincia" class="col-check-item" checked> Provincia</label>
        <label><input type="checkbox" name="col[]" value="email" class="col-check-item" checked> Email</label>
        <label><input type="checkbox" name="col[]" value="delegacion" class="col-check-item" checked> Delegación</label>
      </div>
    </div>

    <div class="record-form__actions">
      <a class="btn btn--secondary" href="index.php">↩️ Volver</a>
      <button class="btn btn--primary" type="submit">📄 Generar listado</button>
    </div>
  </form>
</section>
<script>
function alternarColumnas(origen) {
  document.querySelectorAll('.col-check-item').forEach(function (c) { c.checked = origen.checked; });
  document.getElementById('col-ninguna').checked = !origen.checked;
}
function alternarNinguna(origen) {
  document.querySelectorAll('.col-check-item').forEach(function (c) { c.checked = !origen.checked; });
  document.getElementById('col-todas').checked = !origen.checked;
}
document.querySelectorAll('.col-check-item').forEach(function (c) {
  c.addEventListener('change', function () {
    var todas = document.querySelectorAll('.col-check-item');
    var marcadas = document.querySelectorAll('.col-check-item:checked');
    document.getElementById('col-todas').checked = (todas.length === marcadas.length);
    document.getElementById('col-ninguna').checked = (marcadas.length === 0);
  });
});
</script>
<?php require __DIR__ . '/includes/footer.php'; ?>
