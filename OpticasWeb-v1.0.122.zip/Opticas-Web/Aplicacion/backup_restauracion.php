<?php
require __DIR__ . '/includes/auth.php';
requireAdmin();
require __DIR__ . '/db.php';
$config = require __DIR__ . '/config.php';
$pdo = obtenerConexion();
$backupDir = __DIR__ . DIRECTORY_SEPARATOR . 'Backups_Local';
if (!is_dir($backupDir)) @mkdir($backupDir, 0775, true);
function backupTimestamp(): string { return date('Y-m-d_H-i-s'); }
function mysqlBinary(string $name): string {
    $c = ['C:\\xampp\\mysql\\bin\\'.$name.'.exe', __DIR__.DIRECTORY_SEPARATOR.$name.'.exe', '/usr/bin/'.$name, '/usr/local/bin/'.$name];
    foreach ($c as $p) if (is_file($p)) return $p; return $name;
}
function runDbCommand(string $binary, array $args, ?string $input = null): array {
    $cmd = escapeshellarg($binary); foreach ($args as $arg) $cmd .= ' '.escapeshellarg((string)$arg);
    $spec=[0=>['pipe','r'],1=>['pipe','w'],2=>['pipe','w']]; $p=proc_open($cmd,$spec,$pipes,__DIR__);
    if (!is_resource($p)) return [1,'','No se pudo iniciar el proceso de base de datos.'];
    if ($input !== null) fwrite($pipes[0],$input); fclose($pipes[0]);
    $out=stream_get_contents($pipes[1]); fclose($pipes[1]); $err=stream_get_contents($pipes[2]); fclose($pipes[2]);
    return [proc_close($p),$out,$err];
}
function crearBackup(array $config,string $destino): array {
    $args=['--protocol=tcp','-h',$config['host'],'-u',$config['user'],'--default-character-set=utf8mb4','--single-transaction','--routines','--triggers',$config['dbname']];
    if ($config['password']!=='') $args[]='-p'.$config['password']; [$code,$out,$err]=runDbCommand(mysqlBinary('mysqldump'),$args);
    if ($code!==0 || trim($out)==='') return [false,$err ?: 'mysqldump no devolvió datos.'];
    if (@file_put_contents($destino,$out,LOCK_EX)===false) return [false,'No se pudo guardar el archivo de backup.']; return [true,''];
}
function backupValido(string $archivo): bool {
    if (!is_file($archivo)||filesize($archivo)<100) return false; $h=fopen($archivo,'rb'); $s=$h?fread($h,1048576):''; if($h)fclose($h);
    return stripos($s,'CREATE TABLE')!==false && (stripos($s,'INSERT INTO')!==false || stripos($s,'LOCK TABLES')!==false);
}
function backupFormato(string $archivo): string {
    $h=fopen($archivo,'rb'); $s=$h?fread($h,4*1024*1024):''; if($h)fclose($h);
    if (stripos($s,'CREATE TABLE IF NOT EXISTS `vendedores`')!==false || stripos($s,'CREATE TABLE IF NOT EXISTS `opticos`')!==false) return 'original';
    if (stripos($s,'CREATE TABLE')!==false) return 'opticasweb';
    return 'desconocido';
}
function restaurarArchivo(array $config, string $archivo): array {
    $args=['--protocol=tcp','-h',$config['host'],'-u',$config['user'],'--default-character-set=utf8mb4',$config['dbname']];
    if($config['password']!=='') $args[]='-p'.$config['password'];
    return runDbCommand(mysqlBinary('mysql'),$args,file_get_contents($archivo));
}
/** Combina INSERT del volcado de una base compatible sin borrar la actual. */
function combinarArchivo(PDO $pdo, string $archivo): array {
    $sql = file_get_contents($archivo);
    if ($sql === false) return [false, 'No se pudo leer el archivo SQL.'];
    $permitidas = ['clientes','articulos','usuarios','proveedores','marcas','delegaciones','articulos_stock','articulos_compras','encargos','ventas','compras'];
    $pat = '/INSERT\\s+INTO\\s+`?([a-zA-Z0-9_]+)`?\\s*\\(([^)]*)\\)\\s*VALUES\\s*(.*?);/is';
    if (!preg_match_all($pat, $sql, $ms, PREG_SET_ORDER)) return [false, 'No se encontraron registros INSERT compatibles.'];
    $pdo->beginTransaction(); $n = 0;
    try {
        foreach ($ms as $m) {
            $tabla = strtolower($m[1]);
            if (!in_array($tabla, $permitidas, true)) continue;
            $columnas = array_values(array_filter(array_map(function($c){ return trim($c, " `\\t\\r\\n"); }, explode(',', $m[2]))));
            if (!$columnas) continue;
            $asignaciones = [];
            foreach ($columnas as $c) {
                if (strtolower($c) === 'id') continue;
                $q = '`'.str_replace('`','',$c).'`'; $asignaciones[] = "$q=VALUES($q)";
            }
            if (!$asignaciones) continue;
            $cols = implode('`,`', array_map(fn($c)=>str_replace('`','',$c),$columnas));
            $stmt = 'INSERT INTO `'.$tabla.'` (`'.$cols.'`) VALUES '.$m[3].' ON DUPLICATE KEY UPDATE '.implode(',', $asignaciones);
            $n += $pdo->exec($stmt);
        }
        $pdo->commit(); return [true, (string)$n];
    } catch (Throwable $e) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        return [false, $e->getMessage()];
    }
}
$mensaje=''; $tipo='ok';
if ($_SERVER['REQUEST_METHOD']==='POST' && ($_POST['accion']??'')==='crear') {
    $nombre='Backup_GestionOptica_'.backupTimestamp().'.sql'; [$ok,$error]=crearBackup($config,$backupDir.DIRECTORY_SEPARATOR.$nombre);
    $mensaje=$ok?'Backup creado correctamente: '.$nombre:'No se pudo crear el backup: '.$error; $tipo=$ok?'ok':'error';
}
if ($_SERVER['REQUEST_METHOD']==='POST' && ($_POST['accion']??'')==='restaurar') {
    $tmp=$_FILES['backup']['tmp_name']??'';
    if (!is_uploaded_file($tmp)||($_FILES['backup']['error']??UPLOAD_ERR_NO_FILE)!==UPLOAD_ERR_OK) {$mensaje='Selecciona un archivo SQL válido.';$tipo='error';}
    elseif (!backupValido($tmp)) {$mensaje='El archivo no parece un volcado completo. No se ha restaurado nada.';$tipo='error';}
    else {
        $previo=$backupDir.DIRECTORY_SEPARATOR.'Backup_Antes_Restauracion_'.backupTimestamp().'.sql'; [$okPrev,$errPrev]=crearBackup($config,$previo);
        if(!$okPrev){$mensaje='Restauración cancelada: no se pudo crear la copia automática previa. '.$errPrev;$tipo='error';}
        else {
            $destino=$backupDir.DIRECTORY_SEPARATOR.'Backup_Importado_'.backupTimestamp().'.sql'; move_uploaded_file($tmp,$destino);
            [$code,,$err]=restaurarArchivo($config,$destino); $faltan=[]; foreach(['clientes','articulos','usuarios'] as $t) if(!tablaExiste($pdo,$t))$faltan[]=$t;
            if($code!==0||$faltan){
                // Si la importación falla o deja una estructura incompleta,
                // se revierte automáticamente a la copia previa.
                [$rollbackCode,, $rollbackErr]=restaurarArchivo($config,$previo);
                $mensaje='Restauración incompleta: se ha restaurado automáticamente el estado anterior. Copia previa: '.basename($previo).($rollbackCode!==0?' Error adicional al revertir: '.$rollbackErr:''); $tipo='error';
            } else $mensaje='Restauración completada y validada. Copia previa: '.basename($previo);
        }
    }
}
if ($_SERVER['REQUEST_METHOD']==='POST' && ($_POST['accion']??'')==='combinar') {
    $tmp=$_FILES['base_actualizada']['tmp_name']??'';
    if (!is_uploaded_file($tmp)||($_FILES['base_actualizada']['error']??UPLOAD_ERR_NO_FILE)!==UPLOAD_ERR_OK) {$mensaje='Selecciona un archivo SQL válido.';$tipo='error';}
    elseif (!backupValido($tmp)) {$mensaje='El archivo no parece un volcado completo compatible.';$tipo='error';}
    elseif (backupFormato($tmp)==='original') {$mensaje='El backup pertenece al programa original. La migración incremental para ese formato debe ejecutarse mediante el importador específico; no se ha modificado la base actual.';$tipo='error';}
    else {
        $previo=$backupDir.DIRECTORY_SEPARATOR.'Backup_Antes_Combinacion_'.backupTimestamp().'.sql'; [$okPrev,$errPrev]=crearBackup($config,$previo);
        if(!$okPrev){$mensaje='Combinación cancelada: no se pudo crear la copia automática previa. '.$errPrev;$tipo='error';}
        else {
            $destino=$backupDir.DIRECTORY_SEPARATOR.'Backup_Combinacion_'.backupTimestamp().'.sql'; move_uploaded_file($tmp,$destino);
            [$ok,$detalle]=combinarArchivo($pdo,$destino);
            $mensaje=$ok?'Combinación completada. Registros procesados: '.$detalle.'. Copia previa: '.basename($previo):'Combinación cancelada: '.$detalle.'. La base actual no se ha modificado.';
            $tipo=$ok?'ok':'error';
        }
    }
}
$archivos=glob($backupDir.DIRECTORY_SEPARATOR.'*.sql')?:[]; usort($archivos,fn($a,$b)=>filemtime($b)<=>filemtime($a));
$titulo='Backup y Restauración (Local)'; $activo='backup_restauracion'; require __DIR__.'/includes/header.php';
?>
<section class="panel backup-panel"><div class="panel__title-bar"><span class="panel__title-pill">Backup y Restauración (Local)</span></div>
<?php if($mensaje): ?><p class="form-<?= $tipo==='ok'?'ok':'error' ?>"><?= htmlspecialchars($mensaje) ?></p><?php endif; ?>
<div class="backup-form-grid">
  <div class="backup-form-grid__bloque">
    <h3>Crear backup SQL</h3>
    <p>Genera una copia completa con fecha y hora en <code>Backups_Local</code>.</p>
    <form method="post" class="backup-operacion-form" data-mensaje-progreso="Volcando base de datos">
      <input type="hidden" name="accion" value="crear">
      <div class="backup-operacion">
        <button type="submit" class="btn btn--primary">Crear Backup ahora</button>
        <div class="backup-progreso" role="status" aria-live="polite"><span>Volcando base de datos</span></div>
      </div>
    </form>
  </div>
  <div class="backup-form-grid__bloque">
    <h3>Restaurar backup</h3>
    <p>Se crea automáticamente una copia del estado actual antes de restaurar.</p>
    <form method="post" enctype="multipart/form-data" class="backup-operacion-form" data-mensaje-progreso="Restaurando Base de Datos" onsubmit="return confirmarRestauracion(this);">
      <input type="hidden" name="accion" value="restaurar">
      <div class="backup-operacion">
        <button type="submit" class="btn btn--danger">Restaurar Backup</button>
        <div class="backup-progreso" role="status" aria-live="polite"><span>Restaurando Base de Datos</span></div>
      </div>
      <input class="backup-fichero" type="file" name="backup" accept=".sql,text/plain" required>
    </form>
  </div>
</div>
<div class="backup-combinacion">
  <h3>Actualizar base de datos existente</h3>
  <p>Combina una base compatible del programa original: añade registros nuevos y actualiza los existentes sin borrar la información actual.</p>
  <form method="post" enctype="multipart/form-data" class="backup-operacion-form" data-mensaje-progreso="Actualizando base de datos" onsubmit="return confirmarCombinacion(this);">
    <input type="hidden" name="accion" value="combinar">
    <div class="backup-operacion">
      <button type="submit" class="btn btn--primary">Analizar y actualizar</button>
      <div class="backup-progreso" role="status" aria-live="polite"><span>Actualizando base de datos</span></div>
    </div>
    <input class="backup-fichero" type="file" name="base_actualizada" accept=".sql,text/plain" required>
  </form>
</div>
<div class="backup-listado">
  <h3>Backups disponibles</h3>
  <ul><?php foreach($archivos as $a): ?><li><?= htmlspecialchars(basename($a)) ?> — <?= number_format(filesize($a)/1024,1,',','.') ?> KB — <?= date('d/m/Y H:i',filemtime($a)) ?></li><?php endforeach; if(!$archivos): ?><li>No hay backups todavía.</li><?php endif; ?></ul>
</div>
</section>
<script>
function confirmarRestauracion(form) {
  if (!confirm('ATENCIÓN: se sustituirán los datos actuales. ¿Continuar?')) return false;
  mostrarProgresoBackup(form);
  return true;
}
function confirmarCombinacion(form) {
  if (!confirm('Se conservará una copia automática y se combinarán los registros nuevos y modificados. ¿Continuar?')) return false;
  mostrarProgresoBackup(form);
  return true;
}
function mostrarProgresoBackup(form) {
  var boton = form.querySelector('button[type="submit"]');
  var barra = form.querySelector('.backup-progreso');
  if (boton) { boton.disabled = true; boton.setAttribute('aria-disabled', 'true'); }
  if (barra) barra.classList.add('backup-progreso--visible');
}
document.querySelectorAll('.backup-operacion-form[data-mensaje-progreso]').forEach(function (form) {
  if (form.getAttribute('data-mensaje-progreso') === 'Volcando base de datos' || form.getAttribute('data-mensaje-progreso') === 'Actualizando base de datos') {
    form.addEventListener('submit', function () { mostrarProgresoBackup(form); });
  }
});
</script>
<?php require __DIR__.'/includes/footer.php'; ?>
