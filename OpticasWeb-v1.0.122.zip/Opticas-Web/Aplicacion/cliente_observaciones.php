<?php
require __DIR__ . '/includes/auth.php';
requireLogin();
require __DIR__ . '/db.php';

$pdo = obtenerConexion();
$id = isset($_GET['id']) ? (int) $_GET['id'] : (isset($_POST['id']) ? (int) $_POST['id'] : 0);

$stmt = $pdo->prepare('SELECT * FROM clientes WHERE id = :id');
$stmt->execute(['id' => $id]);
$cliente = $stmt->fetch();
if (!$cliente) {
    header('Location: index.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $pdo->prepare('UPDATE clientes SET notas = :notas WHERE id = :id')
        ->execute(['notas' => trim($_POST['notas'] ?? ''), 'id' => $id]);
    header('Location: cliente_observaciones.php?id=' . $id . '&guardado=1');
    exit;
}

$esExistente = true;
$titulo = 'Observaciones';
$activo = 'clientes';
$tabActiva = 'observaciones';
require __DIR__ . '/includes/header.php';
?>
<section class="panel">
  <div class="panel__title-bar"><span class="panel__title-pill">Ficha cliente</span><span class="panel__title-cliente"><?= htmlspecialchars(trim(($cliente['nombre'] ?? '') . ' ' . ($cliente['apellidos'] ?? ''))) ?></span></div>

  <?php require __DIR__ . '/includes/ficha_cliente_tabs.php'; ?>

  <?php $formGuardarId = 'form-observaciones'; require __DIR__ . '/includes/ficha_acciones.php'; ?>

  <?php if (!empty($_GET['guardado'])): ?>
    <p class="form-ok">Guardado correctamente.</p>
  <?php endif; ?>

  <form method="post" id="form-observaciones" class="record-form">
    <input type="hidden" name="id" value="<?= (int) $cliente['id'] ?>">
    <div class="record-form__row">
      <textarea name="notas" rows="14"><?= htmlspecialchars($cliente['notas'] ?? '') ?></textarea>
    </div>
  </form>
</section>
<?php require __DIR__ . '/includes/footer.php'; ?>
