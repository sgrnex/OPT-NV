<?php
require __DIR__ . '/includes/auth.php';
requireLogin();
require __DIR__ . '/db.php';

header('Content-Type: application/json; charset=utf-8');

$pdo = obtenerConexion();
$texto = trim($_GET['q'] ?? '');

if ($texto === '') {
    echo json_encode(['candidatos' => []]);
    exit;
}

// Búsqueda por parecido: primero el texto completo, luego por palabras.
$palabras = preg_split('/\s+/', $texto);
$condiciones = ['a.nombre LIKE :completo'];
$params = ['completo' => '%' . $texto . '%'];
foreach ($palabras as $i => $palabra) {
    if (mb_strlen($palabra) >= 3) {
        $condiciones[] = "a.nombre LIKE :p$i";
        $params["p$i"] = '%' . $palabra . '%';
    }
}

$sql = "SELECT a.id, a.codigo, a.referencia, a.nombre, a.pvp, m.nombre AS marca
        FROM articulos a LEFT JOIN marcas m ON m.id = a.marca_id
        WHERE " . implode(' OR ', $condiciones) . "
        ORDER BY (a.nombre = :exacto) DESC, a.nombre
        LIMIT 30";
$params['exacto'] = $texto;

$stmt = $pdo->prepare($sql);
$stmt->execute($params);

echo json_encode(['candidatos' => $stmt->fetchAll(PDO::FETCH_ASSOC)]);
