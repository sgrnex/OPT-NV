<?php
require __DIR__ . '/includes/auth.php';
requireLogin();
require __DIR__ . '/db.php';

$pdo = obtenerConexion();

$camposFiltro = ['id', 'nombre', 'apellidos', 'nif', 'telefono', 'poblacion', 'provincia', 'email'];
$etiquetas = [
    'nombre' => 'Nombre', 'apellidos' => 'Apellidos', 'nif' => 'NIF', 'telefono' => 'Teléfono',
    'poblacion' => 'Población', 'provincia' => 'Provincia', 'email' => 'Email',
];
// Para la búsqueda general se puede elegir también "Número".
$etiquetasBusqueda = ['id' => 'Número'] + $etiquetas;
$camposBusqueda = $camposFiltro;

$query = trim($_GET['q'] ?? '');
$resaltarId = (int)($_GET['resaltar'] ?? 0);
$origenId = (int)($_GET['origen'] ?? 0);
$campoGeneral = $_GET['campo'] ?? 'nombre';
if (!in_array($campoGeneral, $camposBusqueda, true)) {
    $campoGeneral = 'nombre';
}

$delegacionId = trim($_GET['delegacion_id'] ?? '');
$activoFiltro = $_GET['activo'] ?? '';

$columnasOrdenables = [
    'id' => 'c.id', 'nombre' => 'c.nombre', 'apellidos' => 'c.apellidos', 'nif' => 'c.nif',
    'telefono' => 'c.telefono', 'poblacion' => 'c.poblacion', 'provincia' => 'c.provincia',
    'email' => 'c.email', 'delegacion' => 'd.nombre',
];
$ordenActual = $_GET['orden'] ?? 'nombre';
if (!isset($columnasOrdenables[$ordenActual])) {
    $ordenActual = 'nombre';
}
$dirActual = strtolower($_GET['dir'] ?? 'asc') === 'desc' ? 'desc' : 'asc';

function urlOrdenar(string $columna): string
{
    $params = $_GET;
    $mismaColumna = ($params['orden'] ?? '') === $columna;
    $dirPrevia = $mismaColumna ? (($params['dir'] ?? 'asc') === 'desc' ? 'desc' : 'asc') : null;
    $params['orden'] = $columna;
    $params['dir'] = $dirPrevia === 'asc' ? 'desc' : 'asc';
    unset($params['resaltar']);
    return 'index.php?' . http_build_query($params);
}

function indicadorOrden(string $columna, string $ordenActual, string $dirActual): string
{
    if ($columna !== $ordenActual) {
        return '';
    }
    return $dirActual === 'asc' ? ' ▲' : ' ▼';
}

$sqlFromWhere = 'FROM clientes c LEFT JOIN delegaciones d ON d.id = c.delegacion_id WHERE 1=1';
$params = [];

if ($query !== '') {
    $sqlFromWhere .= " AND c.$campoGeneral LIKE :q";
    $params['q'] = "%$query%";
}

if ($delegacionId !== '') {
    $sqlFromWhere .= ' AND c.delegacion_id = :delegacion_id';
    $params['delegacion_id'] = (int) $delegacionId;
}

if ($activoFiltro !== '') {
    $sqlFromWhere .= ' AND c.activo = :activo_filtro';
    $params['activo_filtro'] = (int) $activoFiltro;
}

$filtrosColumna = [];
foreach ($camposFiltro as $campo) {
    $valor = trim($_GET["filtro_$campo"] ?? '');
    if ($valor !== '') {
        $filtrosColumna[$campo] = $valor;
        $sqlFromWhere .= " AND c.$campo LIKE :filtro_$campo";
        $params["filtro_$campo"] = "%$valor%";
    }
}

// --- Paginación ---
$tamanosPagina = [50, 100, 200, 500, 1000];
$porPaginaParam = $_GET['por_pagina'] ?? '100';
$mostrarTodos = ($porPaginaParam === 'todos');
$porPagina = $mostrarTodos ? 0 : (in_array((int) $porPaginaParam, $tamanosPagina, true) ? (int) $porPaginaParam : 100);

// Total de registros que cumplen los filtros (para saber cuántas páginas hay)
$stmtCount = $pdo->prepare('SELECT COUNT(*) AS n ' . $sqlFromWhere);
$stmtCount->execute($params);
$totalFiltrado = (int) $stmtCount->fetch()['n'];

$sql = 'SELECT c.*, d.nombre AS delegacion_nombre ' . $sqlFromWhere
     . ' ORDER BY ' . $columnasOrdenables[$ordenActual] . ' ' . strtoupper($dirActual);

if (!$mostrarTodos) {
    $totalPaginas = max(1, (int) ceil($totalFiltrado / $porPagina));
    $pagina = max(1, (int) ($_GET['pagina'] ?? 1));
    if ($pagina > $totalPaginas) {
        $pagina = $totalPaginas;
    }
    $offset = ($pagina - 1) * $porPagina;
    $sql .= " LIMIT $porPagina OFFSET $offset";
} else {
    $totalPaginas = 1;
    $pagina = 1;
}

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$clientes = $stmt->fetchAll();

// No cargamos todo el listado solo para poder ver los dos resaltados.
// Añadimos únicamente los registros destacados que hayan quedado fuera de la página.
if ($resaltarId > 0 && $origenId > 0 && $resaltarId !== $origenId) {
    $idsExtra = [$origenId, $resaltarId];
    $phExtra = ':extra0,:extra1';
    $sqlExtra = 'SELECT c.*, d.nombre AS delegacion_nombre ' . $sqlFromWhere . " AND c.id IN ($phExtra) ORDER BY " . $columnasOrdenables[$ordenActual] . ' ' . strtoupper($dirActual);
    $stExtra = $pdo->prepare($sqlExtra);
    $paramsExtra = $params;
    foreach ($idsExtra as $n => $idExtra) $paramsExtra['extra' . $n] = $idExtra;
    $stExtra->execute($paramsExtra);
    $presentes = array_fill_keys(array_map(fn($r) => (int)$r['id'], $clientes), true);
    foreach ($stExtra->fetchAll() as $extra) if (empty($presentes[(int)$extra['id']])) $clientes[] = $extra;
}

$delegaciones = $pdo->query('SELECT * FROM delegaciones ORDER BY nombre COLLATE utf8mb4_general_ci')->fetchAll();

// Construye una URL de este listado cambiando solo los parámetros dados
// (conserva búsqueda, filtros, orden, tamaño de página...).
function urlPagina(array $cambios): string
{
    $params = array_merge($_GET, $cambios);
    unset($params['resaltar']);
    return 'index.php?' . http_build_query($params);
}

// URL de este listado, tal cual está ahora (con búsqueda/filtros), para
// poder volver exactamente aquí desde la ficha del cliente.
$qsListado = $_GET; unset($qsListado['resaltar'], $qsListado['origen']);
$urlListadoActual = 'index.php' . ($qsListado ? '?' . http_build_query($qsListado) : '');
$volverParam = urlencode($urlListadoActual);

$titulo = 'Clientes';
$activo = 'clientes';
require __DIR__ . '/includes/header.php';
?>
<section class="panel panel--listado">
  <div class="panel--listado__fijo">
  <div class="panel__title-bar"><span class="panel__title-pill">Mantenimiento clientes</span></div>

  <?php if (!empty($_GET['error'])): ?>
    <p class="form-error"><?= htmlspecialchars($_GET['error']) ?></p>
  <?php endif; ?>
  <?php if (!empty($_GET['renumerado'])): ?>
    <p class="form-ok">Numeración reiniciada correctamente.</p>
  <?php endif; ?>
  <?php if (!empty($_GET['accion_masiva'])): ?>
    <?php $n = (int) ($_GET['n'] ?? 0); ?>
    <?php if ($_GET['accion_masiva'] === 'activados'): ?>
      <p class="form-ok"><?= $n ?> cliente<?= $n !== 1 ? 's' : '' ?> activado<?= $n !== 1 ? 's' : '' ?>.</p>
    <?php elseif ($_GET['accion_masiva'] === 'desactivados'): ?>
      <p class="form-ok"><?= $n ?> cliente<?= $n !== 1 ? 's' : '' ?> desactivado<?= $n !== 1 ? 's' : '' ?>.</p>
    <?php elseif ($_GET['accion_masiva'] === 'borrados'): ?>
      <?php $omitidos = (int) ($_GET['omitidos'] ?? 0); ?>
      <p class="form-ok">
        <?= $n ?> cliente<?= $n !== 1 ? 's' : '' ?> eliminado<?= $n !== 1 ? 's' : '' ?>.
        <?php if ($omitidos > 0): ?>
          <?= $omitidos ?> no se <?= $omitidos !== 1 ? 'pudieron' : 'pudo' ?> eliminar por tener ficha óptica, ventas o facturas asociadas.
        <?php endif; ?>
      </p>
    <?php endif; ?>
  <?php endif; ?>

  <form class="search-bar" method="get" action="index.php">
    <div class="search-bar__fila">
      <label class="search-bar__label" for="q">Búsqueda</label>
      <input class="search-bar__input" type="text" id="q" name="q"
             value="<?= htmlspecialchars($query) ?>" placeholder="Escribe para buscar…">
      <select class="search-bar__select" name="campo">
        <?php foreach ($etiquetasBusqueda as $campo => $etiqueta): ?>
          <option value="<?= $campo ?>" <?= $campo === $campoGeneral ? 'selected' : '' ?>><?= $etiqueta ?></option>
        <?php endforeach; ?>
      </select>
      <button class="btn btn--primary" type="submit">🔍 Buscar</button>
      <select class="search-bar__select" name="delegacion_id" onchange="this.form.submit()">
        <option value="">Todas las delegaciones</option>
        <?php foreach ($delegaciones as $d): ?>
          <option value="<?= (int) $d['id'] ?>" <?= $delegacionId === (string) $d['id'] ? 'selected' : '' ?>>
            <?= htmlspecialchars($d['nombre']) ?>
          </option>
        <?php endforeach; ?>
      </select>
      <select class="search-bar__select" name="activo" onchange="this.form.submit()">
        <option value="">Activos e inactivos</option>
        <option value="1" <?= $activoFiltro === '1' ? 'selected' : '' ?>>Solo activos</option>
        <option value="0" <?= $activoFiltro === '0' ? 'selected' : '' ?>>Solo inactivos</option>
      </select>
    </div>
    <div class="search-bar__fila">
      <a class="btn btn--secondary" href="cliente_form.php">➕ Nuevo cliente</a>
      <a class="btn btn--secondary" href="clientes_listados.php">📋 Listados de Clientes</a>
      <button type="button" class="btn btn--secondary" id="btn-modo-seleccion" onclick="alternarModoSeleccion()">☑️ Seleccionar</button>
    <?php if (usuarioActual()['rol'] === 'admin'): ?>
      <a class="btn btn--secondary" href="clientes_reiniciar_numeracion.php">🔢 Reiniciar numeración</a>
    <?php endif; ?>
      <span class="search-bar__hueco"></span>
      <button type="button" class="btn btn--secondary" data-reset-columns-for="tabla-clientes">↔️ Restablecer columnas</button>
      <button type="submit" form="form-filtros" class="btn btn--secondary">🔎 Filtrar</button>
      <a class="btn btn--secondary" href="index.php">🧹 Limpiar</a>
    </div>
  </form>

  <!-- Formulario de filtros por columna (GET). Sus campos están en la
       fila de filtros de la tabla, enlazados por el atributo form. -->
  <form method="get" action="index.php" id="form-filtros">
    <?php if ($query !== ''): ?><input type="hidden" name="q" value="<?= htmlspecialchars($query) ?>"><?php endif; ?>
    <?php if ($campoGeneral !== 'nombre'): ?><input type="hidden" name="campo" value="<?= htmlspecialchars($campoGeneral) ?>"><?php endif; ?>
    <?php if ($delegacionId !== ''): ?><input type="hidden" name="delegacion_id" value="<?= htmlspecialchars($delegacionId) ?>"><?php endif; ?>
    <?php if ($activoFiltro !== ''): ?><input type="hidden" name="activo" value="<?= htmlspecialchars($activoFiltro) ?>"><?php endif; ?>
    <?php if ($porPaginaParam !== '100'): ?><input type="hidden" name="por_pagina" value="<?= htmlspecialchars($porPaginaParam) ?>"><?php endif; ?>
  </form>

  <div class="panel__seleccion" id="contador-seleccion" style="display:none;">
    <span id="texto-contador-seleccion">0 seleccionados</span>
    <button type="submit" form="form-accion-masiva" formaction="clientes_accion_masiva.php?volver=<?= $volverParam ?>"
            name="accion" value="borrar" class="btn btn--danger"
            onclick="return confirm('¿Eliminar todos los clientes seleccionados?');">🗑️ Borrar seleccionados</button>
    <button type="submit" form="form-accion-masiva" formaction="clientes_accion_masiva.php?volver=<?= $volverParam ?>"
            name="accion" value="activar" class="btn btn--secondary">✅ Activar seleccionados</button>
    <button type="submit" form="form-accion-masiva" formaction="clientes_accion_masiva.php?volver=<?= $volverParam ?>"
            name="accion" value="desactivar" class="btn btn--secondary">🚫 Desactivar seleccionados</button>
  </div>

  <?php require __DIR__ . '/includes/paginacion.php'; ?>
  </div><!-- fin zona fija -->

  <div class="panel--listado__scroll">
  <!-- Formulario que envía las casillas seleccionadas (POST). Envuelve la
       tabla, pero NO tiene ningún botón submit dentro, así que pulsar
       Enter en un filtro nunca dispara una acción masiva. -->
  <form method="post" id="form-accion-masiva">
    <table class="data-table data-table--resizable" id="tabla-clientes" data-column-storage-key="opticas:listado:clientes:columnas">
      <thead>
        <tr>
          <th class="col-check" data-col-key="seleccion" data-col-fixed="1"><input type="checkbox" id="chk-todos" onclick="alternarTodos(this)"></th>
          <th class="col-id" data-col-key="numero"><a href="<?= urlOrdenar('id') ?>" class="th-orden">Número<?= indicadorOrden('id', $ordenActual, $dirActual) ?></a></th>
          <th data-col-key="nombre"><a href="<?= urlOrdenar('nombre') ?>" class="th-orden">Nombre<?= indicadorOrden('nombre', $ordenActual, $dirActual) ?></a></th>
          <th data-col-key="apellidos"><a href="<?= urlOrdenar('apellidos') ?>" class="th-orden">Apellidos<?= indicadorOrden('apellidos', $ordenActual, $dirActual) ?></a></th>
          <th data-col-key="nif"><a href="<?= urlOrdenar('nif') ?>" class="th-orden">NIF<?= indicadorOrden('nif', $ordenActual, $dirActual) ?></a></th>
          <th data-col-key="telefono"><a href="<?= urlOrdenar('telefono') ?>" class="th-orden">Teléfono<?= indicadorOrden('telefono', $ordenActual, $dirActual) ?></a></th>
          <th data-col-key="poblacion"><a href="<?= urlOrdenar('poblacion') ?>" class="th-orden">Población<?= indicadorOrden('poblacion', $ordenActual, $dirActual) ?></a></th>
          <th data-col-key="provincia"><a href="<?= urlOrdenar('provincia') ?>" class="th-orden">Provincia<?= indicadorOrden('provincia', $ordenActual, $dirActual) ?></a></th>
          <th data-col-key="email"><a href="<?= urlOrdenar('email') ?>" class="th-orden">Email<?= indicadorOrden('email', $ordenActual, $dirActual) ?></a></th>
          <th data-col-key="delegacion"><a href="<?= urlOrdenar('delegacion') ?>" class="th-orden">Delegación<?= indicadorOrden('delegacion', $ordenActual, $dirActual) ?></a></th>
        </tr>
        <tr class="data-table__filters">
          <td></td>
          <?php foreach ($camposFiltro as $campo): ?>
            <td data-col-key="<?= htmlspecialchars($campo) ?>"><input type="text" name="filtro_<?= $campo ?>" form="form-filtros"
                       value="<?= htmlspecialchars($filtrosColumna[$campo] ?? '') ?>"></td>
          <?php endforeach; ?>
          <td data-col-key="delegacion"></td>
        </tr>
      </thead>
      <tbody>
        <?php if (empty($clientes)): ?>
          <tr><td colspan="10" class="empty-row">No hay clientes que coincidan con la búsqueda.</td></tr>
        <?php else: foreach ($clientes as $c): ?>
          <tr id="fila-cliente-<?= (int) $c['id'] ?>"
              ondblclick="if (!event.target.closest('input,button,a,select,textarea')) location.href='cliente_form.php?id=<?= (int) $c['id'] ?>&volver=<?= $volverParam ?>&origen=<?= (int)$c['id'] ?>'"
              class="fila-clicable <?= $origenId && $origenId === (int)$c['id'] ? 'fila-origen' : '' ?> <?= $resaltarId && $resaltarId !== $origenId && $resaltarId === (int)$c['id'] ? 'fila-resaltada' : '' ?>">
            <td class="col-check"><input type="checkbox" class="chk-cliente" name="ids[]" value="<?= (int) $c['id'] ?>" onclick="event.stopPropagation(); actualizarContadorSeleccion();"></td>
            <td class="col-id"><?= (int) $c['id'] ?></td>
            <td><?= htmlspecialchars($c['nombre']) ?></td>
            <td><?= htmlspecialchars($c['apellidos'] ?? '') ?></td>
            <td><?= htmlspecialchars($c['nif'] ?? '') ?></td>
            <td><?= htmlspecialchars($c['telefono'] ?? '') ?></td>
            <td><?= htmlspecialchars($c['poblacion'] ?? '') ?></td>
            <td><?= htmlspecialchars($c['provincia'] ?? '') ?></td>
            <td><?= htmlspecialchars($c['email'] ?? '') ?></td>
            <td><?= htmlspecialchars($c['delegacion_nombre'] ?? '') ?></td>
          </tr>
        <?php endforeach; endif; ?>
      </tbody>
    </table>
  </form>
  </div><!-- fin zona scroll -->
</section>
<?php if ($resaltarId): ?>
<script>
  var filaResaltada = document.getElementById('fila-cliente-<?= $resaltarId ?>');
  if (filaResaltada) {
    filaResaltada.scrollIntoView({ block: 'center' });
  }
</script>
<?php endif; ?>
<script>
function alternarModoSeleccion() {
  var tabla = document.getElementById('tabla-clientes');
  var contador = document.getElementById('contador-seleccion');
  var boton = document.getElementById('btn-modo-seleccion');
  var activo = tabla.classList.toggle('modo-seleccion');
  contador.style.display = activo ? '' : 'none';
  boton.textContent = activo ? '☑️ Cancelar selección' : '☑️ Seleccionar';
  if (!activo) {
    document.querySelectorAll('.chk-cliente').forEach(function (c) { c.checked = false; });
    document.getElementById('chk-todos').checked = false;
    actualizarContadorSeleccion();
  }
}

function alternarTodos(origen) {
  document.querySelectorAll('.chk-cliente').forEach(function (c) { c.checked = origen.checked; });
  actualizarContadorSeleccion();
}

function actualizarContadorSeleccion() {
  var total = document.querySelectorAll('.chk-cliente:checked').length;
  document.getElementById('texto-contador-seleccion').textContent =
    total + (total === 1 ? ' seleccionado' : ' seleccionados');
}
</script>
<script src="js/listado_columnas.js?v=1056"></script>
<?php require __DIR__ . '/includes/footer.php'; ?>
