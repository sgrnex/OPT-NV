<?php
require __DIR__ . '/includes/auth.php';
requireAdmin();
require __DIR__ . '/db.php';

$pdo = obtenerConexion();

// Bloquear/activar sin borrar
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['toggle_id'])) {
    $id = (int) $_POST['toggle_id'];
    $pdo->prepare('UPDATE usuarios SET activo = 1 - activo WHERE id = :id')->execute(['id' => $id]);
    header('Location: usuarios.php' . (!empty($_GET['q']) ? '?q=' . urlencode($_GET['q']) : ''));
    exit;
}

$q = trim($_GET['q'] ?? '');
$fEstado = $_GET['estado'] ?? '';
$sql = 'SELECT * FROM usuarios WHERE 1=1';
$params = [];
if ($q !== '') { $sql .= ' AND (usuario LIKE :q OR nombre LIKE :q)'; $params['q'] = "%$q%"; }
if ($fEstado !== '') { $sql .= ' AND activo = :e'; $params['e'] = (int) $fEstado; }
$sql .= ' ORDER BY usuario';
$stmt = $pdo->prepare($sql); $stmt->execute($params);
$usuarios = $stmt->fetchAll();

$titulo = 'Usuarios';
$activo = 'usuarios';
require __DIR__ . '/includes/header.php';
?>
<!-- El listado de usuarios ocupa todo el ancho disponible para que sus
     columnas se ajusten al contenido y no queden truncadas. -->
<section class="panel panel--listado panel--usuarios">
  <div class="panel--listado__fijo">
  <div class="panel__title-bar"><span class="panel__title-pill">Usuarios</span></div>

  <form method="get" action="usuarios.php" class="alta-simple">
    <input class="alta-simple__input" type="text" name="q" value="<?= htmlspecialchars($q) ?>" placeholder="Buscar usuario...">
    <select class="search-bar__select" name="estado" onchange="this.form.submit()">
      <option value="">Todos</option>
      <option value="1" <?= $fEstado === '1' ? 'selected' : '' ?>>Solo activos</option>
      <option value="0" <?= $fEstado === '0' ? 'selected' : '' ?>>Solo inactivos</option>
    </select>
    <button class="btn btn--secondary" type="submit">🔍 Buscar</button>
  </form>

  <div class="search-bar">
    <div class="search-bar__fila">
      <a class="btn btn--secondary" href="usuario_form.php">➕ Nuevo usuario</a>
    </div>
  </div>
  </div>

  <div class="panel--listado__scroll">
  <table class="data-table data-table--resizable" id="tabla-usuarios" data-column-storage-key="opticas:listado:usuarios:columnas">
    <thead>
      <tr>
        <th data-col-key="usuario">Usuario</th>
        <th data-col-key="nombre">Nombre</th>
        <th data-col-key="rol">Rol</th>
        <th data-col-key="ultimo_acceso">Último acceso</th>
        <th data-col-key="activo">Activo</th>
        <th class="col-actions" data-col-key="acciones" data-col-fixed="1"></th>
      </tr>
    </thead>
    <tbody>
      <?php if (empty($usuarios)): ?>
        <tr><td colspan="6" class="empty-row">No hay usuarios.</td></tr>
      <?php else: foreach ($usuarios as $u): ?>
        <tr class="fila-clicable" ondblclick="location.href='usuario_form.php?id=<?= (int) $u['id'] ?>'">
          <td><?= htmlspecialchars($u['usuario']) ?></td>
          <td><?= htmlspecialchars($u['nombre']) ?></td>
          <td><?= $u['rol'] === 'admin' ? 'Administrador' : 'Usuario' ?></td>
          <td><?= !empty($u['ultimo_acceso']) ? date('d-m-Y H:i', strtotime($u['ultimo_acceso'])) : '—' ?></td>
          <td><?= $u['activo'] ? 'Sí' : 'No' ?></td>
          <td class="col-actions">
            <a class="icon-link" href="usuario_form.php?id=<?= (int) $u['id'] ?>" title="Ver / editar">🔍</a>
            <form method="post" class="inline-form">
              <input type="hidden" name="toggle_id" value="<?= (int) $u['id'] ?>">
              <button type="submit" class="icon-link" title="<?= $u['activo'] ? 'Bloquear' : 'Activar' ?>"><?= $u['activo'] ? '🔒' : '🔓' ?></button>
            </form>
            <form action="usuario_borrar.php" method="post" class="inline-form"
                  onsubmit="return confirm('¿Eliminar a <?= htmlspecialchars(addslashes($u['usuario'])) ?>?');">
              <input type="hidden" name="id" value="<?= (int) $u['id'] ?>">
              <button type="submit" class="icon-link icon-link--danger" title="Eliminar">✕</button>
            </form>
          </td>
        </tr>
      <?php endforeach; endif; ?>
    </tbody>
  </table>
  </div>
</section>
<script src="js/listado_columnas.js?v=1057"></script>
<?php require __DIR__ . '/includes/footer.php'; ?>
