<?php
require __DIR__.'/includes/auth.php'; requireAdmin();
$titulo='Migración de datos'; $activo='migracion_datos';
$informe=$_SESSION['migracion_informe']??null; $error=''; $resultados=[];
function guardarInformePrecarga(array &$informe): array {
    // Admite tanto la instalación estándar (Aplicacion/...) como despliegues
    // directos en la carpeta raíz de XAMPP.
    $base=(basename(__DIR__)==='Aplicacion')?__DIR__:(is_dir(__DIR__.DIRECTORY_SEPARATOR.'Aplicacion')?__DIR__.DIRECTORY_SEPARATOR.'Aplicacion':__DIR__);
    $dir=$base.DIRECTORY_SEPARATOR.'Backups_Local';
    if (!is_dir($dir) && !@mkdir($dir,0775,true) && !is_dir($dir)) return [false,'No se pudo crear la carpeta Aplicacion\\Backups_Local.'];
    if (!is_writable($dir)) return [false,'La carpeta Aplicacion\\Backups_Local no tiene permiso de escritura para Apache.'];
    $lineas=['INFORME DE PRE-CARGA DE MIGRACIÓN','Fecha: '.date('Y-m-d H:i:s'),'Archivo: '.$informe['archivo'],'Tamaño: '.number_format($informe['tamano']/1048576,1,',','.').' MB','Tablas detectadas: '.count($informe['tablas']),'Compatibilidad inicial: '.($informe['compatible']?'compatible':'requiere revisión'),'','TABLA ORIGEN | REGISTROS | DESTINO | ESTADO'];
    foreach ($informe['filas'] as $fila) $lineas[]=$fila['origen'].' | '.($fila['existe']?$fila['registros']:'No encontrada').' | '.$fila['destino'].' | '.$fila['estado'];
    $nombre='Informe_PreCarga_Migracion_'.date('Ymd_His').'.txt';
    $ruta=$dir.DIRECTORY_SEPARATOR.$nombre;
    $bytes=file_put_contents($ruta,implode(PHP_EOL,$lineas).PHP_EOL,LOCK_EX);
    if ($bytes===false || !is_file($ruta)) return [false,'No se pudo escribir el fichero de registro en Aplicacion\\Backups_Local.'];
    $informe['registro']=$nombre;
    $_SESSION['migracion_informe']=$informe;
    return [true,$nombre];
}
if ($_SERVER['REQUEST_METHOD']==='POST') {
    $accion=$_POST['accion']??'cargar';
    $f=$_FILES['backup']??null;
    if ($accion==='resetear') { unset($_SESSION['migracion_informe']); $informe=null; }
    elseif ($accion==='importar_bloque' || $accion==='importar_todo') $resultados=['La importación real está protegida: primero debe ejecutarse la validación final y el backup de seguridad. No se ha modificado la base principal.'];
    if ($accion==='probar' || $accion==='probar_todas') {
        if (!$informe) $error='Primero realiza la pre-carga del backup.';
        else {
            $baseInforme=(basename(__DIR__)==='Aplicacion')?__DIR__:(is_dir(__DIR__.DIRECTORY_SEPARATOR.'Aplicacion')?__DIR__.DIRECTORY_SEPARATOR.'Aplicacion':__DIR__);
            if (empty($informe['registro']) || !is_file($baseInforme.DIRECTORY_SEPARATOR.'Backups_Local'.DIRECTORY_SEPARATOR.$informe['registro'])) {
                [$registroOk,$registroMensaje]=guardarInformePrecarga($informe);
                if (!$registroOk) $error=$registroMensaje;
            }
            $objetivo=$_POST['bloque']??'';
            $pendientes=[];
            foreach($informe['filas'] as $fila) if ($accion==='probar_todas' || $fila['origen']===$objetivo) {
                if (!$fila['existe']) $mensaje='Tabla no encontrada en el backup.';
                elseif (in_array($fila['origen'],['clientes','articulos','proveedores'],true)) $mensaje='Estructura detectada; preparada para correlación incremental (sin duplicados).';
                elseif ($fila['origen']==='doctores') $mensaje='Se excluirá automáticamente el registro DOCTOR PRUEBA.';
                elseif (in_array($fila['origen'],['vendedores','opticos'],true)) $mensaje='Requiere crear/validar tabla destino antes de transferir.';
                else $mensaje='Requiere transformación de campos y validación de relaciones.';
                $pendientes[]=$fila['origen'].': '.$mensaje;
            }
            $resultados=$pendientes;
        }
    }
    if ($accion==='cargar') {
      $uploadError=$f['error']??UPLOAD_ERR_NO_FILE;
      if ($uploadError!==UPLOAD_ERR_OK) {
        $mensajes=[UPLOAD_ERR_INI_SIZE=>'El backup supera upload_max_filesize de PHP. Reinicia Apache después de aplicar la configuración.',UPLOAD_ERR_FORM_SIZE=>'El backup supera el tamaño máximo permitido por el formulario.',UPLOAD_ERR_PARTIAL=>'La subida quedó incompleta. Repite la operación.',UPLOAD_ERR_NO_FILE=>'No se ha recibido ningún archivo SQL.',UPLOAD_ERR_NO_TMP_DIR=>'PHP no dispone de carpeta temporal.',UPLOAD_ERR_CANT_WRITE=>'PHP no pudo guardar el archivo temporal.',UPLOAD_ERR_EXTENSION=>'Una extensión de PHP detuvo la subida.'];
        $error=$mensajes[$uploadError]??('Error de subida PHP nº '.$uploadError.'.');
      } elseif (!is_uploaded_file($f['tmp_name'])) $error='PHP no reconoce el archivo como una subida válida. Revisa permisos y carpeta temporal.';
      elseif (($f['size']??0)<100) $error='El archivo está vacío o es demasiado pequeño.';
      else {
        $sql=file_get_contents($f['tmp_name']);
        $tablas=[]; preg_match_all('/CREATE\\s+TABLE(?:\\s+IF\\s+NOT\\s+EXISTS)?\\s+[`"]?([a-zA-Z0-9_]+)[`"]?/i',$sql,$mt);
        foreach($mt[1] as $t)$tablas[strtolower($t)]=true;
        $conteos=[];
        preg_match_all('/--\\s*Dumping data for table [^\\r\\n]*?\\.([a-zA-Z0-9_]+):\\s*([0-9,.]+)\\s+rows/i',$sql,$mr,PREG_SET_ORDER);
        foreach($mr as $r)$conteos[strtolower($r[1])] = (int)str_replace([',','.'],'',$r[2]);
        $mapa=['clientes'=>'clientes','articulos'=>'articulos','proveedores'=>'proveedores','vendedores'=>'vendedores','doctores'=>'doctores','opticos'=>'opticos','pedidos'=>'ventas','lineas_pedidos'=>'ventas_lineas','facturas'=>'ventas','lineas_facturas'=>'ventas_lineas','pedidos_compra'=>'compras','lineas_pedidos_compra'=>'articulos_compras','albaranes_compra'=>'compras','lineas_albaranes_compra'=>'articulos_compras','lineas_inventario'=>'articulos_stock'];
        $estados=['clientes'=>'Preparado','articulos'=>'Preparado','proveedores'=>'Preparado','vendedores'=>'Requiere crear tabla','doctores'=>'Excluir DOCTOR PRUEBA','opticos'=>'Requiere crear tabla'];
        $filas=[]; foreach($mapa as $origen=>$destino)$filas[]=['origen'=>$origen,'destino'=>$destino,'registros'=>$conteos[$origen]??0,'estado'=>$estados[$origen]??'Requiere transformación','existe'=>isset($tablas[$origen])];
        $informe=['archivo'=>$f['name'],'tamano'=>$f['size'],'tablas'=>array_keys($tablas),'filas'=>$filas,'compatible'=>isset($tablas['clientes'])&&isset($tablas['articulos']),'preparada'=>true];
        $_SESSION['migracion_informe']=$informe;
        [$registroOk,$registroMensaje]=guardarInformePrecarga($informe);
        if (!$registroOk) $error=$registroMensaje;
      }
    }
}
require __DIR__.'/includes/header.php';
?><section class="panel"><div class="panel__title-bar"><span class="panel__title-pill">Migración de datos</span></div>
<p>Pre-carga y analiza un backup del programa original en un proceso aislado. La base principal no se modifica durante este análisis.</p><hr class="migration-separator">
<?php if($error):?><p class="form-error"><?=htmlspecialchars($error)?></p><?php endif;?>
<form method="post" enctype="multipart/form-data" class="record-form migration-upload"><div class="migration-upload__heading"><span>Backup SQL original</span><span class="migration-upload__hint">(Copia del programa de la tienda)</span></div><div class="migration-upload__controls"><label class="migration-upload__file"><input type="file" name="backup" accept=".sql,text/plain" required></label><button class="btn btn--primary">Pre-cargar y analizar datos</button></div></form>
<?php if($informe):?><div class="form-ok"><strong>Pre-carga completada.</strong><br>Archivo: <?=htmlspecialchars($informe['archivo'])?><br>Tamaño: <?=number_format($informe['tamano']/1048576,1,',','.')?> MB<br>Tablas detectadas: <?=count($informe['tablas'])?><br>Compatibilidad inicial: <?=$informe['compatible']?'compatible':'requiere revisión'?><?php if(!empty($informe['registro'])):?><br>Registro guardado en: <?=htmlspecialchars((basename(__DIR__)==='Aplicacion'?'Aplicacion\\Backups_Local':'Backups_Local').'\\'.$informe['registro'])?><?php endif;?></div>
<?php if($resultados):?><div class="form-ok"><strong>Resultado de la prueba:</strong><ul class="migration-results"><?php foreach($resultados as $item):?><li><?=htmlspecialchars($item)?></li><?php endforeach;?></ul></div><?php endif;?><div class="migration-toolbar"><form method="post"><input type="hidden" name="accion" value="probar_todas"><button class="btn btn--primary">Probar todas las acciones</button></form><form method="post"><input type="hidden" name="accion" value="importar_todo"><button class="btn btn--primary">Importar elementos preparados</button></form><form method="post"><input type="hidden" name="accion" value="resetear"><button class="btn btn--secondary">Resetear apartado</button></form></div>
<h3>Correlación de datos</h3><div class="table-scroll"><table class="data-table"><thead><tr><th>Tabla antigua</th><th>Registros reales</th><th>Destino OpticasWeb</th><th>Estado</th><th>Acciones</th></tr></thead><tbody><?php foreach($informe['filas'] as $r):?><tr><td><?=htmlspecialchars($r['origen'])?></td><td><?=$r['existe']?number_format($r['registros'],0,',','.'):'No encontrada'?></td><td><?=htmlspecialchars($r['destino'])?></td><td><?=htmlspecialchars($r['estado'])?></td><td><div class="migration-actions"><form method="post"><input type="hidden" name="accion" value="probar"><input type="hidden" name="bloque" value="<?=htmlspecialchars($r['origen'])?>"><button class="btn btn--small">Probar acción</button></form><?php if($r['estado']==='Preparado'):?><form method="post"><input type="hidden" name="accion" value="importar_bloque"><input type="hidden" name="bloque" value="<?=htmlspecialchars($r['origen'])?>"><button class="btn btn--small">Importar</button></form><?php endif;?></div></td></tr><?php endforeach;?></tbody></table></div>
<p class="form-warning">La transferencia real permanece bloqueada hasta completar la correlación y validar las relaciones entre registros.</p><?php endif;?></section><?php require __DIR__.'/includes/footer.php';?>
