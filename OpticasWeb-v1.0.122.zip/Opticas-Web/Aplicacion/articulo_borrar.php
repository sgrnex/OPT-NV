<?php
require __DIR__ . '/includes/auth.php';
requireLogin();
require __DIR__ . '/db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = (int) ($_POST['id'] ?? 0);
    obtenerConexion()->prepare('DELETE FROM articulos WHERE id = :id')->execute(['id' => $id]);
    $volver = $_GET['volver'] ?? $_POST['volver'] ?? 'almacen_articulos.php';
    header('Location: ' . $volver);
    exit;
}

header('Location: almacen_articulos.php');
exit;
