<?php
require __DIR__ . '/includes/auth.php';
requireLogin();
require __DIR__ . '/db.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: index.php');
    exit;
}

$config = require __DIR__ . '/includes/grids_config.php';
$tabla = $_POST['tabla'] ?? '';

if (isset($config[$tabla])) {
    $pdo = obtenerConexion();
    $id = (int) ($_POST['id'] ?? 0);
    $clienteId = (int) ($_POST['ctx_cliente_id'] ?? 0);
    $pdo->prepare("DELETE FROM `$tabla` WHERE id = :id AND cliente_id = :cliente_id")
        ->execute(['id' => $id, 'cliente_id' => $clienteId]);
}

$clienteId = (int) ($_POST['ctx_cliente_id'] ?? 0);
$volver = $_POST['volver'] ?? ('index.php?id=' . $clienteId);
header('Location: ' . $volver);
exit;
