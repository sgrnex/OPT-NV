<?php
require __DIR__ . '/includes/auth.php';
requireLogin();
require __DIR__ . '/db.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: almacen_articulos.php');
    exit;
}

$pdo = obtenerConexion();
$ids = array_values(array_filter(array_map('intval', $_POST['ids'] ?? [])));
$accion = $_POST['accion'] ?? '';
$volver = $_GET['volver'] ?? $_POST['volver'] ?? 'almacen_articulos.php';
$sep = strpos($volver, '?') !== false ? '&' : '?';

if (empty($ids) || !in_array($accion, ['activar', 'desactivar', 'borrar'], true)) {
    header('Location: ' . $volver);
    exit;
}

$ph = implode(',', array_fill(0, count($ids), '?'));

if ($accion === 'activar') {
    $pdo->prepare("UPDATE articulos SET activo = 1 WHERE id IN ($ph)")->execute($ids);
    header("Location: {$volver}{$sep}accion_masiva=activados&n=" . count($ids));
    exit;
}
if ($accion === 'desactivar') {
    $pdo->prepare("UPDATE articulos SET activo = 0 WHERE id IN ($ph)")->execute($ids);
    header("Location: {$volver}{$sep}accion_masiva=desactivados&n=" . count($ids));
    exit;
}

// Borrar
$pdo->prepare("DELETE FROM articulos WHERE id IN ($ph)")->execute($ids);
header("Location: {$volver}{$sep}accion_masiva=borrados&n=" . count($ids));
exit;
