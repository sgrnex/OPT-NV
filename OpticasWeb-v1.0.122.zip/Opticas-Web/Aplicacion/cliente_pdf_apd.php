<?php
require __DIR__ . '/includes/auth.php';
requireLogin();
require __DIR__ . '/db.php';
require __DIR__ . '/includes/pdf_simple.php';

$pdo = obtenerConexion();
$id = (int) ($_GET['id'] ?? 0);

$stmt = $pdo->prepare('SELECT * FROM clientes WHERE id = :id');
$stmt->execute(['id' => $id]);
$cliente = $stmt->fetch();
if (!$cliente) {
    header('Location: index.php');
    exit;
}

$optica = require __DIR__ . '/datos_optica.php';

$nombreCompleto = trim(($cliente['nombre'] ?? '') . ' ' . ($cliente['apellidos'] ?? ''));
$nif = $cliente['nif'] ?: '';
$email = $cliente['email'] ?: '';
$movil = $cliente['movil'] ?: ($cliente['telefono'] ?: '');

$meses = [
    1 => 'enero', 2 => 'febrero', 3 => 'marzo', 4 => 'abril', 5 => 'mayo', 6 => 'junio',
    7 => 'julio', 8 => 'agosto', 9 => 'septiembre', 10 => 'octubre', 11 => 'noviembre', 12 => 'diciembre',
];
$dia = date('d');
$mesTexto = $meses[(int) date('n')];
$anio = date('Y');

// ---------------------------------------------------------------
// Maquetación del documento (una sola página, A4: 595 x 842 pt)
// ---------------------------------------------------------------
$c = new ConstructorPdf();
$margen = 44;
$anchoUtil = 595 - 2 * $margen;
$y = 798;

// Título y subtítulo
$y = $c->parrafo($margen, $y, 60, 'AUTORIZACIÓN PARA EL ENVÍO DE COMUNICACIONES COMERCIALES', 'F2', 13, 15);
$y -= 2;
$c->texto($margen, $y, mb_strtoupper($optica['nombre'], 'UTF-8'), 'F2', 10);
$y -= 16;

// Responsable del tratamiento
$textoResponsable = 'Responsable del tratamiento: ' . $optica['nombre'] . ', con establecimiento en '
    . $optica['direccion'] . '. NIF: ' . $optica['nif']
    . ($optica['email'] ? '. Correo electrónico: ' . $optica['email'] . '.' : '.');
$y = $c->parrafo($margen, $y, 108, $textoResponsable, 'F1', 8.5, 11, '0 0 0', $anchoUtil);
$y -= 10;

// Datos de la persona interesada
$c->texto($margen, $y, 'DATOS DE LA PERSONA INTERESADA', 'F2', 9.5);
$y -= 14;
$colB = $margen + $anchoUtil / 2;
$c->texto($margen, $y, 'Nombre y apellidos:', 'F2', 8.5);
$c->texto($margen + 100, $y, $nombreCompleto ?: '____________________________', 'F1', 8.5);
$c->texto($colB, $y, 'DNI/NIE:', 'F2', 8.5);
$c->texto($colB + 45, $y, $nif ?: '________________', 'F1', 8.5);
$y -= 13;
$c->texto($margen, $y, 'Correo electrónico:', 'F2', 8.5);
$c->texto($margen + 100, $y, $email ?: '____________________________', 'F1', 8.5);
$c->texto($colB, $y, 'Teléfono móvil:', 'F2', 8.5);
$c->texto($colB + 70, $y, $movil ?: '______________', 'F1', 8.5);
$y -= 10;
$c->linea($margen, $y, $margen + $anchoUtil, $y, '0.75 0.75 0.75');
$y -= 14;

// Consentimiento y finalidad
$c->texto($margen, $y, 'CONSENTIMIENTO Y FINALIDAD', 'F2', 9.5);
$y -= 13;
$textoConsentimiento = 'Mediante la firma del presente documento, la persona interesada autoriza de forma '
    . 'libre, específica, informada e inequívoca a ' . $optica['nombre'] . ' a tratar sus datos de contacto '
    . '(nombre, correo electrónico y/o número de teléfono) con la finalidad exclusiva de remitirle '
    . 'información comercial, publicidad, promociones, descuentos, ofertas, campañas y novedades '
    . 'relacionadas con los productos y servicios propios de la óptica.';
$y = $c->parrafo($margen, $y, 108, $textoConsentimiento, 'F1', 8.5, 11, '0 0 0', $anchoUtil);
$y -= 6;
$yaAcepta = !empty($cliente['acepta_mailing_sms']);
$c->rectangulo($margen, $y - 2, 8, 8, '0 0 0');
if ($yaAcepta) {
    $c->texto($margen + 1.3, $y - 1.5, 'X', 'F2', 8);
}
$c->texto($margen + 13, $y, 'AUTORIZO el envío de comunicaciones comerciales por CORREO ELECTRÓNICO y SMS.', 'F1', 8.5);
$y -= 14;
$textoNegativa = 'La negativa a prestar este consentimiento no condicionará la atención, contratación o '
    . 'prestación de los servicios de ' . $optica['nombre'] . '. Este consentimiento se refiere únicamente al '
    . 'uso de los datos de contacto para comunicaciones comerciales y no autoriza el uso con fines '
    . 'publicitarios de datos relativos a la salud, graduación, historial óptico u otras categorías '
    . 'especiales de datos.';
$y = $c->parrafo($margen, $y, 108, $textoNegativa, 'F1', 8.5, 11, '0 0 0', $anchoUtil);
$y -= 14;

// Conservación y destinatarios
$c->texto($margen, $y, 'CONSERVACIÓN Y DESTINATARIOS', 'F2', 9.5);
$y -= 13;
$textoConservacion = 'Los datos se conservarán mientras se mantenga vigente el consentimiento y, una vez '
    . 'retirado, durante los plazos estrictamente necesarios para atender posibles responsabilidades legales '
    . 'y acreditar el consentimiento otorgado. Los datos no se cederán a terceros para sus propios fines '
    . 'publicitarios, sin perjuicio de los proveedores que puedan prestar servicios técnicos a la óptica '
    . 'como encargados del tratamiento y de las comunicaciones exigidas por ley.';
$y = $c->parrafo($margen, $y, 108, $textoConservacion, 'F1', 8.5, 11, '0 0 0', $anchoUtil);
$y -= 10;

// Derechos de la persona interesada
$c->texto($margen, $y, 'DERECHOS DE LA PERSONA INTERESADA', 'F2', 9.5);
$y -= 13;
$textoDerechos = 'La persona interesada puede retirar este consentimiento en cualquier momento, de forma '
    . 'sencilla y gratuita, sin que ello afecte a la licitud del tratamiento realizado con anterioridad. '
    . 'También puede ejercer los derechos de acceso, rectificación, supresión, oposición, limitación y, '
    . 'cuando proceda, portabilidad, dirigiéndose a ' . $optica['nombre'] . ' en ' . $optica['direccion'] . ', '
    . 'o mediante el correo electrónico indicado en este documento. Asimismo, puede presentar una '
    . 'reclamación ante la Agencia Española de Protección de Datos (AEPD).';
$y = $c->parrafo($margen, $y, 108, $textoDerechos, 'F1', 8.5, 11, '0 0 0', $anchoUtil);
$y -= 6;
$y = $c->parrafo($margen, $y, 108, 'Cada comunicación comercial incluirá o indicará un mecanismo sencillo y gratuito para dejar de recibir futuras comunicaciones.', 'F1', 8.5, 11, '0 0 0', $anchoUtil);
$y -= 10;

// Declaración
$c->texto($margen, $y, 'DECLARACIÓN', 'F2', 9.5);
$y -= 13;
$y = $c->parrafo($margen, $y, 108, 'Declaro haber leído y comprendido la información anterior y presto, mediante las casillas marcadas, mi consentimiento para las finalidades y canales seleccionados.', 'F1', 8.5, 11, '0 0 0', $anchoUtil);
$y -= 10;

// Fecha, alineada a la derecha, justo antes de las firmas
$textoFecha = "En {$optica['poblacion_firma']}, a $dia de $mesTexto de $anio.";
$anchoFecha = $c->medirAncho($textoFecha, 'F1', 8.5);
$c->texto($margen + $anchoUtil - $anchoFecha, $y, $textoFecha, 'F1', 8.5);
$y -= 22;

// Firmas
$colFirmaB = $margen + $anchoUtil / 2 + 10;
$c->linea($margen, $y, $margen + $anchoUtil / 2 - 10, $y, '0 0 0');
$c->linea($colFirmaB, $y, $margen + $anchoUtil, $y, '0 0 0');
$y -= 11;
$c->texto($margen, $y, 'Firma de la persona interesada', 'F1', 8);
$c->texto($colFirmaB, $y, 'Firma/sello de ' . $optica['nombre'], 'F1', 8);
$y -= 22;
$c->texto($margen, $y, 'Nombre: ' . ($nombreCompleto ?: '_________________________'), 'F1', 8);
$c->texto($colFirmaB, $y, 'Recibido por: ___________________________', 'F1', 8);
$y -= 26;

// Recuadro con la base jurídica, al final del documento (más pequeño, para diferenciarlo)
$textoBaseJuridica = 'BASE JURÍDICA Y NORMATIVA APLICABLE. El tratamiento se basa en el consentimiento de la '
    . 'persona interesada, conforme a los artículos 6.1.a) y 7 del Reglamento (UE) 2016/679, General de '
    . 'Protección de Datos (RGPD), y a la Ley Orgánica 3/2018, de 5 de diciembre, de Protección de Datos '
    . 'Personales y garantía de los derechos digitales (LOPDGDD). El envío de publicidad mediante correo '
    . 'electrónico o medios electrónicos equivalentes se realizará asimismo de acuerdo con los artículos 21 '
    . 'y 22 de la Ley 34/2002, de 11 de julio, de servicios de la sociedad de la información y de comercio '
    . 'electrónico (LSSI-CE).';
$lineasBase = explode("\n", wordwrap($textoBaseJuridica, 128, "\n", true));
$altoCaja = count($lineasBase) * 9 + 12;
$anchoCajaTexto = $anchoUtil - 16;
$ultimaLineaBase = count($lineasBase) - 1;
$c->rectangulo($margen, $y - $altoCaja, $anchoUtil, $altoCaja, '0.55 0.55 0.55');
$yCaja = $y - 10;
foreach ($lineasBase as $indiceLinea => $linea) {
    if ($indiceLinea !== $ultimaLineaBase) {
        $c->lineaJustificada($margen + 8, $yCaja, $anchoCajaTexto, $linea, 'F1', 6.8, '0.35 0.35 0.35');
    } else {
        $c->texto($margen + 8, $yCaja, $linea, 'F1', 6.8, '0.35 0.35 0.35');
    }
    $yCaja -= 9;
}

$pdfBytes = $c->generarPdf();

header('Content-Type: application/pdf');
header('Content-Disposition: inline; filename="autorizacion_cliente_' . $id . '.pdf"');
header('Content-Length: ' . strlen($pdfBytes));
echo $pdfBytes;
exit;
