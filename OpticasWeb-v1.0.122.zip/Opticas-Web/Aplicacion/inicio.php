<?php
require __DIR__ . '/includes/auth.php';
require __DIR__ . '/db.php';

$error = null;
$usuarioIntroducido = trim($_POST['usuario'] ?? '');
$next = destinoLocalSeguro($_GET['next'] ?? $_POST['next'] ?? 'index.php');

// La portada es también la pantalla única de acceso.
if (!usuarioActual() && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $password = $_POST['password'] ?? '';
    $stmt = obtenerConexion()->prepare(
        'SELECT * FROM usuarios WHERE usuario = :usuario AND activo = 1'
    );
    $stmt->execute(['usuario' => $usuarioIntroducido]);
    $fila = $stmt->fetch();

    if ($fila && password_verify($password, $fila['password_hash'])) {
        session_regenerate_id(true);
        obtenerConexion()->prepare('UPDATE usuarios SET ultimo_acceso = NOW() WHERE id = :id')
            ->execute(['id' => $fila['id']]);
        $_SESSION['usuario'] = [
            'id'     => $fila['id'],
            'nombre' => $fila['nombre'],
            'rol'    => $fila['rol'],
        ];
        header('Location: ' . $next);
        exit;
    }
    $error = 'Usuario o contraseña incorrectos.';
}

if (!usuarioActual()) {
    $portadaLogin = true;
    $titulo = 'Inicio';
    $activo = 'inicio';
    require __DIR__ . '/includes/header.php';
    ?>
    <section class="inicio-portada inicio-portada--login">
      <div class="inicio-portada__bienvenida">
        <div class="inicio-portada__contenido">
          <div class="inicio-portada__marca">
            <img class="inicio-portada__wordmark" src="logo_cloud_opticas_portada.png" alt="Logotipo Cloud Opticas">
          </div>
          <p class="inicio-portada__descripcion">Gestiona clientes, ventas, compras, almacén y contabilidad desde un único lugar, con la sencillez de siempre.</p>
          <div class="inicio-login-card">
            <div class="inicio-login-card__titulo">Iniciar sesión</div>
            <?php if ($error): ?>
              <p class="form-error"><?= htmlspecialchars($error) ?></p>
            <?php endif; ?>
            <form method="post" class="inicio-login-form">
              <input type="hidden" name="next" value="<?= htmlspecialchars($next) ?>">
              <label for="usuario">Usuario</label>
              <input type="text" id="usuario" name="usuario" value="<?= htmlspecialchars($usuarioIntroducido) ?>" autocomplete="username" autofocus required>
              <label for="password">Contraseña</label>
              <input type="password" id="password" name="password" autocomplete="current-password" required>
              <div class="inicio-login-form__acciones">
                <button class="btn btn--primary" type="submit">Entrar</button>
              </div>
            </form>
          </div>
        </div>
      </div>
      <footer class="inicio-portada__pie">
        <span>© Copyright Santiago Gil - 2.026</span>
        <span>v<?= htmlspecialchars(APP_VERSION) ?> · Gestión de ópticas</span>
      </footer>
    </section>
    <?php
    require __DIR__ . '/includes/footer.php';
    exit;
}

$titulo = 'Inicio';
$activo = 'inicio';
require __DIR__ . '/includes/header.php';
?>
<section class="inicio-portada inicio-portada--autenticada">
  <div class="inicio-portada__bienvenida">
    <div class="inicio-portada__contenido">
      <h1 class="inicio-portada__saludo">Bienvenido <strong>a tu óptica</strong></h1>
      <div class="inicio-portada__marca">
        <img class="inicio-portada__wordmark" src="logo_cloud_opticas_portada.png" alt="Logotipo Cloud Opticas">
      </div>
      <p class="inicio-portada__descripcion">Gestiona clientes, ventas, compras, almacén y contabilidad desde un único lugar, con la sencillez de siempre.</p>
    </div>
  </div>
  <footer class="inicio-portada__pie">
    <span>© Copyright Santiago Gil - 2.026</span>
    <span>v<?= htmlspecialchars(APP_VERSION) ?> · Gestión de ópticas</span>
  </footer>
</section>
<?php require __DIR__ . '/includes/footer.php'; ?>
