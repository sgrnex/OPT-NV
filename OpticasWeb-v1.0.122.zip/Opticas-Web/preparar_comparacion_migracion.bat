@echo off
setlocal EnableExtensions EnableDelayedExpansion
title Cloud Opticas - Comparacion de migracion
cd /d "%~dp0"
set "MYSQL_DIR=C:\xampp\mysql\bin"
set "MYSQL_EXE=%MYSQL_DIR%\mysql.exe"
set "DB_USER=root"
set "DB_PASSWORD="
set "ORIGIN_DB=opticasweb_migracion_origen"
set "TARGET_DB=opticasweb_migracion_prueba"
set "OLD_BACKUP=%~1"
set "CURRENT_BACKUP=%~2"
if not defined OLD_BACKUP for /f "delims=" %%F in ('dir /b /a-d /o-d "backup nuevavision*.sql" 2^>nul') do if not defined OLD_BACKUP set "OLD_BACKUP=%CD%\%%F"
if not defined CURRENT_BACKUP for /f "delims=" %%F in ('dir /b /a-d /o-d "Backup_GestionOptica_*.sql" 2^>nul') do if not defined CURRENT_BACKUP set "CURRENT_BACKUP=%CD%\%%F"
if not exist "%MYSQL_EXE%" echo ERROR: No se encontro MySQL en %MYSQL_DIR%. & pause & exit /b 1
if not exist "%OLD_BACKUP%" echo ERROR: Falta el backup antiguo. & pause & exit /b 2
if not exist "%CURRENT_BACKUP%" echo ERROR: Falta el backup actual de OpticasWeb. & pause & exit /b 3
set "AUTH=-u%DB_USER%"
if defined DB_PASSWORD set "AUTH=%AUTH% -p%DB_PASSWORD%"
echo CLOUD OPTICAS - COMPARACION AISLADA DE MIGRACION
echo Origen: %OLD_BACKUP%
echo Destino actual: %CURRENT_BACKUP%
echo Bases temporales: %ORIGIN_DB% y %TARGET_DB%
choice /C SN /N /M "Reconstruir ambas bases temporales [S/N]? "
if errorlevel 2 exit /b 0
"%MYSQL_EXE%" %AUTH% -e "DROP DATABASE IF EXISTS `%ORIGIN_DB%`; DROP DATABASE IF EXISTS `%TARGET_DB%`; CREATE DATABASE `%ORIGIN_DB%` CHARACTER SET utf8mb4; CREATE DATABASE `%TARGET_DB%` CHARACTER SET utf8mb4;"
if errorlevel 1 goto :error
call :importar "%OLD_BACKUP%" "%ORIGIN_DB%" || goto :error
call :importar "%CURRENT_BACKUP%" "%TARGET_DB%" || goto :error
if not exist "Aplicacion\Backups_Local" mkdir "Aplicacion\Backups_Local"
set "REPORT=Aplicacion\Backups_Local\Informe_Comparacion_Migracion.txt"
(
 echo CLOUD OPTICAS - COMPARACION AISLADA
 echo Fecha: %date% %time%
 echo Origen: %ORIGIN_DB%
 echo Destino: %TARGET_DB%
 echo.
 echo TABLAS Y REGISTROS DEL ORIGEN
) > "%REPORT%"
"%MYSQL_EXE%" %AUTH% -N -B "%ORIGIN_DB%" -e "SELECT table_name, table_rows FROM information_schema.tables WHERE table_schema=DATABASE() ORDER BY table_name;" >> "%REPORT%"
>>"%REPORT%" echo.
>>"%REPORT%" echo TABLAS Y REGISTROS DEL DESTINO OPTICASWEB
"%MYSQL_EXE%" %AUTH% -N -B "%TARGET_DB%" -e "SELECT table_name, table_rows FROM information_schema.tables WHERE table_schema=DATABASE() ORDER BY table_name;" >> "%REPORT%"
>>"%REPORT%" echo.
>>"%REPORT%" echo BLOQUES PRIORIZADOS PARA TRANSFORMACION
>>"%REPORT%" echo clientes - clientes
>>"%REPORT%" echo articulos - articulos
>>"%REPORT%" echo proveedores - proveedores
>>"%REPORT%" echo vendedores - vendedores
>>"%REPORT%" echo doctores - excluir DOCTOR PRUEBA
>>"%REPORT%" echo opticos - opticos
>>"%REPORT%" echo pedidos + facturas - ventas
>>"%REPORT%" echo lineas_pedidos + lineas_facturas - ventas_lineas
>>"%REPORT%" echo lineas_inventario + stock_producto - articulos_stock
echo Comparacion completada. Informe: %CD%\%REPORT%
pause
exit /b 0
:importar
set "SRC=%~1"
set "DEST=%~2"
set "TMP_SQL=%TEMP%\CloudOpticas_%RANDOM%_%RANDOM%.sql"
powershell -NoProfile -ExecutionPolicy Bypass -Command "$in=[IO.File]::OpenText('%SRC%'); $out=New-Object IO.StreamWriter('%TMP_SQL%', $false, (New-Object Text.UTF8Encoding($false))); try { while(($line=$in.ReadLine()) -ne $null){ if($line -notmatch '^\s*(CREATE\s+DATABASE|USE\s+)'){ $out.WriteLine($line) } } } finally { $in.Dispose(); $out.Dispose() }"
if errorlevel 1 exit /b 1
"%MYSQL_EXE%" %AUTH% --default-character-set=utf8mb4 "%DEST%" < "%TMP_SQL%"
set "RC=%ERRORLEVEL%"
del /q "%TMP_SQL%" >nul 2>&1
exit /b %RC%
:error
echo ERROR: No se completaron las bases temporales. gestion_optica no se ha tocado.
pause
exit /b 10
