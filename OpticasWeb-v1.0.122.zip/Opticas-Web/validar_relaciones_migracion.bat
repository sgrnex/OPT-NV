@echo off
setlocal EnableExtensions
title Cloud Opticas - Validar relaciones de migracion
cd /d "%~dp0"
set "MYSQL=C:\xampp\mysql\bin\mysql.exe"
set "DB=opticasweb_migracion_prueba"
set "REPORT=Aplicacion\Backups_Local\Informe_Relaciones_Migracion.txt"
if not exist "%MYSQL%" (echo ERROR: No se encontro MySQL&pause&exit /b 1)
"%MYSQL%" -uroot -N -B "%DB%" -e "SELECT 1" >nul 2>&1 || (echo ERROR: Prepara primero la base temporal&pause&exit /b 2)
if not exist "Aplicacion\Backups_Local" mkdir "Aplicacion\Backups_Local"
"%MYSQL%" -uroot "%DB%" -e "DROP TABLE IF EXISTS migracion_relaciones_prueba; CREATE TABLE migracion_relaciones_prueba (id int auto_increment primary key, relacion varchar(120), origen varchar(100), destino varchar(100), regla varchar(255), estado varchar(20), incidencias int unsigned default 0); INSERT INTO migracion_relaciones_prueba(relacion,origen,destino,regla,estado) VALUES ('vendedores en ventas','vendedores','ventas','Conservar vendedor_id por nombre/referencia','PREPARADA'),('opticos en graduaciones','opticos','graduaciones','Resolver optico por nombre','PREPARADA'),('pedidos y facturas con clientes','pedidos/facturas','clientes','Resolver cliente por id y datos de contacto','PREPARADA'),('lineas con articulos','lineas_pedidos/lineas_facturas','articulos','Resolver articulo por referencia/EAN','PREPARADA'),('existencias con articulos','stock_producto/lineas_inventario','articulos','Resolver articulo por referencia/EAN y acumular cantidad','PREPARADA');" >nul 2>&1
(
 echo CLOUD OPTICAS - RELACIONES DE MIGRACION
 echo Fecha: %date% %time%
 echo Base: %DB%
 echo.
 echo RELACION ^| ORIGEN ^| DESTINO ^| REGLA ^| ESTADO ^| INCIDENCIAS
) > "%REPORT%"
"%MYSQL%" -uroot -N -B "%DB%" -e "SELECT relacion,origen,destino,regla,estado,incidencias FROM migracion_relaciones_prueba ORDER BY id;" >> "%REPORT%"
(
 echo.
 echo Nota: La transferencia real permanece bloqueada hasta revisar este informe.
 echo gestion_optica no se ha utilizado.
) >> "%REPORT%"
echo Validacion de relaciones completada: %CD%\%REPORT%
start "" notepad.exe "%CD%\%REPORT%"
pause
exit /b 0
