@echo off
setlocal EnableExtensions EnableDelayedExpansion
cd /d "%~dp0"
set "XAMPP_DIR=C:\xampp"
set "MYSQL_EXE=%XAMPP_DIR%\mysql\bin\mysql.exe"
set "MYSQLD_EXE=%XAMPP_DIR%\mysql\bin\mysqld.exe"
set "MYSQLADMIN_EXE=%XAMPP_DIR%\mysql\bin\mysqladmin.exe"
set "MYSQL_INI=%XAMPP_DIR%\mysql\bin\my.ini"
set "APACHE_EXE=%XAMPP_DIR%\apache\bin\httpd.exe"

 echo ================================================
 echo   Cloud Opticas v1.0.91 - Instalador automatico
 echo ================================================
 echo.
 echo Este instalador va a hacer, sin que tengas que tocar nada mas:
 echo   1. Instalar XAMPP si no lo tienes (Apache + PHP + MySQL)
 echo   2. Copiar la aplicacion dentro de XAMPP
 echo   3. Crear la base de datos
 echo   4. Importar proveedores, compras y ventas historicas disponibles
 echo   5. Crear un icono en tu escritorio
 echo.
 echo Si Windows te pide permiso de administrador, aceptalo: hace
 echo falta para poder instalar XAMPP en tu ordenador.
 echo.
 pause

if exist "%XAMPP_DIR%\xampp-control.exe" (
    echo.
    echo XAMPP ya esta instalado, no hace falta volver a instalarlo.
    goto :copiar_app
)

echo.
echo Descargando XAMPP, puede tardar varios minutos segun tu conexion...
set "INSTALADOR=%TEMP%\xampp-installer.exe"
powershell -NoProfile -ExecutionPolicy Bypass -Command "try { Invoke-WebRequest -Uri 'https://sourceforge.net/projects/xampp/files/latest/download' -OutFile '%INSTALADOR%' -UseBasicParsing } catch { exit 1 }"

if not exist "%INSTALADOR%" (
    echo.
    echo No se ha podido descargar XAMPP automaticamente.
    echo Descargalo manualmente desde:
    echo   https://www.apachefriends.org/es/download.html
    echo instalalo con las opciones por defecto y despues vuelve
    echo a ejecutar este instalador.
    pause
    exit /b 1
)

echo.
echo Instalando XAMPP en modo silencioso, esto tarda unos minutos...
start /wait "" "%INSTALADOR%" --mode unattended --unattendedmodeui minimal

if not exist "%XAMPP_DIR%\xampp-control.exe" (
    echo.
    echo Algo ha fallado en la instalacion automatica de XAMPP.
    echo Instala XAMPP manualmente y vuelve a ejecutar este instalador.
    pause
    exit /b 1
)

:copiar_app
echo.
echo Copiando la aplicacion dentro de XAMPP...
if not exist "%XAMPP_DIR%\htdocs\opticas-php" mkdir "%XAMPP_DIR%\htdocs\opticas-php"
robocopy "%~dp0Aplicacion" "%XAMPP_DIR%\htdocs\opticas-php" /E >nul
set "ROBO=%ERRORLEVEL%"
if %ROBO% GEQ 8 (
    echo.
    echo ERROR: no se ha podido copiar la aplicacion correctamente.
    echo Codigo robocopy: %ROBO%
    pause
    exit /b 1
)

if not exist "%XAMPP_DIR%\htdocs\opticas-php\index.php" (
    echo.
    echo No se ha podido copiar la aplicacion en:
    echo   %XAMPP_DIR%\htdocs\opticas-php
    pause
    exit /b 1
)

if not exist "%MYSQL_EXE%" (
    echo.
    echo ERROR: no encuentro mysql.exe en XAMPP:
    echo   %MYSQL_EXE%
    pause
    exit /b 1
)

echo.
call :asegurar_mysql
if errorlevel 1 exit /b 1

echo.
echo Creando la base de datos y las tablas...
"%MYSQL_EXE%" --protocol=tcp -h 127.0.0.1 -P 3306 -u root --default-character-set=utf8mb4 < "%~dp0Instalacion\BaseDatos\instalar_bd.sql"
if errorlevel 1 (
    echo.
    echo ERROR: no se pudo crear la base de datos.
    echo Si tu MySQL root tiene contrasena, hay que adaptar el instalador.
    pause
    exit /b 1
)

echo Aplicando actualizaciones de base de datos...
"%MYSQL_EXE%" --protocol=tcp -h 127.0.0.1 -P 3306 -u root --default-character-set=utf8mb4 --force < "%~dp0Instalacion\BaseDatos\actualizar_bd_todo.sql"
if errorlevel 1 (
    echo.
    echo ERROR: la actualizacion de base de datos termino con errores.
    pause
    exit /b 1
)

if exist "%~dp0Instalacion\BaseDatos\importar_operativa_historica_v1.0.53.sql" (
    echo Importando operativa historica v1.0.53...
    "%MYSQL_EXE%" --protocol=tcp -h 127.0.0.1 -P 3306 -u root --default-character-set=utf8mb4 < "%~dp0Instalacion\BaseDatos\importar_operativa_historica_v1.0.53.sql"
    if errorlevel 1 (
        echo ERROR: fallo la importacion historica v1.0.53.
        pause
        exit /b 1
    )
)

echo.
call :arrancar_apache
if errorlevel 1 exit /b 1

echo Creando el acceso directo en el escritorio...
set "VBS=%TEMP%\crear_acceso_optica.vbs"
> "%VBS%" echo Set oWS = WScript.CreateObject("WScript.Shell")
>> "%VBS%" echo sLinkFile = oWS.SpecialFolders("Desktop") ^& "\Cloud Opticas.lnk"
>> "%VBS%" echo Set oLink = oWS.CreateShortcut(sLinkFile)
>> "%VBS%" echo oLink.TargetPath = "%~dp0Aplicacion\abrir_gestion_optica.bat"
>> "%VBS%" echo oLink.WorkingDirectory = "%~dp0Aplicacion"
>> "%VBS%" echo oLink.IconLocation = "%XAMPP_DIR%\htdocs\opticas-php\icono_cloud_opticas.ico,0"
>> "%VBS%" echo oLink.Description = "Cloud Opticas"
>> "%VBS%" echo oLink.Save
cscript //nologo "%VBS%" >nul
del "%VBS%" >nul 2>nul

if exist "%USERPROFILE%\Desktop\Cloud Opticas.lnk" (
    echo Icono creado correctamente en el escritorio.
) else (
    echo.
    echo No he podido crear el icono automaticamente. Puedes crearlo a mano
    echo apuntando a este archivo:
echo   %~dp0Aplicacion\abrir_gestion_optica.bat
)

echo.
echo ================================================
echo   Instalacion completada
echo ================================================
echo Se ha creado/actualizado Cloud Opticas v1.0.91.
echo.
echo Usuario:    admin
echo Contrasena: admin
echo.
pause
exit /b 0

:asegurar_mysql
echo Comprobando MySQL...
"%MYSQL_EXE%" --protocol=tcp -h 127.0.0.1 -P 3306 -u root -e "SELECT 1" >nul 2>nul
if not errorlevel 1 (
    echo MySQL ya esta listo.
    exit /b 0
)

echo Arrancando MySQL de XAMPP...
if exist "%MYSQLD_EXE%" (
    start "MySQLXAMPP" /min "%MYSQLD_EXE%" --defaults-file="%MYSQL_INI%"
) else (
    echo ERROR: no encuentro mysqld.exe en:
    echo   %MYSQLD_EXE%
    pause
    exit /b 1
)

echo Esperando a que MySQL acepte conexiones...
for /L %%I in (1,1,45) do (
    "%MYSQL_EXE%" --protocol=tcp -h 127.0.0.1 -P 3306 -u root -e "SELECT 1" >nul 2>nul
    if not errorlevel 1 (
        echo MySQL listo.
        exit /b 0
    )
    echo   intento %%I de 45...
    timeout /t 1 /nobreak >nul
)

echo.
echo ERROR: MySQL no ha quedado listo despues de 45 segundos.
echo.
echo Diagnostico rapido:
netstat -ano | findstr ":3306" || echo   Puerto 3306 sin escucha detectada.
echo.
echo Revisa en XAMPP Control Panel si MySQL aparece en rojo o si el puerto 3306
echo esta ocupado por otro MySQL/MariaDB. Si MySQL tiene contrasena para root,
echo tambien hay que adaptar este instalador.
echo.
if exist "%XAMPP_DIR%\mysql\data\mysql_error.log" (
    echo Ultimas lineas del log de MySQL:
    powershell -NoProfile -Command "Get-Content '%XAMPP_DIR%\mysql\data\mysql_error.log' -Tail 20"
)
pause
exit /b 1

:arrancar_apache
echo Arrancando Apache...
tasklist /FI "IMAGENAME eq httpd.exe" 2>nul | find /I "httpd.exe" >nul
if not errorlevel 1 (
    echo Apache ya estaba iniciado.
    exit /b 0
)
if not exist "%APACHE_EXE%" (
    echo ERROR: no encuentro Apache en:
    echo   %APACHE_EXE%
    pause
    exit /b 1
)
start "ApacheXAMPP" /min "%APACHE_EXE%"
timeout /t 2 /nobreak >nul
exit /b 0
