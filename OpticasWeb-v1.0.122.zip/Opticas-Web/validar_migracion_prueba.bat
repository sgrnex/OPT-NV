@echo off
setlocal EnableExtensions
title Cloud Opticas - Validar migracion de prueba
cd /d "%~dp0"
set "MYSQL_EXE=C:\xampp\mysql\bin\mysql.exe"
set "DB=opticasweb_migracion_prueba"
set "REPORT=Aplicacion\Backups_Local\Informe_Validacion_Migracion.txt"
if not exist "%MYSQL_EXE%" set "MYSQL_EXE=C:\xampp\mysql\bin\mysql.exe"
if not exist "%MYSQL_EXE%" (echo ERROR: No se encontro MySQL en C:\xampp\mysql\bin&pause&exit /b 1)
"%MYSQL_EXE%" -uroot -e "SELECT 1" >nul 2>&1 || (echo ERROR: Inicia MySQL desde XAMPP&pause&exit /b 2)
"%MYSQL_EXE%" -uroot -N -B "%DB%" -e "SELECT 1" >nul 2>&1 || (echo ERROR: No existe %DB%. Ejecuta primero migracion_prueba_automatica.bat&pause&exit /b 3)
if not exist "Aplicacion\Backups_Local" mkdir "Aplicacion\Backups_Local"
"%MYSQL_EXE%" -uroot "%DB%" -e "CREATE TABLE IF NOT EXISTS migracion_mapa_prueba (tabla_origen varchar(100) NOT NULL PRIMARY KEY, tabla_destino varchar(100) NOT NULL, regla varchar(255) NOT NULL); DELETE FROM migracion_mapa_prueba; INSERT INTO migracion_mapa_prueba VALUES ('clientes','clientes','correlacion por id/e-mail'),('articulos','articulos','correlacion por referencia/EAN'),('proveedores','proveedores','correlacion por CIF/nombre'),('vendedores','vendedores','correlacion por nombre'),('doctores','clientes','excluir DOCTOR PRUEBA'),('opticos','graduaciones','correlacion por nombre'),('pedidos','ventas','transformacion de cabecera'),('lineas_pedidos','ventas_lineas','relacion con pedidos y articulos'),('facturas','ventas','transformacion de cabecera'),('lineas_facturas','ventas_lineas','relacion con facturas y articulos'),('pedidos_compra','compras','transformacion de cabecera'),('lineas_pedidos_compra','articulos_compras','relacion con compras y articulos'),('lineas_inventario','articulos_stock','validar referencia de articulo');" >nul 2>&1
if errorlevel 1 echo AVISO: No se pudo persistir el mapa en la base temporal.
(
 echo CLOUD OPTICAS - VALIDACION DE MIGRACION DE PRUEBA
 echo Fecha: %date% %time%
 echo Base validada: %DB%
 echo.
 echo MAPA DE CORRESPONDENCIAS
 echo clientes ^|^| clientes
 echo articulos ^|^| articulos
 echo proveedores ^|^| proveedores
 echo vendedores ^|^| vendedores
 echo doctores ^|^| clientes.doctor - excluir DOCTOR PRUEBA
 echo opticos ^|^| graduaciones.optico
 echo pedidos ^|^| ventas
 echo lineas_pedidos ^|^| ventas_lineas
 echo facturas ^|^| ventas
 echo lineas_facturas ^|^| ventas_lineas
 echo pedidos_compra ^|^| compras
 echo lineas_pedidos_compra ^|^| articulos_compras
 echo lineas_inventario ^|^| articulos_stock
 echo.
 echo TABLAS Y REGISTROS EN LA BASE TEMPORAL
) > "%REPORT%"
"%MYSQL_EXE%" -uroot -N -B "%DB%" -e "SELECT table_name,table_rows FROM information_schema.tables WHERE table_schema=DATABASE() ORDER BY table_name;" >> "%REPORT%"
(
 echo.
 echo COMPROBACIONES
 echo La base principal gestion_optica no se ha utilizado.
 echo Las transformaciones de ventas, compras y existencias quedan pendientes de ejecutar tras validar el mapa.
) >> "%REPORT%"
echo Validacion completada.
echo Informe: %CD%\%REPORT%
start "" notepad.exe "%CD%\%REPORT%"
pause
exit /b 0
